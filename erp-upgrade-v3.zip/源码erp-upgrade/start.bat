@echo off
echo.
echo  ERP System v2.0 Starting...
echo.
npm install
node server.js
pause
