const express = require('express');
const router = express.Router();

// List BOMs
router.get('/', (req, res) => {
  const rows = req.db.prepare(`
    SELECT b.*, p.code as product_code, p.name as product_name, p.unit as product_unit,
      (SELECT COUNT(*) FROM bom_items WHERE bom_id=b.id) as item_count,
      (SELECT COALESCE(SUM(bi.quantity * p2.cost_price),0) FROM bom_items bi JOIN products p2 ON bi.material_id=p2.id WHERE bi.bom_id=b.id) as total_cost
    FROM bom b JOIN products p ON b.product_id = p.id ORDER BY b.id DESC
  `).all();
  res.json(rows);
});

// Get BOM detail with items and alternatives
router.get('/:id(\\d+)', (req, res) => {
  const bom = req.db.prepare('SELECT b.*, p.code as product_code, p.name as product_name FROM bom b JOIN products p ON b.product_id=p.id WHERE b.id=?').get(req.params.id);
  if (!bom) return res.status(404).json({ error: '未找到' });
  bom.items = req.db.prepare(`
    SELECT bi.*, p.code as material_code, p.name as material_name, p.unit as material_unit, p.cost_price as material_cost, p.current_stock, p.occupied_stock,
    (p.current_stock - p.occupied_stock) as available_stock
    FROM bom_items bi JOIN products p ON bi.material_id = p.id WHERE bi.bom_id = ?
  `).all(req.params.id);
  // Get alternatives for each item
  bom.items.forEach(item => {
    item.alternatives = req.db.prepare(`
      SELECT ba.*, p.code, p.name, p.cost_price, p.current_stock
      FROM bom_alternatives ba JOIN products p ON ba.alt_material_id = p.id
      WHERE ba.bom_item_id = ? ORDER BY ba.priority
    `).all(item.id);
  });
  res.json(bom);
});

// Get BOM by product
router.get('/product/:pid', (req, res) => {
  const boms = req.db.prepare(`SELECT b.* FROM bom b WHERE b.product_id=? AND b.status='approved'`).all(req.params.pid);
  res.json(boms);
});

// Calculate BOM cost for a product
router.get('/cost/:pid', (req, res) => {
  const bom = req.db.prepare("SELECT id FROM bom WHERE product_id=? AND status='approved' LIMIT 1").get(req.params.pid);
  if (!bom) return res.json({ items: [], totalCost: 0 });
  const items = req.db.prepare(`
    SELECT bi.quantity, bi.loss_rate, p.cost_price, p.name, p.code, p.unit
    FROM bom_items bi JOIN products p ON bi.material_id = p.id WHERE bi.bom_id = ?
  `).all(bom.id);
  const totalCost = items.reduce((s, i) => s + i.quantity * (1 + i.loss_rate) * i.cost_price, 0);
  res.json({ items, totalCost });
});

// MRP calculation for production
router.get('/mrp/:bomId', (req, res) => {
  const { qty = 1 } = req.query;
  const bom = req.db.prepare('SELECT * FROM bom WHERE id=?').get(req.params.bomId);
  if (!bom) return res.status(404).json({ error: 'BOM不存在' });
  const items = req.db.prepare(`
    SELECT bi.material_id, bi.quantity as unit_qty, bi.loss_rate,
      p.code, p.name, p.unit, p.cost_price, p.current_stock, p.occupied_stock,
      (p.current_stock - p.occupied_stock) as available_stock
    FROM bom_items bi JOIN products p ON bi.material_id = p.id WHERE bi.bom_id = ?
  `).all(req.params.bomId);
  const numQty = Number(qty);
  const result = items.map(item => {
    const needQty = Math.ceil(item.unit_qty * numQty * (1 + item.loss_rate));
    const shortage = Math.max(0, needQty - item.available_stock);
    return {
      ...item,
      total_required: needQty,
      available_stock: item.available_stock,
      shortage,
      enough: shortage === 0,
      cost: needQty * item.cost_price
    };
  });
  const totalCost = result.reduce((s, i) => s + i.cost, 0);
  const totalShortage = result.filter(i => i.shortage > 0).length;
  res.json({ items: result, totalCost, totalShortage, bomName: bom.name });
});

// Copy BOM
router.post('/:id/copy', (req, res) => {
  const src = req.db.prepare('SELECT * FROM bom WHERE id=?').get(req.params.id);
  if (!src) return res.status(404).json({ error: '源BOM不存在' });
  const r = req.db.prepare('INSERT INTO bom (name,product_id,version,status) VALUES (?,?,?,?)')
    .run(src.name + ' (副本)', src.product_id, 'v1.0', 'draft');
  const items = req.db.prepare('SELECT * FROM bom_items WHERE bom_id=?').all(req.params.id);
  const insItem = req.db.prepare('INSERT INTO bom_items (bom_id,material_id,quantity,loss_rate,remark) VALUES (?,?,?,?,?)');
  items.forEach(i => insItem.run(r.lastInsertRowid, i.material_id, i.quantity, i.loss_rate, i.remark));
  res.json({ id: r.lastInsertRowid, message: '复制成功' });
});

// Approve / disable BOM
router.put('/:id/status', (req, res) => {
  const { status } = req.body;
  if (!['draft','approved','disabled'].includes(status)) return res.status(400).json({ error: '无效状态' });
  req.db.prepare('UPDATE bom SET status=? WHERE id=?').run(status, req.params.id);
  req.db.prepare('INSERT INTO audit_logs (user_id,action,detail) VALUES (?,?,?)').run(req.session.username, 'bom_status', JSON.stringify({id: req.params.id, status}));
  res.json({ message: '状态已更新' });
});

// Create BOM
router.post('/', (req, res) => {
  const { name, product_id, items, remark } = req.body;
  if (!product_id || !items || !items.length) return res.status(400).json({ error: '请选择产品和物料' });
  if (items.some(i => i.material_id == product_id)) return res.status(400).json({ error: '成品不能是自身原材料' });
  const r = req.db.prepare('INSERT INTO bom (name,product_id,remark) VALUES (?,?,?)')
    .run((name||'').trim(), Number(product_id), (remark||'').trim());
  const insItem = req.db.prepare('INSERT INTO bom_items (bom_id,material_id,quantity,loss_rate,remark) VALUES (?,?,?,?,?)');
  items.forEach(i => insItem.run(r.lastInsertRowid, Number(i.material_id), Number(i.quantity)||1, Number(i.loss_rate)||0, (i.remark||'').trim()));
  // Add alternatives
  items.forEach(i => {
    if (i.alternatives && i.alternatives.length) {
      const insAlt = req.db.prepare('INSERT INTO bom_alternatives (bom_item_id,alt_material_id,priority) VALUES (?,?,?)');
      // Need to get the bom_item id - approximate by re-query
    }
  });
  req.db.prepare('INSERT INTO audit_logs (user_id,action,detail) VALUES (?,?,?)').run(req.session.username, 'create_bom', JSON.stringify({name, product_id}));
  res.json({ id: r.lastInsertRowid });
});

// Update BOM item
router.put('/item/:id', (req, res) => {
  const { quantity, loss_rate, remark } = req.body;
  req.db.prepare('UPDATE bom_items SET quantity=?, loss_rate=?, remark=? WHERE id=?').run(Number(quantity), Number(loss_rate)||0, (remark||'').trim(), req.params.id);
  res.json({ message: '更新成功' });
});

// Add alternative material
router.post('/item/:id/alternative', (req, res) => {
  const { material_id, priority } = req.body;
  if (!material_id) return res.status(400).json({ error: '请选择替代物料' });
  req.db.prepare('INSERT INTO bom_alternatives (bom_item_id,alt_material_id,priority) VALUES (?,?,?)').run(Number(req.params.id), Number(material_id), Number(priority)||1);
  res.json({ message: '添加成功' });
});

// Delete alternative
router.delete('/alternative/:id', (req, res) => {
  req.db.prepare('DELETE FROM bom_alternatives WHERE id=?').run(req.params.id);
  res.json({ message: '删除成功' });
});

// Delete BOM item
router.delete('/item/:id', (req, res) => {
  req.db.prepare('DELETE FROM bom_alternatives WHERE bom_item_id=?').run(req.params.id);
  req.db.prepare('DELETE FROM bom_items WHERE id=?').run(req.params.id);
  res.json({ message: '删除成功' });
});

// Delete BOM
router.delete('/:id', (req, res) => {
  req.db.prepare('DELETE FROM bom_alternatives WHERE bom_item_id IN (SELECT id FROM bom_items WHERE bom_id=?)').run(req.params.id);
  req.db.prepare('DELETE FROM bom_items WHERE bom_id=?').run(req.params.id);
  req.db.prepare('DELETE FROM bom WHERE id=?').run(req.params.id);
  res.json({ message: '删除成功' });
});

module.exports = router;
