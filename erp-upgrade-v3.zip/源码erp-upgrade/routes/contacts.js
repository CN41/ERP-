const express = require('express');
const router = express.Router();

function sanitize(str) { return typeof str !== 'string' ? str : str.replace(/[<>'"]/g, '').trim(); }

router.get('/', (req, res) => {
  const { type, keyword, page = 1, pageSize = 50 } = req.query;
  let sql = 'SELECT * FROM contacts WHERE 1=1';
  let countSql = 'SELECT COUNT(*) as total FROM contacts WHERE 1=1';
  const params = [];
  if (type) { sql += ' AND (type=? OR type=?)'; countSql += ' AND (type=? OR type=?)'; params.push(type, 'both'); }
  if (keyword) { const kw = `%${sanitize(keyword)}%`; sql += ' AND (name LIKE ? OR contact_person LIKE ? OR phone LIKE ?)'; countSql += ' AND (name LIKE ? OR contact_person LIKE ? OR phone LIKE ?)'; params.push(kw, kw, kw); }
  const total = req.db.prepare(countSql).get(...params).total;
  sql += ' ORDER BY id DESC LIMIT ? OFFSET ?';
  params.push(Number(pageSize), (Number(page)-1)*Number(pageSize));
  res.json({ data: req.db.prepare(sql).all(...params), total });
});

router.post('/', (req, res) => {
  const { type, name, contact_person, phone, email, address, remark } = req.body;
  if (!name || !name.trim()) return res.status(400).json({ error: '名称不能为空' });
  const r = req.db.prepare('INSERT INTO contacts (type,name,contact_person,phone,email,address,remark) VALUES (?,?,?,?,?,?,?)')
    .run(type||'customer', name.trim(), sanitize(contact_person)||'', sanitize(phone)||'', sanitize(email)||'', sanitize(address)||'', sanitize(remark)||'');
  res.json({ id: r.lastInsertRowid });
});

router.put('/:id', (req, res) => {
  const { type, name, contact_person, phone, email, address, remark, status } = req.body;
  if (!name || !name.trim()) return res.status(400).json({ error: '名称不能为空' });
  req.db.prepare('UPDATE contacts SET type=?,name=?,contact_person=?,phone=?,email=?,address=?,remark=?,status=? WHERE id=?')
    .run(type, name.trim(), sanitize(contact_person), sanitize(phone), sanitize(email), sanitize(address), sanitize(remark), Number(status)||1, req.params.id);
  res.json({ message: '更新成功' });
});

router.delete('/:id', (req, res) => { req.db.prepare('DELETE FROM contacts WHERE id=?').run(req.params.id); res.json({ message: '删除成功' }); });
module.exports = router;
