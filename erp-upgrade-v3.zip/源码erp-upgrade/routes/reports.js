const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
  const db = req.db;
  const products = {
    total: db.prepare('SELECT COUNT(*) as c FROM products WHERE status=1').get().c,
    categories: db.prepare("SELECT category, COUNT(*) as count FROM products WHERE status=1 AND category!='' GROUP BY category ORDER BY count DESC").all(),
    stockValue: db.prepare('SELECT COALESCE(SUM(current_stock*cost_price),0) as v FROM products WHERE status=1').get().v,
    lowStock: db.prepare('SELECT code, name, current_stock, min_stock FROM products WHERE status=1 AND current_stock <= min_stock').all(),
    occupied: db.prepare('SELECT COALESCE(SUM(occupied_stock),0) as v FROM products WHERE status=1').get().v
  };
  const finance = {
    income: db.prepare("SELECT COALESCE(SUM(amount),0) as v FROM finance_records WHERE type='income'").get().v,
    expense: db.prepare("SELECT COALESCE(SUM(amount),0) as v FROM finance_records WHERE type='expense'").get().v,
    monthlyIncome: db.prepare("SELECT COALESCE(SUM(amount),0) as v FROM finance_records WHERE type='income' AND created_at >= datetime('now','localtime','start of month')").get().v,
    monthlyExpense: db.prepare("SELECT COALESCE(SUM(amount),0) as v FROM finance_records WHERE type='expense' AND created_at >= datetime('now','localtime','start of month')").get().v,
  };
  finance.profit = finance.income - finance.expense;
  finance.monthlyProfit = finance.monthlyIncome - finance.monthlyExpense;
  const topSelling = db.prepare(`SELECT p.code, p.name, SUM(soi.quantity) as total_qty, SUM(soi.quantity * soi.unit_price) as total_amount FROM sales_order_items soi JOIN products p ON soi.product_id = p.id GROUP BY soi.product_id ORDER BY total_qty DESC LIMIT 10`).all();
  const topCost = db.prepare(`SELECT p.code, p.name, SUM(poi.quantity * poi.unit_price) as total_amount, SUM(poi.quantity) as total_qty FROM purchase_order_items poi JOIN products p ON poi.product_id = p.id GROUP BY poi.product_id ORDER BY total_amount DESC LIMIT 10`).all();
  res.json({ products, finance, topSelling, topCost });
});
module.exports = router;
