const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
  const { status, keyword, days, tag } = req.query;
  let sql = 'SELECT po.*, c.name as supplier_name FROM purchase_orders po LEFT JOIN contacts c ON po.supplier_id = c.id WHERE 1=1';
  const params = [];
  if (status) { sql += ' AND po.status = ?'; params.push(status); }
  if (keyword) { sql += ' AND (po.order_no LIKE ? OR c.name LIKE ?)'; const kw = `%${keyword}%`; params.push(kw, kw); }
  if (days) { sql += ` AND po.created_at >= datetime('now','localtime','-${Number(days)} days')`; }
  if (tag) { sql += ' AND po.tag = ?'; params.push(tag); }
  sql += ' ORDER BY po.id DESC';
  res.json(req.db.prepare(sql).all(...params));
});

router.get('/:id(\\d+)', (req, res) => {
  const order = req.db.prepare('SELECT po.*, c.name as supplier_name FROM purchase_orders po LEFT JOIN contacts c ON po.supplier_id=c.id WHERE po.id=?').get(req.params.id);
  if (!order) return res.status(404).json({ error: '未找到' });
  order.items = req.db.prepare(`SELECT poi.*, p.code as product_code, p.name as product_name, p.unit, (poi.quantity - poi.received_qty) as pending_qty FROM purchase_order_items poi JOIN products p ON poi.product_id=p.id WHERE poi.order_id=?`).all(req.params.id);
  res.json(order);
});

router.post('/', (req, res) => {
  const { supplier_id, items, remark, tag } = req.body;
  if (!items || !items.length) return res.status(400).json({ error: '请添加物料' });
  const order_no = 'PO' + Date.now().toString().slice(-8);
  const total = items.reduce((s, i) => s + Number(i.quantity) * Number(i.unit_price), 0);
  const r = req.db.prepare('INSERT INTO purchase_orders (order_no,supplier_id,total_amount,tag,remark) VALUES (?,?,?,?,?)')
    .run(order_no, supplier_id ? Number(supplier_id) : null, total, (tag||'').trim(), (remark||'').trim());
  const ins = req.db.prepare('INSERT INTO purchase_order_items (order_id,product_id,quantity,unit_price) VALUES (?,?,?,?)');
  items.forEach(i => ins.run(r.lastInsertRowid, Number(i.product_id), Number(i.quantity), Number(i.unit_price)));
  req.db.prepare('INSERT INTO audit_logs (user_id,action,detail) VALUES (?,?,?)').run(req.session.username, 'create_purchase', JSON.stringify({order_no, total}));
  res.json({ id: r.lastInsertRowid, order_no });
});

// Partial receive
router.put('/:id/receive', (req, res) => {
  const { items } = req.body; // [{item_id, receive_qty}]
  if (!items || !items.length) return res.status(400).json({ error: '请选择要入库的物料' });
  const order = req.db.prepare('SELECT * FROM purchase_orders WHERE id=?').get(req.params.id);
  if (!order) return res.status(404).json({ error: '未找到' });
  if (['received','cancelled'].includes(order.status)) return res.status(400).json({ error: '该订单已完成或已取消' });

  const updateItem = req.db.prepare('UPDATE purchase_order_items SET received_qty = received_qty + ? WHERE id = ? AND order_id = ?');
  const updateStock = req.db.prepare('UPDATE products SET current_stock = current_stock + ? WHERE id = ?');
  const insertLog = req.db.prepare('INSERT INTO stock_movements (product_id,type,quantity,related_order,remark) VALUES (?,?,?,?,?)');

  for (const item of items) {
    const poi = req.db.prepare('SELECT * FROM purchase_order_items WHERE id=? AND order_id=?').get(item.item_id, req.params.id);
    if (!poi) continue;
    const recvQty = Math.min(Number(item.receive_qty), poi.quantity - poi.received_qty);
    if (recvQty <= 0) continue;
    updateItem.run(recvQty, item.item_id, req.params.id);
    updateStock.run(recvQty, poi.product_id);
    insertLog.run(poi.product_id, 'in', recvQty, order.order_no, '采购入库');
    // Record batch
    req.db.prepare('INSERT INTO batches (product_id,batch_no,quantity,cost_price,supplier) VALUES (?,?,?,?,?)')
      .run(poi.product_id, order.order_no + '-' + item.item_id, recvQty, poi.unit_price, order.supplier_id||'');
  }

  // Check if fully received
  const allItems = req.db.prepare('SELECT * FROM purchase_order_items WHERE order_id=?').all(req.params.id);
  const allReceived = allItems.every(i => i.received_qty >= i.quantity);
  const newStatus = allReceived ? 'received' : 'partial_received';
  req.db.prepare("UPDATE purchase_orders SET status=?,updated_at=datetime('now','localtime') WHERE id=?").run(newStatus, req.params.id);

  // Finance record on full receive
  if (newStatus === 'received' && order.status !== 'received') {
    req.db.prepare("INSERT INTO finance_records (type,category,amount,related_order,contact_id,remark) SELECT 'expense','采购',total_amount,order_no,supplier_id,'采购支出' FROM purchase_orders WHERE id=?").run(req.params.id);
  }

  req.db.prepare('INSERT INTO audit_logs (user_id,action,detail) VALUES (?,?,?)').run(req.session.username, 'purchase_receive', JSON.stringify({order_no: order.order_no, items: items.length}));
  res.json({ message: '入库成功', status: newStatus });
});

// Status change
router.put('/:id/status', (req, res) => {
  const { status } = req.body;
  const validTransitions = { draft: ['confirmed','cancelled'], confirmed: ['cancelled'], partial_received: ['received','cancelled'], received: [], cancelled: [] };
  const order = req.db.prepare('SELECT * FROM purchase_orders WHERE id=?').get(req.params.id);
  if (!order) return res.status(404).json({ error: '未找到' });
  if (!validTransitions[order.status]?.includes(status)) return res.status(400).json({ error: `不允许从 ${order.status} 转为 ${status}` });
  req.db.prepare("UPDATE purchase_orders SET status=?,updated_at=datetime('now','localtime') WHERE id=?").run(status, req.params.id);
  req.db.prepare('INSERT INTO audit_logs (user_id,action,detail) VALUES (?,?,?)').run(req.session.username, 'purchase_status', JSON.stringify({order_no: order.order_no, from: order.status, to: status}));
  res.json({ message: '状态已更新' });
});

// Payment
router.put('/:id/pay', (req, res) => {
  const { amount } = req.body;
  const order = req.db.prepare('SELECT * FROM purchase_orders WHERE id=?').get(req.params.id);
  if (!order) return res.status(404).json({ error: '未找到' });
  const pay = Number(amount);
  if (!pay || pay <= 0) return res.status(400).json({ error: '金额必须大于0' });
  req.db.prepare('UPDATE purchase_orders SET paid_amount = paid_amount + ? WHERE id=?').run(pay, req.params.id);
  req.db.prepare("INSERT INTO finance_records (type,category,amount,related_order,contact_id,remark) VALUES ('expense','采购付款',?,?,?,'采购付款')").run(pay, order.order_no, order.supplier_id);
  res.json({ message: '付款成功' });
});

router.delete('/:id', (req, res) => {
  const order = req.db.prepare('SELECT order_no FROM purchase_orders WHERE id=?').get(req.params.id);
  if (order) {
    req.db.prepare('DELETE FROM purchase_order_items WHERE order_id=?').run(req.params.id);
    req.db.prepare('DELETE FROM purchase_orders WHERE id=?').run(req.params.id);
    req.db.prepare('INSERT INTO audit_logs (user_id,action,detail) VALUES (?,?,?)').run(req.session.username, 'delete_purchase', JSON.stringify(order));
  }
  res.json({ message: '删除成功' });
});

module.exports = router;
