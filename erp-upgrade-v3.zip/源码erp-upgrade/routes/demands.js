const express = require('express');
const router = express.Router();

// Purchase demands (auto-generated from stock warnings or MRP)
router.get('/', (req, res) => {
  const { status = 'pending' } = req.query;
  const rows = req.db.prepare(`SELECT pd.*, p.code, p.name, p.unit, p.cost_price, (p.current_stock - p.min_stock) as stock_diff 
    FROM purchase_demands pd JOIN products p ON pd.product_id=p.id WHERE pd.status=? ORDER BY pd.id DESC`).all(status);
  res.json(rows);
});

// Auto-generate from stock warnings
router.post('/auto-generate', (req, res) => {
  const warnings = req.db.prepare(`SELECT id, code, name, min_stock, max_stock, current_stock, auto_replenish FROM products WHERE status=1 AND current_stock <= min_stock AND auto_replenish=1`).all();
  let generated = 0;
  warnings.forEach(p => {
    const existing = req.db.prepare("SELECT COUNT(*) as c FROM purchase_demands WHERE product_id=? AND status='pending'").get(p.id).c;
    if (existing === 0) {
      const demandQty = (p.max_stock || p.min_stock * 2) - p.current_stock;
      req.db.prepare('INSERT INTO purchase_demands (product_id,quantity,source,source_ref) VALUES (?,?,?,?)').run(p.id, demandQty, 'warning', p.code);
      generated++;
    }
  });
  res.json({ message: `生成了 ${generated} 条采购需求`, generated });
});

// Convert demand to purchase order
router.post('/convert', (req, res) => {
  const { demand_ids, supplier_id } = req.body;
  if (!demand_ids || !demand_ids.length) return res.status(400).json({ error: '请选择采购需求' });
  const demands = demand_ids.map(id => req.db.prepare('SELECT pd.*, p.cost_price FROM purchase_demands pd JOIN products p ON pd.product_id=p.id WHERE pd.id=? AND pd.status="pending"').get(id)).filter(Boolean);
  if (!demands.length) return res.status(400).json({ error: '无有效需求' });

  const order_no = 'PO' + Date.now().toString().slice(-8);
  const total = demands.reduce((s, d) => s + d.quantity * d.cost_price, 0);
  const r = req.db.prepare('INSERT INTO purchase_orders (order_no,supplier_id,total_amount,source,remark) VALUES (?,?,?,?,?)')
    .run(order_no, supplier_id ? Number(supplier_id) : null, total, 'auto', '自动生成采购单');

  const ins = req.db.prepare('INSERT INTO purchase_order_items (order_id,product_id,quantity,unit_price) VALUES (?,?,?,?)');
  demands.forEach(d => {
    ins.run(r.lastInsertRowid, d.product_id, d.quantity, d.cost_price);
    req.db.prepare('UPDATE purchase_demands SET status="converted" WHERE id=?').run(d.id);
  });

  res.json({ id: r.lastInsertRowid, order_no, items: demands.length });
});

router.delete('/:id', (req, res) => {
  req.db.prepare("UPDATE purchase_demands SET status='cancelled' WHERE id=?").run(req.params.id);
  res.json({ message: '已取消' });
});

module.exports = router;
