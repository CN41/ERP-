const express = require('express');
const router = express.Router();
router.get('/', (req, res) => { res.json(req.db.prepare('SELECT * FROM tags ORDER BY name').all()); });
router.post('/', (req, res) => {
  const { name, color } = req.body;
  if (!name || !name.trim()) return res.status(400).json({ error: '名称不能为空' });
  try { const r = req.db.prepare('INSERT INTO tags (name,color) VALUES (?,?)').run(name.trim(), color||'#4f6ef7'); res.json({ id: r.lastInsertRowid }); }
  catch(e) { if (e.message.includes('UNIQUE')) return res.status(400).json({ error: '标签已存在' }); res.status(400).json({ error: e.message }); }
});
router.delete('/:id', (req, res) => { req.db.prepare('DELETE FROM tags WHERE id=?').run(req.params.id); res.json({ message: '删除成功' }); });
module.exports = router;
