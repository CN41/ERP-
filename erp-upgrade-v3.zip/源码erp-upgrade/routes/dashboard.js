const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
  const db = req.db;
  const product_count = db.prepare('SELECT COUNT(*) as c FROM products WHERE status=1').get().c;
  const low_stock = db.prepare('SELECT COUNT(*) as c FROM products WHERE current_stock <= min_stock AND status=1').get().c;
  const pending_purchase = db.prepare("SELECT COUNT(*) as c FROM purchase_orders WHERE status IN ('draft','confirmed','partial_received')").get().c;
  const pending_sales = db.prepare("SELECT COUNT(*) as c FROM sales_orders WHERE status IN ('draft','confirmed','partial_shipped')").get().c;
  const pending_production = db.prepare("SELECT COUNT(*) as c FROM production_orders WHERE status IN ('pending','in_progress','partial_completed')").get().c;
  const pending_demands = db.prepare("SELECT COUNT(*) as c FROM purchase_demands WHERE status='pending'").get().c;
  const total_income = db.prepare("SELECT COALESCE(SUM(amount),0) as t FROM finance_records WHERE type='income'").get().t;
  const total_expense = db.prepare("SELECT COALESCE(SUM(amount),0) as t FROM finance_records WHERE type='expense'").get().t;
  const monthly_income = db.prepare("SELECT COALESCE(SUM(amount),0) as t FROM finance_records WHERE type='income' AND created_at >= datetime('now','localtime','start of month')").get().t;
  const monthly_expense = db.prepare("SELECT COALESCE(SUM(amount),0) as t FROM finance_records WHERE type='expense' AND created_at >= datetime('now','localtime','start of month')").get().t;
  const stock_value = db.prepare('SELECT COALESCE(SUM(current_stock*cost_price),0) as t FROM products WHERE status=1').get().t;
  const total_occupied = db.prepare('SELECT COALESCE(SUM(occupied_stock),0) as t FROM products WHERE status=1').get().t;
  const recent_orders = db.prepare(`SELECT 'purchase' as type, order_no, total_amount, status, created_at FROM purchase_orders UNION ALL SELECT 'sales' as type, order_no, total_amount, status, created_at FROM sales_orders ORDER BY created_at DESC LIMIT 10`).all();
  const low_stock_items = db.prepare('SELECT code,name,current_stock,min_stock FROM products WHERE current_stock<=min_stock AND status=1 LIMIT 5').all();
  const recent_activities = db.prepare('SELECT * FROM audit_logs ORDER BY id DESC LIMIT 5').all();
  const warehouse_count = db.prepare('SELECT COUNT(*) as c FROM warehouses WHERE status=1').get().c;

  res.json({
    product_count, low_stock, pending_purchase, pending_sales, pending_production, pending_demands,
    total_income, total_expense, profit: total_income - total_expense,
    monthly_income, monthly_expense, monthly_profit: monthly_income - monthly_expense,
    stock_value, total_occupied, recent_orders, low_stock_items, recent_activities, warehouse_count
  });
});

module.exports = router;
