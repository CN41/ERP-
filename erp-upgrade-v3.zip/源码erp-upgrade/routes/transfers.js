const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
  const rows = req.db.prepare(`SELECT st.*, fw.name as from_name, tw.name as to_name FROM stock_transfers st LEFT JOIN warehouses fw ON st.from_warehouse_id=fw.id LEFT JOIN warehouses tw ON st.to_warehouse_id=tw.id ORDER BY st.id DESC`).all();
  res.json(rows);
});

router.get('/:id', (req, res) => {
  const t = req.db.prepare('SELECT st.*, fw.name as from_name, tw.name as to_name FROM stock_transfers st LEFT JOIN warehouses fw ON st.from_warehouse_id=fw.id LEFT JOIN warehouses tw ON st.to_warehouse_id=tw.id WHERE st.id=?').get(req.params.id);
  if (!t) return res.status(404).json({ error: '未找到' });
  t.items = req.db.prepare('SELECT sti.*, p.code, p.name, p.unit FROM stock_transfer_items sti JOIN products p ON sti.product_id=p.id WHERE sti.transfer_id=?').all(req.params.id);
  res.json(t);
});

router.post('/', (req, res) => {
  const { from_warehouse_id, to_warehouse_id, items, remark } = req.body;
  if (!from_warehouse_id || !to_warehouse_id) return res.status(400).json({ error: '请选择出库和入库仓库' });
  if (from_warehouse_id === to_warehouse_id) return res.status(400).json({ error: '出库和入库仓库不能相同' });
  if (!items || !items.length) return res.status(400).json({ error: '请添加调拨物料' });
  const order_no = 'TF' + Date.now().toString().slice(-8);
  const r = req.db.prepare('INSERT INTO stock_transfers (order_no,from_warehouse_id,to_warehouse_id,remark) VALUES (?,?,?,?)').run(order_no, from_warehouse_id, to_warehouse_id, (remark||'').trim());
  const ins = req.db.prepare('INSERT INTO stock_transfer_items (transfer_id,product_id,quantity) VALUES (?,?,?)');
  items.forEach(i => ins.run(r.lastInsertRowid, Number(i.product_id), Number(i.quantity)));
  res.json({ id: r.lastInsertRowid, order_no });
});

router.put('/:id/execute', (req, res) => {
  const t = req.db.prepare('SELECT * FROM stock_transfers WHERE id=?').get(req.params.id);
  if (!t) return res.status(404).json({ error: '未找到' });
  if (t.status !== 'confirmed') return res.status(400).json({ error: '请先确认调拨单' });
  const items = req.db.prepare('SELECT sti.*, p.current_stock FROM stock_transfer_items sti JOIN products p ON sti.product_id=p.id WHERE sti.transfer_id=?').all(req.params.id);
  for (const i of items) {
    if (i.current_stock < i.quantity) return res.status(400).json({ error: `库存不足: ${i.code}` });
  }
  const updateStock = req.db.prepare('UPDATE products SET current_stock=current_stock-?, warehouse_id=? WHERE id=?');
  const logOut = req.db.prepare("INSERT INTO stock_movements (product_id,type,quantity,related_order,remark) VALUES (?,'transfer_out',?,?,?)");
  const logIn = req.db.prepare("INSERT INTO stock_movements (product_id,type,quantity,related_order,remark) VALUES (?,'transfer_in',?,?,?)");
  items.forEach(i => {
    updateStock.run(i.quantity, t.to_warehouse_id, i.product_id);
    logOut.run(i.product_id, i.quantity, t.order_no, '调拨出库');
    logIn.run(i.product_id, i.quantity, t.order_no, '调拨入库');
  });
  req.db.prepare("UPDATE stock_transfers SET status='completed' WHERE id=?").run(req.params.id);
  res.json({ message: '调拨完成' });
});

router.put('/:id/status', (req, res) => {
  const { status } = req.body;
  req.db.prepare('UPDATE stock_transfers SET status=? WHERE id=?').run(status, req.params.id);
  res.json({ message: '状态已更新' });
});

router.delete('/:id', (req, res) => {
  req.db.prepare('DELETE FROM stock_transfer_items WHERE transfer_id=?').run(req.params.id);
  req.db.prepare('DELETE FROM stock_transfers WHERE id=?').run(req.params.id);
  res.json({ message: '删除成功' });
});

module.exports = router;
