const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
  const { status, keyword, days, tag } = req.query;
  let sql = 'SELECT so.*, c.name as customer_name FROM sales_orders so LEFT JOIN contacts c ON so.customer_id=c.id WHERE 1=1';
  const params = [];
  if (status) { sql += ' AND so.status = ?'; params.push(status); }
  if (keyword) { sql += ' AND (so.order_no LIKE ? OR c.name LIKE ?)'; const kw = `%${keyword}%`; params.push(kw, kw); }
  if (days) { sql += ` AND so.created_at >= datetime('now','localtime','-${Number(days)} days')`; }
  if (tag) { sql += ' AND so.tag = ?'; params.push(tag); }
  sql += ' ORDER BY so.id DESC';
  res.json(req.db.prepare(sql).all(...params));
});

router.get('/:id(\\d+)', (req, res) => {
  const order = req.db.prepare('SELECT so.*, c.name as customer_name FROM sales_orders so LEFT JOIN contacts c ON so.customer_id=c.id WHERE so.id=?').get(req.params.id);
  if (!order) return res.status(404).json({ error: '未找到' });
  order.items = req.db.prepare(`SELECT soi.*, p.code as product_code, p.name as product_name, p.unit, (soi.quantity - soi.shipped_qty) as pending_qty FROM sales_order_items soi JOIN products p ON soi.product_id=p.id WHERE soi.order_id=?`).all(req.params.id);
  res.json(order);
});

router.post('/', (req, res) => {
  const { customer_id, items, remark, tag } = req.body;
  if (!items || !items.length) return res.status(400).json({ error: '请添加产品' });
  const order_no = 'SO' + Date.now().toString().slice(-8);
  const total = items.reduce((s, i) => s + Number(i.quantity) * Number(i.unit_price), 0);
  const r = req.db.prepare('INSERT INTO sales_orders (order_no,customer_id,total_amount,tag,remark) VALUES (?,?,?,?,?)')
    .run(order_no, customer_id ? Number(customer_id) : null, total, (tag||'').trim(), (remark||'').trim());
  const ins = req.db.prepare('INSERT INTO sales_order_items (order_id,product_id,quantity,unit_price) VALUES (?,?,?,?)');
  items.forEach(i => ins.run(r.lastInsertRowid, Number(i.product_id), Number(i.quantity), Number(i.unit_price)));
  // Occupy stock
  const occupy = req.db.prepare('UPDATE products SET occupied_stock = occupied_stock + ? WHERE id = ?');
  items.forEach(i => occupy.run(Number(i.quantity), Number(i.product_id)));
  req.db.prepare('INSERT INTO audit_logs (user_id,action,detail) VALUES (?,?,?)').run(req.session.username, 'create_sale', JSON.stringify({order_no, total}));
  res.json({ id: r.lastInsertRowid, order_no });
});

// Partial ship
router.put('/:id/ship', (req, res) => {
  const { items } = req.body; // [{item_id, ship_qty}]
  if (!items || !items.length) return res.status(400).json({ error: '请选择要发货的产品' });
  const order = req.db.prepare('SELECT * FROM sales_orders WHERE id=?').get(req.params.id);
  if (!order) return res.status(404).json({ error: '未找到' });
  if (['completed','cancelled'].includes(order.status)) return res.status(400).json({ error: '该订单已完成或已取消' });

  const updateItem = req.db.prepare('UPDATE sales_order_items SET shipped_qty = shipped_qty + ? WHERE id = ? AND order_id = ?');
  const updateStock = req.db.prepare('UPDATE products SET current_stock = current_stock - ?, occupied_stock = occupied_stock - ? WHERE id = ?');
  const insertLog = req.db.prepare('INSERT INTO stock_movements (product_id,type,quantity,related_order,remark) VALUES (?,?,?,?,?)');

  for (const item of items) {
    const soi = req.db.prepare('SELECT * FROM sales_order_items WHERE id=? AND order_id=?').get(item.item_id, req.params.id);
    if (!soi) continue;
    const p = req.db.prepare('SELECT current_stock FROM products WHERE id=?').get(soi.product_id);
    const shipQty = Math.min(Number(item.ship_qty), soi.quantity - soi.shipped_qty, p.current_stock);
    if (shipQty <= 0) continue;
    updateItem.run(shipQty, item.item_id, req.params.id);
    updateStock.run(shipQty, shipQty, soi.product_id);
    insertLog.run(soi.product_id, 'out', shipQty, order.order_no, '销售出库');
  }

  const allItems = req.db.prepare('SELECT * FROM sales_order_items WHERE order_id=?').all(req.params.id);
  const allShipped = allItems.every(i => i.shipped_qty >= i.quantity);
  const newStatus = allShipped ? 'shipped' : 'partial_shipped';
  req.db.prepare("UPDATE sales_orders SET status=?,updated_at=datetime('now','localtime') WHERE id=?").run(newStatus, req.params.id);
  req.db.prepare('INSERT INTO audit_logs (user_id,action,detail) VALUES (?,?,?)').run(req.session.username, 'sale_ship', JSON.stringify({order_no: order.order_no, items: items.length}));
  res.json({ message: '发货成功', status: newStatus });
});

// Complete order
router.put('/:id/complete', (req, res) => {
  const order = req.db.prepare('SELECT * FROM sales_orders WHERE id=?').get(req.params.id);
  if (!order) return res.status(404).json({ error: '未找到' });
  if (!['shipped','partial_shipped'].includes(order.status)) return res.status(400).json({ error: '请先发货' });
  req.db.prepare("UPDATE sales_orders SET status='completed',updated_at=datetime('now','localtime') WHERE id=?").run(req.params.id);
  req.db.prepare("INSERT INTO finance_records (type,category,amount,related_order,contact_id,remark) SELECT 'income','销售',total_amount,order_no,customer_id,'销售收款' FROM sales_orders WHERE id=?").run(req.params.id);
  req.db.prepare('INSERT INTO audit_logs (user_id,action,detail) VALUES (?,?,?)').run(req.session.username, 'sale_complete', JSON.stringify({order_no: order.order_no}));
  res.json({ message: '订单完成' });
});

// Status change
router.put('/:id/status', (req, res) => {
  const { status } = req.body;
  const validTransitions = { draft: ['confirmed','cancelled'], confirmed: ['cancelled'], partial_shipped: ['shipped','cancelled'], shipped: ['completed'], completed: [], cancelled: [] };
  const order = req.db.prepare('SELECT * FROM sales_orders WHERE id=?').get(req.params.id);
  if (!order) return res.status(404).json({ error: '未找到' });
  if (!validTransitions[order.status]?.includes(status)) return res.status(400).json({ error: `不允许从 ${order.status} 转为 ${status}` });
  req.db.prepare("UPDATE sales_orders SET status=?,updated_at=datetime('now','localtime') WHERE id=?").run(status, req.params.id);
  res.json({ message: '状态已更新' });
});

// Payment
router.put('/:id/pay', (req, res) => {
  const { amount } = req.body;
  const order = req.db.prepare('SELECT * FROM sales_orders WHERE id=?').get(req.params.id);
  if (!order) return res.status(404).json({ error: '未找到' });
  const pay = Number(amount);
  if (!pay || pay <= 0) return res.status(400).json({ error: '金额必须大于0' });
  req.db.prepare('UPDATE sales_orders SET paid_amount = paid_amount + ? WHERE id=?').run(pay, req.params.id);
  req.db.prepare("INSERT INTO finance_records (type,category,amount,related_order,contact_id,remark) VALUES ('income','销售收款',?,?,?,'销售收款')").run(pay, order.order_no, order.customer_id);
  res.json({ message: '收款成功' });
});

router.delete('/:id', (req, res) => {
  const order = req.db.prepare('SELECT order_no FROM sales_orders WHERE id=?').get(req.params.id);
  if (order) {
    // Release occupied stock
    const items = req.db.prepare('SELECT * FROM sales_order_items WHERE order_id=?').all(req.params.id);
    items.forEach(i => {
      req.db.prepare('UPDATE products SET occupied_stock = MAX(0, occupied_stock - ?) WHERE id = ?').run(i.quantity - i.shipped_qty, i.product_id);
    });
    req.db.prepare('DELETE FROM sales_order_items WHERE order_id=?').run(req.params.id);
    req.db.prepare('DELETE FROM sales_orders WHERE id=?').run(req.params.id);
    req.db.prepare('INSERT INTO audit_logs (user_id,action,detail) VALUES (?,?,?)').run(req.session.username, 'delete_sale', JSON.stringify(order));
  }
  res.json({ message: '删除成功' });
});

module.exports = router;
