const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
  const { type, category, days, page = 1, pageSize = 50 } = req.query;
  let countSql = 'SELECT COUNT(*) as total FROM finance_records WHERE 1=1';
  let sql = 'SELECT fr.*, c.name as contact_name FROM finance_records fr LEFT JOIN contacts c ON fr.contact_id=c.id WHERE 1=1';
  const params = [];
  if (type) { sql += ' AND fr.type=?'; countSql += ' AND type=?'; params.push(type); }
  if (category) { sql += ' AND fr.category=?'; countSql += ' AND category=?'; params.push(category); }
  if (days) { sql += ` AND fr.created_at >= datetime('now','localtime','-${Number(days)} days')`; countSql += ` AND created_at >= datetime('now','localtime','-${Number(days)} days')`; }
  const total = req.db.prepare(countSql).get(...params).total;
  sql += ' ORDER BY fr.id DESC LIMIT ? OFFSET ?';
  params.push(Number(pageSize), (Number(page)-1)*Number(pageSize));
  res.json({ data: req.db.prepare(sql).all(...params), total });
});

router.get('/summary', (req, res) => {
  const db = req.db;
  const income = db.prepare("SELECT COALESCE(SUM(amount),0) as t FROM finance_records WHERE type='income'").get().t;
  const expense = db.prepare("SELECT COALESCE(SUM(amount),0) as t FROM finance_records WHERE type='expense'").get().t;
  const monthly_income = db.prepare("SELECT COALESCE(SUM(amount),0) as t FROM finance_records WHERE type='income' AND created_at >= datetime('now','localtime','start of month')").get().t;
  const monthly_expense = db.prepare("SELECT COALESCE(SUM(amount),0) as t FROM finance_records WHERE type='expense' AND created_at >= datetime('now','localtime','start of month')").get().t;
  const unpaid_sales = db.prepare("SELECT COALESCE(SUM(total_amount-paid_amount),0) as t FROM sales_orders WHERE status NOT IN ('draft','cancelled')").get().t;
  const unpaid_purchase = db.prepare("SELECT COALESCE(SUM(total_amount-paid_amount),0) as t FROM purchase_orders WHERE status NOT IN ('draft','cancelled')").get().t;
  const monthly_trend = [];
  for (let i = 5; i >= 0; i--) {
    const mi = db.prepare(`SELECT COALESCE(SUM(amount),0) as v FROM finance_records WHERE type='income' AND strftime('%Y-%m',created_at)=strftime('%Y-%m','now','localtime','-${i} months')`).get().v;
    const me = db.prepare(`SELECT COALESCE(SUM(amount),0) as v FROM finance_records WHERE type='expense' AND strftime('%Y-%m',created_at)=strftime('%Y-%m','now','localtime','-${i} months')`).get().v;
    const label = db.prepare(`SELECT strftime('%m','now','localtime','-${i} months') as d`).get().d;
    monthly_trend.push({ label, income: mi, expense: me });
  }
  res.json({ income, expense, profit: income - expense, monthly_income, monthly_expense, monthly_profit: monthly_income - monthly_expense, unpaid_sales, unpaid_purchase, monthly_trend });
});

router.post('/', (req, res) => {
  const { type, category, amount, related_order, contact_id, remark } = req.body;
  if (!type || !['income','expense'].includes(type)) return res.status(400).json({ error: '类型无效' });
  const amt = Number(amount);
  if (!amt || amt <= 0) return res.status(400).json({ error: '金额必须大于0' });
  const r = req.db.prepare('INSERT INTO finance_records (type,category,amount,related_order,contact_id,remark) VALUES (?,?,?,?,?,?)')
    .run(type, (category||'').trim(), amt, (related_order||'').trim(), contact_id ? Number(contact_id) : null, (remark||'').trim());
  res.json({ id: r.lastInsertRowid });
});

router.delete('/:id', (req, res) => { req.db.prepare('DELETE FROM finance_records WHERE id=?').run(req.params.id); res.json({ message: '删除成功' }); });
module.exports = router;
