const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
  const { status, keyword } = req.query;
  let sql = `SELECT po.*, p.code as product_code, p.name as product_name, p.unit as product_unit, b.name as bom_name FROM production_orders po JOIN products p ON po.product_id=p.id LEFT JOIN bom b ON po.bom_id=b.id WHERE 1=1`;
  const params = [];
  if (status) { sql += ' AND po.status = ?'; params.push(status); }
  if (keyword) { sql += ' AND (po.order_no LIKE ? OR p.name LIKE ?)'; const kw = `%${keyword}%`; params.push(kw, kw); }
  sql += ' ORDER BY po.id DESC';
  res.json(req.db.prepare(sql).all(...params));
});

router.get('/:id(\\d+)', (req, res) => {
  const order = req.db.prepare('SELECT po.*, p.code as product_code, p.name as product_name, p.unit as product_unit FROM production_orders po JOIN products p ON po.product_id=p.id WHERE po.id=?').get(req.params.id);
  if (!order) return res.status(404).json({ error: '未找到' });
  order.materials = req.db.prepare(`SELECT pm.*, p.code as material_code, p.name as material_name, p.unit as material_unit, p.current_stock, p.occupied_stock, (p.current_stock-p.occupied_stock) as available_stock, p.cost_price FROM production_materials pm JOIN products p ON pm.material_id = p.id WHERE pm.production_id=?`).all(req.params.id);
  res.json(order);
});

// Create with MRP check
router.post('/', (req, res) => {
  const { product_id, bom_id, quantity, remark } = req.body;
  if (!product_id || !quantity) return res.status(400).json({ error: '请选择产品和数量' });
  const qty = Number(quantity);
  if (qty <= 0) return res.status(400).json({ error: '数量必须大于0' });
  const product = req.db.prepare('SELECT * FROM products WHERE id=?').get(Number(product_id));
  if (!product) return res.status(404).json({ error: '产品不存在' });

  let bom;
  if (bom_id) {
    bom = req.db.prepare("SELECT * FROM bom WHERE id=? AND status='approved'").get(Number(bom_id));
  } else {
    bom = req.db.prepare("SELECT * FROM bom WHERE product_id=? AND status='approved' LIMIT 1").get(Number(product_id));
  }
  if (!bom) return res.status(400).json({ error: '该产品没有已审核的BOM' });

  // MRP calculation
  const bomItems = req.db.prepare(`
    SELECT bi.*, p.name, p.current_stock, p.occupied_stock, p.cost_price,
    (p.current_stock - p.occupied_stock) as available_stock
    FROM bom_items bi JOIN products p ON bi.material_id = p.id WHERE bi.bom_id=?
  `).all(bom.id);

  const shortages = [];
  const materials = bomItems.map(b => {
    const requiredQty = Math.ceil(b.quantity * qty * (1 + b.loss_rate));
    const shortage = Math.max(0, requiredQty - b.available_stock);
    if (shortage > 0) shortages.push({ material_id: b.material_id, name: b.name, required: requiredQty, available: b.available_stock, shortage });
    return { material_id: b.material_id, required_qty: requiredQty };
  });

  const order_no = 'MF' + Date.now().toString().slice(-8);
  const r = req.db.prepare('INSERT INTO production_orders (order_no,product_id,bom_id,quantity,remark) VALUES (?,?,?,?,?)')
    .run(order_no, Number(product_id), bom.id, qty, (remark||'').trim());

  const insMat = req.db.prepare('INSERT INTO production_materials (production_id,material_id,required_qty) VALUES (?,?,?)');
  materials.forEach(m => insMat.run(r.lastInsertRowid, m.material_id, m.required_qty));

  req.db.prepare('INSERT INTO audit_logs (user_id,action,detail) VALUES (?,?,?)').run(req.session.username, 'create_production', JSON.stringify({order_no, product: product.name, qty, shortages: shortages.length}));
  res.json({ id: r.lastInsertRowid, order_no, shortages });
});

// Start production (consume materials)
router.put('/:id/start', (req, res) => {
  const order = req.db.prepare('SELECT * FROM production_orders WHERE id=?').get(req.params.id);
  if (!order) return res.status(404).json({ error: '未找到' });
  if (order.status !== 'pending') return res.status(400).json({ error: '只能启动待生产状态的工单' });

  const materials = req.db.prepare('SELECT pm.*, p.current_stock FROM production_materials pm JOIN products p ON pm.material_id=p.id WHERE pm.production_id=?').all(req.params.id);
  for (const m of materials) {
    if (m.current_stock < m.required_qty) return res.status(400).json({ error: `原材料不足: ${m.material_id}，需要${m.required_qty}，库存${m.current_stock}` });
  }

  const updateStock = req.db.prepare('UPDATE products SET current_stock=current_stock-? WHERE id=?');
  const insertLog = req.db.prepare('INSERT INTO stock_movements (product_id,type,quantity,related_order,remark) VALUES (?,?,?,?,?)');
  materials.forEach(m => {
    updateStock.run(m.required_qty, m.material_id);
    insertLog.run(m.material_id, 'out', m.required_qty, order.order_no, '生产领料');
    req.db.prepare('UPDATE production_materials SET consumed_qty=? WHERE id=?').run(m.required_qty, m.id);
  });

  req.db.prepare("UPDATE production_orders SET status='in_progress',updated_at=datetime('now','localtime') WHERE id=?").run(req.params.id);
  req.db.prepare('INSERT INTO audit_logs (user_id,action,detail) VALUES (?,?,?)').run(req.session.username, 'production_start', JSON.stringify({order_no: order.order_no}));
  res.json({ message: '已开始生产' });
});

// Partial or full completion
router.put('/:id/complete', (req, res) => {
  const { quantity } = req.body;
  const order = req.db.prepare('SELECT * FROM production_orders WHERE id=?').get(req.params.id);
  if (!order) return res.status(404).json({ error: '未找到' });
  if (!['in_progress','partial_completed'].includes(order.status)) return res.status(400).json({ error: '工单状态不允许完工' });

  const completeQty = Number(quantity) || (order.quantity - order.completed_qty);
  if (completeQty <= 0) return res.status(400).json({ error: '数量必须大于0' });
  if (order.completed_qty + completeQty > order.quantity) return res.status(400).json({ error: '完工数量超过计划数量' });

  req.db.prepare('UPDATE products SET current_stock=current_stock+? WHERE id=?').run(completeQty, order.product_id);
  req.db.prepare('INSERT INTO stock_movements (product_id,type,quantity,related_order,remark) VALUES (?,?,?,?,?)').run(order.product_id, 'in', completeQty, order.order_no, '生产入库');

  const newCompleted = order.completed_qty + completeQty;
  const newStatus = newCompleted >= order.quantity ? 'completed' : 'partial_completed';
  req.db.prepare('UPDATE production_orders SET completed_qty=?,status=?,updated_at=datetime("now","localtime") WHERE id=?').run(newCompleted, newStatus, req.params.id);
  req.db.prepare('INSERT INTO audit_logs (user_id,action,detail) VALUES (?,?,?)').run(req.session.username, 'production_complete', JSON.stringify({order_no: order.order_no, qty: completeQty}));
  res.json({ message: '入库成功', completed_qty: newCompleted, status: newStatus });
});

// Material return (尾料回库)
router.put('/:id/return-materials', (req, res) => {
  const order = req.db.prepare('SELECT * FROM production_orders WHERE id=?').get(req.params.id);
  if (!order) return res.status(404).json({ error: '未找到' });
  if (!['in_progress','partial_completed','completed'].includes(order.status)) return res.status(400).json({ error: '状态不允许退料' });

  const materials = req.db.prepare('SELECT * FROM production_materials WHERE production_id=?').all(req.params.id);
  const updateStock = req.db.prepare('UPDATE products SET current_stock=current_stock+? WHERE id=?');
  const insertLog = req.db.prepare('INSERT INTO stock_movements (product_id,type,quantity,related_order,remark) VALUES (?,?,?,?,?)');

  materials.forEach(m => {
    const returnQty = m.consumed_qty - m.returned_qty;
    if (returnQty > 0) {
      // Proportional return based on completion ratio
      const ratio = order.completed_qty / order.quantity;
      const actualReturn = Math.floor(returnQty * (1 - ratio));
      if (actualReturn > 0) {
        updateStock.run(actualReturn, m.material_id);
        insertLog.run(m.material_id, 'in', actualReturn, order.order_no, '尾料回库');
        req.db.prepare('UPDATE production_materials SET returned_qty=returned_qty+? WHERE id=?').run(actualReturn, m.id);
      }
    }
  });

  res.json({ message: '退料完成' });
});

router.put('/:id/status', (req, res) => {
  const { status } = req.body;
  const order = req.db.prepare('SELECT * FROM production_orders WHERE id=?').get(req.params.id);
  if (!order) return res.status(404).json({ error: '未找到' });
  const valid = { pending: ['cancelled'], in_progress: ['cancelled'], partial_completed: ['completed','cancelled'], completed: [], cancelled: [] };
  if (!valid[order.status]?.includes(status)) return res.status(400).json({ error: '不允许该状态变更' });
  req.db.prepare("UPDATE production_orders SET status=?,updated_at=datetime('now','localtime') WHERE id=?").run(status, req.params.id);
  res.json({ message: '状态已更新' });
});

router.delete('/:id', (req, res) => {
  req.db.prepare('DELETE FROM production_materials WHERE production_id=?').run(req.params.id);
  req.db.prepare('DELETE FROM production_orders WHERE id=?').run(req.params.id);
  res.json({ message: '删除成功' });
});

module.exports = router;
