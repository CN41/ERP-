const express = require('express');
const router = express.Router();

function sanitize(str) { return typeof str !== 'string' ? str : str.replace(/[<>'"]/g, '').trim(); }

router.get('/', (req, res) => {
  const { category, keyword, status, warehouse_id, low_only, page = 1, pageSize = 50 } = req.query;
  let countSql = 'SELECT COUNT(*) as total FROM products WHERE 1=1';
  let sql = `SELECT p.*, w.name as warehouse_name, l.name as location_name,
    CASE WHEN p.current_stock <= p.min_stock THEN 1 ELSE 0 END as is_low,
    (p.current_stock - p.occupied_stock) as available_stock
    FROM products p LEFT JOIN warehouses w ON p.warehouse_id=w.id LEFT JOIN locations l ON p.location_id=l.id WHERE 1=1`;
  const params = [];
  if (category) { sql += ' AND p.category = ?'; countSql += ' AND category = ?'; params.push(sanitize(category)); }
  if (keyword) { const kw = `%${sanitize(keyword)}%`; sql += ' AND (p.code LIKE ? OR p.name LIKE ? OR p.barcode LIKE ? OR p.brand LIKE ? OR p.model LIKE ?)'; countSql += ' AND (code LIKE ? OR name LIKE ? OR barcode LIKE ? OR brand LIKE ? OR model LIKE ?)'; params.push(kw,kw,kw,kw,kw); }
  if (status !== undefined && status !== '') { sql += ' AND p.status = ?'; countSql += ' AND status = ?'; params.push(Number(status)); }
  if (warehouse_id) { sql += ' AND p.warehouse_id = ?'; countSql += ' AND warehouse_id = ?'; params.push(Number(warehouse_id)); }
  if (low_only === '1') { sql += ' AND p.current_stock <= p.min_stock'; countSql += ' AND current_stock <= min_stock'; }
  const total = req.db.prepare(countSql).get(...params).total;
  sql += ' ORDER BY p.id DESC LIMIT ? OFFSET ?';
  params.push(Number(pageSize), (Number(page)-1)*Number(pageSize));
  res.json({ data: req.db.prepare(sql).all(...params), total, page: Number(page), pageSize: Number(pageSize) });
});

router.get('/categories', (req, res) => {
  res.json(req.db.prepare("SELECT DISTINCT category FROM products WHERE category != '' ORDER BY category").all().map(r => r.category));
});

router.get('/search', (req, res) => {
  const { keyword } = req.query;
  if (!keyword || keyword.length < 1) return res.json([]);
  const kw = `%${sanitize(keyword)}%`;
  res.json(req.db.prepare('SELECT id, code, name, barcode, unit, cost_price, sale_price, current_stock, occupied_stock, (current_stock-occupied_stock) as available_stock FROM products WHERE status=1 AND (code LIKE ? OR name LIKE ? OR barcode LIKE ? OR model LIKE ?) LIMIT 20').all(kw,kw,kw,kw));
});

router.get('/warning', (req, res) => {
  const items = req.db.prepare(`SELECT p.*, (p.current_stock - p.min_stock) as diff, w.name as warehouse_name FROM products p LEFT JOIN warehouses w ON p.warehouse_id=w.id WHERE p.status=1 AND p.current_stock <= p.min_stock ORDER BY diff ASC`).all();
  res.json(items);
});

router.get('/:id(\\d+)', (req, res) => {
  const row = req.db.prepare(`SELECT p.*, w.name as warehouse_name, l.name as location_name, (p.current_stock - p.occupied_stock) as available_stock FROM products p LEFT JOIN warehouses w ON p.warehouse_id=w.id LEFT JOIN locations l ON p.location_id=l.id WHERE p.id = ?`).get(req.params.id);
  row ? res.json(row) : res.status(404).json({ error: '未找到' });
});

router.post('/', (req, res) => {
  const { code, name } = req.body;
  if (!code || !code.trim() || !name || !name.trim()) return res.status(400).json({ error: '编号和名称不能为空' });
  const b = req.body;
  try {
    const r = req.db.prepare(`INSERT INTO products (code,name,category,unit,spec,brand,model,package,cost_price,sale_price,min_stock,max_stock,auto_replenish,warehouse_id,location_id,supplier,remark,barcode) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`)
      .run(sanitize(code), sanitize(name), sanitize(b.category)||'', sanitize(b.unit)||'个', sanitize(b.spec)||'', sanitize(b.brand)||'', sanitize(b.model)||'', sanitize(b.package)||'', Number(b.cost_price)||0, Number(b.sale_price)||0, Number(b.min_stock)||0, Number(b.max_stock)||0, b.auto_replenish?1:0, b.warehouse_id?Number(b.warehouse_id):null, b.location_id?Number(b.location_id):null, sanitize(b.supplier)||'', sanitize(b.remark)||'', sanitize(b.barcode)||'');
    req.db.prepare('INSERT INTO audit_logs (user_id,action,detail) VALUES (?,?,?)').run(req.session.username, 'create_product', JSON.stringify({id: r.lastInsertRowid, code, name}));
    res.json({ id: r.lastInsertRowid, message: '添加成功' });
  } catch(e) {
    if (e.message.includes('UNIQUE')) return res.status(400).json({ error: '物料编号已存在' });
    res.status(400).json({ error: e.message });
  }
});

router.put('/:id', (req, res) => {
  const { code, name } = req.body;
  if (!code || !code.trim() || !name || !name.trim()) return res.status(400).json({ error: '编号和名称不能为空' });
  const b = req.body;
  req.db.prepare(`UPDATE products SET code=?,name=?,category=?,unit=?,spec=?,brand=?,model=?,package=?,cost_price=?,sale_price=?,min_stock=?,max_stock=?,current_stock=?,auto_replenish=?,warehouse_id=?,location_id=?,supplier=?,remark=?,status=?,barcode=?,updated_at=datetime('now','localtime') WHERE id=?`)
    .run(sanitize(code), sanitize(name), sanitize(b.category), sanitize(b.unit), sanitize(b.spec), sanitize(b.brand), sanitize(b.model), sanitize(b.package), Number(b.cost_price), Number(b.sale_price), Number(b.min_stock), Number(b.max_stock), Number(b.current_stock), b.auto_replenish?1:0, b.warehouse_id?Number(b.warehouse_id):null, b.location_id?Number(b.location_id):null, sanitize(b.supplier), sanitize(b.remark), Number(b.status)||1, sanitize(b.barcode)||'', req.params.id);
  req.db.prepare('INSERT INTO audit_logs (user_id,action,detail) VALUES (?,?,?)').run(req.session.username, 'update_product', JSON.stringify({id: req.params.id, code}));
  res.json({ message: '更新成功' });
});

router.delete('/:id', (req, res) => {
  const p = req.db.prepare('SELECT code, name FROM products WHERE id=?').get(req.params.id);
  req.db.prepare('DELETE FROM products WHERE id = ?').run(req.params.id);
  req.db.prepare('INSERT INTO audit_logs (user_id,action,detail) VALUES (?,?,?)').run(req.session.username, 'delete_product', JSON.stringify(p));
  res.json({ message: '删除成功' });
});

module.exports = router;
