const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
  const { keyword, category, low_only, warehouse_id } = req.query;
  let sql = `SELECT p.*, w.name as warehouse_name, l.name as location_name,
    CASE WHEN p.current_stock <= p.min_stock THEN 1 ELSE 0 END as is_low,
    CASE WHEN p.current_stock = 0 THEN 1 ELSE 0 END as is_out,
    (p.current_stock - p.occupied_stock) as available_stock
    FROM products p LEFT JOIN warehouses w ON p.warehouse_id=w.id LEFT JOIN locations l ON p.location_id=l.id WHERE p.status = 1`;
  const params = [];
  if (keyword) { sql += ' AND (p.code LIKE ? OR p.name LIKE ? OR p.barcode LIKE ? OR p.brand LIKE ? OR p.model LIKE ?)'; const kw = `%${keyword}%`; params.push(kw,kw,kw,kw,kw); }
  if (category) { sql += ' AND p.category = ?'; params.push(category); }
  if (warehouse_id) { sql += ' AND p.warehouse_id = ?'; params.push(Number(warehouse_id)); }
  if (low_only === '1') { sql += ' AND p.current_stock <= p.min_stock'; }
  sql += ' ORDER BY is_low DESC, p.category, p.name';
  res.json(req.db.prepare(sql).all(...params));
});

router.get('/movements', (req, res) => {
  const { product_id, type, days = 30, keyword, page = 1, pageSize = 50 } = req.query;
  let countSql = 'SELECT COUNT(*) as total FROM stock_movements sm JOIN products p ON sm.product_id = p.id WHERE 1=1';
  let sql = 'SELECT sm.*, p.code as product_code, p.name as product_name, p.barcode, p.unit FROM stock_movements sm JOIN products p ON sm.product_id = p.id WHERE 1=1';
  const params = [];
  if (product_id) { sql += ' AND sm.product_id = ?'; countSql += ' AND sm.product_id = ?'; params.push(Number(product_id)); }
  if (type) { sql += ' AND sm.type = ?'; countSql += ' AND sm.type = ?'; params.push(type); }
  if (days) { sql += ` AND sm.created_at >= datetime('now','localtime','-${Number(days)} days')`; countSql += ` AND sm.created_at >= datetime('now','localtime','-${Number(days)} days')`; }
  if (keyword) { const kw = `%${keyword}%`; sql += ' AND (p.code LIKE ? OR p.name LIKE ?)'; countSql += ' AND (p.code LIKE ? OR p.name LIKE ?)'; params.push(kw, kw); }
  const total = req.db.prepare(countSql).get(...params).total;
  sql += ' ORDER BY sm.id DESC LIMIT ? OFFSET ?';
  params.push(Number(pageSize), (Number(page)-1)*Number(pageSize));
  res.json({ data: req.db.prepare(sql).all(...params), total });
});

router.get('/barcode/:code', (req, res) => {
  const p = req.db.prepare('SELECT *, (current_stock-occupied_stock) as available_stock FROM products WHERE (barcode = ? OR code = ?) AND status = 1').get(req.params.code, req.params.code);
  p ? res.json(p) : res.status(404).json({ error: '未找到该条码对应的产品' });
});

router.post('/scan', (req, res) => {
  const { barcode, type, quantity, remark } = req.body;
  if (!barcode || !type) return res.status(400).json({ error: '条码和类型不能为空' });
  if (!['in','out'].includes(type)) return res.status(400).json({ error: '类型必须为 in 或 out' });
  const p = req.db.prepare('SELECT * FROM products WHERE (barcode = ? OR code = ?) AND status = 1').get(barcode.trim(), barcode.trim());
  if (!p) return res.status(404).json({ error: '未找到该条码对应的产品' });
  const qty = Number(quantity) || 1;
  if (qty <= 0) return res.status(400).json({ error: '数量必须大于0' });
  const delta = type === 'in' ? qty : -qty;
  if (p.current_stock + delta < 0) return res.status(400).json({ error: `库存不足！当前: ${p.current_stock}` });
  req.db.prepare('UPDATE products SET current_stock = current_stock + ?, updated_at=datetime("now","localtime") WHERE id = ?').run(delta, p.id);
  req.db.prepare('INSERT INTO stock_movements (product_id,type,quantity,remark) VALUES (?,?,?,?)').run(p.id, type, qty, remark || (type === 'in' ? '扫码入库' : '扫码出库'));
  req.db.prepare('INSERT INTO audit_logs (user_id,action,detail) VALUES (?,?,?)').run(req.session.username, 'scan_'+type, JSON.stringify({product: p.name, qty, new_stock: p.current_stock + delta}));
  res.json({ message: `${type === 'in' ? '入库' : '出库'}成功`, product: p.name, quantity: qty, new_stock: p.current_stock + delta });
});

router.post('/adjust', (req, res) => {
  const { product_id, type, quantity, remark } = req.body;
  if (!product_id || !type || !quantity) return res.status(400).json({ error: '参数不完整' });
  const qty = Number(quantity);
  if (qty <= 0) return res.status(400).json({ error: '数量必须大于0' });
  const delta = type === 'in' ? qty : -qty;
  const p = req.db.prepare('SELECT * FROM products WHERE id = ?').get(Number(product_id));
  if (!p) return res.status(404).json({ error: '产品不存在' });
  if (p.current_stock + delta < 0) return res.status(400).json({ error: `库存不足，当前: ${p.current_stock}` });
  req.db.prepare('UPDATE products SET current_stock = current_stock + ?, updated_at=datetime("now","localtime") WHERE id = ?').run(delta, product_id);
  req.db.prepare('INSERT INTO stock_movements (product_id,type,quantity,remark) VALUES (?,?,?,?)').run(product_id, type, qty, remark || '库存调整');
  res.json({ message: '调整成功', new_stock: p.current_stock + delta });
});

router.post('/stocktake', (req, res) => {
  const { items } = req.body;
  if (!items || !items.length) return res.status(400).json({ error: '请添加盘点项' });
  const results = [];
  const updateStock = req.db.prepare('UPDATE products SET current_stock = ?, updated_at=datetime("now","localtime") WHERE id = ?');
  const insertLog = req.db.prepare('INSERT INTO stock_movements (product_id,type,quantity,remark) VALUES (?,?,?,?)');
  for (const item of items) {
    const actual = Number(item.actual_count);
    if (isNaN(actual) || actual < 0) continue;
    const p = req.db.prepare('SELECT * FROM products WHERE id = ?').get(Number(item.product_id));
    if (!p) continue;
    const diff = actual - p.current_stock;
    if (diff !== 0) {
      updateStock.run(actual, item.product_id);
      insertLog.run(item.product_id, diff > 0 ? 'in' : 'out', Math.abs(diff), `盘点调整: 系统${p.current_stock} -> 实际${actual}`);
    }
    results.push({ product_id: p.id, code: p.code, name: p.name, system_count: p.current_stock, actual_count: actual, diff });
  }
  req.db.prepare('INSERT INTO audit_logs (user_id,action,detail) VALUES (?,?,?)').run(req.session.username, 'stocktake', JSON.stringify({adjusted: results.filter(r=>r.diff!==0).length}));
  res.json({ message: '盘点完成', results });
});

router.get('/report', (req, res) => {
  const db = req.db;
  const total_products = db.prepare('SELECT COUNT(*) as c FROM products WHERE status = 1').get().c;
  const total_stock_value = db.prepare('SELECT COALESCE(SUM(current_stock * cost_price), 0) as v FROM products WHERE status = 1').get().v;
  const total_occupied = db.prepare('SELECT COALESCE(SUM(occupied_stock), 0) as v FROM products WHERE status = 1').get().v;
  const low_stock_count = db.prepare('SELECT COUNT(*) as c FROM products WHERE status = 1 AND current_stock <= min_stock').get().c;
  const out_of_stock = db.prepare('SELECT COUNT(*) as c FROM products WHERE status = 1 AND current_stock = 0').get().c;
  const today_in = db.prepare("SELECT COALESCE(SUM(quantity), 0) as v FROM stock_movements WHERE type = 'in' AND date(created_at) = date('now','localtime')").get().v;
  const today_out = db.prepare("SELECT COALESCE(SUM(quantity), 0) as v FROM stock_movements WHERE type = 'out' AND date(created_at) = date('now','localtime')").get().v;
  const month_in = db.prepare("SELECT COALESCE(SUM(quantity), 0) as v FROM stock_movements WHERE type = 'in' AND created_at >= datetime('now','localtime','start of month')").get().v;
  const month_out = db.prepare("SELECT COALESCE(SUM(quantity), 0) as v FROM stock_movements WHERE type = 'out' AND created_at >= datetime('now','localtime','start of month')").get().v;
  const category_value = db.prepare("SELECT category, COUNT(*) as count, SUM(current_stock) as total_qty, SUM(current_stock * cost_price) as total_value FROM products WHERE status = 1 AND category != '' GROUP BY category ORDER BY total_value DESC").all();
  const trend_7d = [];
  for (let i = 6; i >= 0; i--) {
    const in_v = db.prepare(`SELECT COALESCE(SUM(quantity),0) as v FROM stock_movements WHERE type='in' AND date(created_at)=date('now','localtime','-${i} days')`).get().v;
    const out_v = db.prepare(`SELECT COALESCE(SUM(quantity),0) as v FROM stock_movements WHERE type='out' AND date(created_at)=date('now','localtime','-${i} days')`).get().v;
    const label = db.prepare(`SELECT date('now','localtime','-${i} days') as d`).get().d.slice(5);
    trend_7d.push({ label, in: in_v, out: out_v });
  }
  res.json({ total_products, total_stock_value, total_occupied, low_stock_count, out_of_stock, today_in, today_out, month_in, month_out, category_value, trend_7d });
});

module.exports = router;
