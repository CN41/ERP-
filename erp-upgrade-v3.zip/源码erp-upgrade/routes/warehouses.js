const express = require('express');
const router = express.Router();

// Warehouses
router.get('/', (req, res) => {
  const warehouses = req.db.prepare(`SELECT w.*, 
    (SELECT COUNT(*) FROM products WHERE warehouse_id=w.id AND status=1) as product_count,
    (SELECT COALESCE(SUM(current_stock*cost_price),0) FROM products WHERE warehouse_id=w.id AND status=1) as stock_value
    FROM warehouses w ORDER BY w.id`).all();
  res.json(warehouses);
});

router.post('/', (req, res) => {
  const { name, address } = req.body;
  if (!name || !name.trim()) return res.status(400).json({ error: '仓库名称不能为空' });
  try {
    const r = req.db.prepare('INSERT INTO warehouses (name,address) VALUES (?,?)').run(name.trim(), (address||'').trim());
    res.json({ id: r.lastInsertRowid });
  } catch(e) {
    if (e.message.includes('UNIQUE')) return res.status(400).json({ error: '仓库名称已存在' });
    res.status(400).json({ error: e.message });
  }
});

router.put('/:id', (req, res) => {
  const { name, address, status } = req.body;
  req.db.prepare('UPDATE warehouses SET name=?,address=?,status=? WHERE id=?').run(name, address, Number(status)||1, req.params.id);
  res.json({ message: '更新成功' });
});

// Locations
router.get('/:whId/locations', (req, res) => {
  res.json(req.db.prepare('SELECT * FROM locations WHERE warehouse_id=? ORDER BY name').all(req.params.whId));
});

router.post('/:whId/locations', (req, res) => {
  const { name, shelf, remark } = req.body;
  if (!name || !name.trim()) return res.status(400).json({ error: '库位名称不能为空' });
  const r = req.db.prepare('INSERT INTO locations (warehouse_id,name,shelf,remark) VALUES (?,?,?,?)').run(Number(req.params.whId), name.trim(), (shelf||'').trim(), (remark||'').trim());
  res.json({ id: r.lastInsertRowid });
});

module.exports = router;
