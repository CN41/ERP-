const express = require('express');
const router = express.Router();

// Sales returns
router.get('/sales', (req, res) => {
  const rows = req.db.prepare(`SELECT sr.*, c.name as customer_name, so.order_no as orig_order_no FROM sales_returns sr LEFT JOIN contacts c ON sr.customer_id=c.id LEFT JOIN sales_orders so ON sr.sales_order_id=so.id ORDER BY sr.id DESC`).all();
  res.json(rows);
});

router.post('/sales', (req, res) => {
  const { sales_order_id, items, remark } = req.body;
  if (!items || !items.length) return res.status(400).json({ error: '请添加退货商品' });
  const so = req.db.prepare('SELECT * FROM sales_orders WHERE id=?').get(sales_order_id);
  if (!so) return res.status(404).json({ error: '原销售单不存在' });
  const order_no = 'SR' + Date.now().toString().slice(-8);
  const total = items.reduce((s, i) => s + Number(i.quantity) * Number(i.unit_price), 0);
  const r = req.db.prepare('INSERT INTO sales_returns (order_no,sales_order_id,customer_id,total_amount,remark) VALUES (?,?,?,?,?)')
    .run(order_no, sales_order_id, so.customer_id, total, (remark||'').trim());
  const ins = req.db.prepare('INSERT INTO sales_return_items (return_id,product_id,quantity,unit_price) VALUES (?,?,?,?)');
  items.forEach(i => ins.run(r.lastInsertRowid, Number(i.product_id), Number(i.quantity), Number(i.unit_price)));
  res.json({ id: r.lastInsertRowid, order_no });
});

router.put('/sales/:id/execute', (req, res) => {
  const ret = req.db.prepare('SELECT * FROM sales_returns WHERE id=?').get(req.params.id);
  if (!ret) return res.status(404).json({ error: '未找到' });
  if (ret.status === 'returned') return res.status(400).json({ error: '已退货' });
  const items = req.db.prepare('SELECT * FROM sales_return_items WHERE return_id=?').all(req.params.id);
  const updateStock = req.db.prepare('UPDATE products SET current_stock=current_stock+? WHERE id=?');
  const logIn = req.db.prepare("INSERT INTO stock_movements (product_id,type,quantity,related_order,remark) VALUES (?,'return_in',?,?,?)");
  items.forEach(i => {
    updateStock.run(i.quantity, i.product_id);
    logIn.run(i.product_id, i.quantity, ret.order_no, '销售退货入库');
  });
  req.db.prepare("UPDATE sales_returns SET status='returned' WHERE id=?").run(req.params.id);
  req.db.prepare("INSERT INTO finance_records (type,category,amount,related_order,contact_id,remark) VALUES ('expense','销售退货',?,?,?,'销售退货退款')").run(ret.total_amount, ret.order_no, ret.customer_id);
  res.json({ message: '退货完成' });
});

// Purchase returns
router.get('/purchase', (req, res) => {
  const rows = req.db.prepare(`SELECT pr.*, c.name as supplier_name, po.order_no as orig_order_no FROM purchase_returns pr LEFT JOIN contacts c ON pr.supplier_id=c.id LEFT JOIN purchase_orders po ON pr.purchase_order_id=po.id ORDER BY pr.id DESC`).all();
  res.json(rows);
});

router.post('/purchase', (req, res) => {
  const { purchase_order_id, items, remark } = req.body;
  if (!items || !items.length) return res.status(400).json({ error: '请添加退货物料' });
  const po = req.db.prepare('SELECT * FROM purchase_orders WHERE id=?').get(purchase_order_id);
  if (!po) return res.status(404).json({ error: '原采购单不存在' });
  const order_no = 'PR' + Date.now().toString().slice(-8);
  const total = items.reduce((s, i) => s + Number(i.quantity) * Number(i.unit_price), 0);
  const r = req.db.prepare('INSERT INTO purchase_returns (order_no,purchase_order_id,supplier_id,total_amount,remark) VALUES (?,?,?,?,?)')
    .run(order_no, purchase_order_id, po.supplier_id, total, (remark||'').trim());
  const ins = req.db.prepare('INSERT INTO purchase_return_items (return_id,product_id,quantity,unit_price) VALUES (?,?,?,?)');
  items.forEach(i => ins.run(r.lastInsertRowid, Number(i.product_id), Number(i.quantity), Number(i.unit_price)));
  res.json({ id: r.lastInsertRowid, order_no });
});

router.put('/purchase/:id/execute', (req, res) => {
  const ret = req.db.prepare('SELECT * FROM purchase_returns WHERE id=?').get(req.params.id);
  if (!ret) return res.status(404).json({ error: '未找到' });
  if (ret.status === 'returned') return res.status(400).json({ error: '已退货' });
  const items = req.db.prepare('SELECT * FROM purchase_return_items WHERE return_id=?').all(req.params.id);
  const updateStock = req.db.prepare('UPDATE products SET current_stock=current_stock-? WHERE id=?');
  const logOut = req.db.prepare("INSERT INTO stock_movements (product_id,type,quantity,related_order,remark) VALUES (?,'return_out',?,?,?)");
  for (const i of items) {
    const p = req.db.prepare('SELECT current_stock FROM products WHERE id=?').get(i.product_id);
    if (p.current_stock < i.quantity) return res.status(400).json({ error: '库存不足' });
    updateStock.run(i.quantity, i.product_id);
    logOut.run(i.product_id, i.quantity, ret.order_no, '采购退货出库');
  }
  req.db.prepare("UPDATE purchase_returns SET status='returned' WHERE id=?").run(req.params.id);
  req.db.prepare("INSERT INTO finance_records (type,category,amount,related_order,contact_id,remark) VALUES ('income','采购退货',?,?,?,'采购退货退款')").run(ret.total_amount, ret.order_no, ret.supplier_id);
  res.json({ message: '退货完成' });
});

module.exports = router;
