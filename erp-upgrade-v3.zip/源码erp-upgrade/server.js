const express = require('express');
const path = require('path');
const Database = require('better-sqlite3');
const os = require('os');
const helmet = require('helmet');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const session = require('express-session');
const SQLiteStore = require('connect-sqlite3')(session);

const app = express();
const PORT = process.env.PORT || 3000;
const AUTH_USER = process.env.ERP_USER || 'admin';
const AUTH_PASS = process.env.ERP_PASS || 'admin123';

app.use(helmet({ contentSecurityPolicy: { directives: { defaultSrc: ["'self'"], scriptSrc: ["'self'","'unsafe-inline'","https://unpkg.com"], styleSrc: ["'self'","'unsafe-inline'","https://fonts.googleapis.com"], fontSrc: ["'self'","https://fonts.gstatic.com"], imgSrc: ["'self'","data:","blob:"], connectSrc: ["'self'"] } } }));
app.use(cors({ origin: false }));
app.use(express.json({ limit: '5mb' }));
app.use('/api/', rateLimit({ windowMs: 15*60*1000, max: 300, message: { error: '请求过于频繁' } }));
app.use(session({ store: new SQLiteStore({ dir: path.join(os.homedir(),'.erp-sessions') }), secret: process.env.ERP_SECRET||'erp-secret-change-me', resave: false, saveUninitialized: false, cookie: { maxAge: 86400000, httpOnly: true, sameSite: 'strict' } }));

const dbPath = path.join(os.homedir(), 'erp-data.db');
const db = new Database(dbPath);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
require('./db-init')(db);
app.use((req, res, next) => { req.db = db; next(); });

function requireAuth(req, res, next) {
  if (req.session && req.session.authenticated) return next();
  if (req.path.startsWith('/api/')) return res.status(401).json({ error: '请先登录' });
  res.redirect('/login.html');
}

app.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body;
  if (username === AUTH_USER && password === AUTH_PASS) { req.session.authenticated = true; req.session.username = username; return res.json({ message: '登录成功' }); }
  res.status(401).json({ error: '用户名或密码错误' });
});
app.post('/api/auth/logout', (req, res) => { req.session.destroy(); res.json({ message: '已退出' }); });
app.get('/api/auth/status', (req, res) => { res.json({ authenticated: !!(req.session && req.session.authenticated) }); });
app.get('/login.html', (req, res) => { if (req.session?.authenticated) return res.redirect('/'); res.sendFile(path.join(__dirname,'public','login.html')); });

app.use(express.static(path.join(__dirname, 'public')));
app.use(requireAuth);

app.use('/api/products', require('./routes/products'));
app.use('/api/bom', require('./routes/bom'));
app.use('/api/procurement', require('./routes/procurement'));
app.use('/api/sales', require('./routes/sales'));
app.use('/api/inventory', require('./routes/inventory'));
app.use('/api/contacts', require('./routes/contacts'));
app.use('/api/finance', require('./routes/finance'));
app.use('/api/dashboard', require('./routes/dashboard'));
app.use('/api/production', require('./routes/production'));
app.use('/api/reports', require('./routes/reports'));
app.use('/api/audit', require('./routes/audit'));
app.use('/api/warehouses', require('./routes/warehouses'));
app.use('/api/transfers', require('./routes/transfers'));
app.use('/api/returns', require('./routes/returns'));
app.use('/api/demands', require('./routes/demands'));
app.use('/api/tags', require('./routes/tags'));

app.get('*', (req, res) => { res.sendFile(path.join(__dirname,'public','index.html')); });
app.use((err, req, res, next) => { console.error(err); res.status(500).json({ error: '服务器内部错误' }); });

app.listen(PORT, '0.0.0.0', () => {
  console.log('');
  console.log('  ╔══════════════════════════════════════╗');
  console.log('  ║   ERP 管理系统 v3.0 立创ERP 深度参考  ║');
  console.log('  ║   http://localhost:'+PORT+'              ║');
  console.log('  ╚══════════════════════════════════════╝');
  console.log('');
  console.log('  账号: '+AUTH_USER+' / 密码: '+AUTH_PASS);
  console.log('');
});
