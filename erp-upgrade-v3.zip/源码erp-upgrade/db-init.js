module.exports = function(db) {
  db.exec(`
    -- 仓库
    CREATE TABLE IF NOT EXISTS warehouses (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT UNIQUE NOT NULL,
      address TEXT DEFAULT '',
      status INTEGER DEFAULT 1,
      created_at TEXT DEFAULT (datetime('now','localtime'))
    );

    -- 库位
    CREATE TABLE IF NOT EXISTS locations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      warehouse_id INTEGER NOT NULL,
      name TEXT NOT NULL,
      shelf TEXT DEFAULT '',
      remark TEXT DEFAULT '',
      status INTEGER DEFAULT 1,
      FOREIGN KEY (warehouse_id) REFERENCES warehouses(id)
    );

    -- 产品物料
    CREATE TABLE IF NOT EXISTS products (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      code TEXT UNIQUE NOT NULL,
      name TEXT NOT NULL,
      barcode TEXT DEFAULT '',
      category TEXT DEFAULT '',
      unit TEXT DEFAULT '个',
      spec TEXT DEFAULT '',
      brand TEXT DEFAULT '',
      model TEXT DEFAULT '',
      package TEXT DEFAULT '',
      cost_price REAL DEFAULT 0,
      sale_price REAL DEFAULT 0,
      min_stock INTEGER DEFAULT 0,
      max_stock INTEGER DEFAULT 0,
      current_stock INTEGER DEFAULT 0,
      occupied_stock INTEGER DEFAULT 0,
      auto_replenish INTEGER DEFAULT 0,
      warehouse_id INTEGER,
      location_id INTEGER,
      supplier TEXT DEFAULT '',
      image_url TEXT DEFAULT '',
      remark TEXT DEFAULT '',
      status INTEGER DEFAULT 1,
      created_at TEXT DEFAULT (datetime('now','localtime')),
      updated_at TEXT DEFAULT (datetime('now','localtime')),
      FOREIGN KEY (warehouse_id) REFERENCES warehouses(id),
      FOREIGN KEY (location_id) REFERENCES locations(id)
    );

    -- 批次管理
    CREATE TABLE IF NOT EXISTS batches (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      product_id INTEGER NOT NULL,
      batch_no TEXT NOT NULL,
      quantity REAL NOT NULL DEFAULT 0,
      cost_price REAL DEFAULT 0,
      supplier TEXT DEFAULT '',
      received_date TEXT DEFAULT (datetime('now','localtime')),
      remark TEXT DEFAULT '',
      FOREIGN KEY (product_id) REFERENCES products(id)
    );

    -- BOM
    CREATE TABLE IF NOT EXISTS bom (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT DEFAULT '',
      product_id INTEGER NOT NULL,
      version TEXT DEFAULT 'v1.0',
      status TEXT CHECK(status IN ('draft','approved','disabled')) DEFAULT 'draft',
      remark TEXT DEFAULT '',
      created_at TEXT DEFAULT (datetime('now','localtime'))
    );

    CREATE TABLE IF NOT EXISTS bom_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      bom_id INTEGER NOT NULL,
      material_id INTEGER NOT NULL,
      quantity REAL NOT NULL DEFAULT 1,
      loss_rate REAL DEFAULT 0,
      remark TEXT DEFAULT '',
      FOREIGN KEY (bom_id) REFERENCES bom(id),
      FOREIGN KEY (material_id) REFERENCES products(id)
    );

    -- BOM 替换料
    CREATE TABLE IF NOT EXISTS bom_alternatives (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      bom_item_id INTEGER NOT NULL,
      alt_material_id INTEGER NOT NULL,
      priority INTEGER DEFAULT 1,
      FOREIGN KEY (bom_item_id) REFERENCES bom_items(id),
      FOREIGN KEY (alt_material_id) REFERENCES products(id)
    );

    -- 联系人
    CREATE TABLE IF NOT EXISTS contacts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      type TEXT CHECK(type IN ('customer','supplier','both')) DEFAULT 'customer',
      name TEXT NOT NULL,
      contact_person TEXT DEFAULT '',
      phone TEXT DEFAULT '',
      email TEXT DEFAULT '',
      address TEXT DEFAULT '',
      remark TEXT DEFAULT '',
      status INTEGER DEFAULT 1,
      created_at TEXT DEFAULT (datetime('now','localtime'))
    );

    -- 采购单
    CREATE TABLE IF NOT EXISTS purchase_orders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_no TEXT UNIQUE NOT NULL,
      supplier_id INTEGER,
      source TEXT DEFAULT 'manual',
      total_amount REAL DEFAULT 0,
      paid_amount REAL DEFAULT 0,
      status TEXT CHECK(status IN ('draft','confirmed','partial_received','received','cancelled')) DEFAULT 'draft',
      tag TEXT DEFAULT '',
      remark TEXT DEFAULT '',
      created_at TEXT DEFAULT (datetime('now','localtime')),
      updated_at TEXT DEFAULT (datetime('now','localtime')),
      FOREIGN KEY (supplier_id) REFERENCES contacts(id)
    );

    CREATE TABLE IF NOT EXISTS purchase_order_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_id INTEGER NOT NULL,
      product_id INTEGER NOT NULL,
      quantity REAL NOT NULL,
      received_qty REAL DEFAULT 0,
      unit_price REAL NOT NULL,
      amount REAL GENERATED ALWAYS AS (quantity * unit_price) STORED,
      FOREIGN KEY (order_id) REFERENCES purchase_orders(id),
      FOREIGN KEY (product_id) REFERENCES products(id)
    );

    -- 采购退货单
    CREATE TABLE IF NOT EXISTS purchase_returns (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_no TEXT UNIQUE NOT NULL,
      purchase_order_id INTEGER,
      supplier_id INTEGER,
      total_amount REAL DEFAULT 0,
      status TEXT CHECK(status IN ('draft','confirmed','returned','cancelled')) DEFAULT 'draft',
      remark TEXT DEFAULT '',
      created_at TEXT DEFAULT (datetime('now','localtime')),
      FOREIGN KEY (purchase_order_id) REFERENCES purchase_orders(id),
      FOREIGN KEY (supplier_id) REFERENCES contacts(id)
    );

    CREATE TABLE IF NOT EXISTS purchase_return_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      return_id INTEGER NOT NULL,
      product_id INTEGER NOT NULL,
      quantity REAL NOT NULL,
      unit_price REAL NOT NULL,
      FOREIGN KEY (return_id) REFERENCES purchase_returns(id),
      FOREIGN KEY (product_id) REFERENCES products(id)
    );

    -- 销售单
    CREATE TABLE IF NOT EXISTS sales_orders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_no TEXT UNIQUE NOT NULL,
      customer_id INTEGER,
      total_amount REAL DEFAULT 0,
      paid_amount REAL DEFAULT 0,
      status TEXT CHECK(status IN ('draft','confirmed','partial_shipped','shipped','completed','cancelled')) DEFAULT 'draft',
      tag TEXT DEFAULT '',
      remark TEXT DEFAULT '',
      created_at TEXT DEFAULT (datetime('now','localtime')),
      updated_at TEXT DEFAULT (datetime('now','localtime')),
      FOREIGN KEY (customer_id) REFERENCES contacts(id)
    );

    CREATE TABLE IF NOT EXISTS sales_order_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_id INTEGER NOT NULL,
      product_id INTEGER NOT NULL,
      quantity REAL NOT NULL,
      shipped_qty REAL DEFAULT 0,
      unit_price REAL NOT NULL,
      amount REAL GENERATED ALWAYS AS (quantity * unit_price) STORED,
      FOREIGN KEY (order_id) REFERENCES sales_orders(id),
      FOREIGN KEY (product_id) REFERENCES products(id)
    );

    -- 销售退货单
    CREATE TABLE IF NOT EXISTS sales_returns (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_no TEXT UNIQUE NOT NULL,
      sales_order_id INTEGER,
      customer_id INTEGER,
      total_amount REAL DEFAULT 0,
      status TEXT CHECK(status IN ('draft','confirmed','returned','cancelled')) DEFAULT 'draft',
      remark TEXT DEFAULT '',
      created_at TEXT DEFAULT (datetime('now','localtime')),
      FOREIGN KEY (sales_order_id) REFERENCES sales_orders(id),
      FOREIGN KEY (customer_id) REFERENCES contacts(id)
    );

    CREATE TABLE IF NOT EXISTS sales_return_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      return_id INTEGER NOT NULL,
      product_id INTEGER NOT NULL,
      quantity REAL NOT NULL,
      unit_price REAL NOT NULL,
      FOREIGN KEY (return_id) REFERENCES sales_returns(id),
      FOREIGN KEY (product_id) REFERENCES products(id)
    );

    -- 生产单
    CREATE TABLE IF NOT EXISTS production_orders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_no TEXT UNIQUE NOT NULL,
      product_id INTEGER NOT NULL,
      bom_id INTEGER,
      quantity REAL NOT NULL DEFAULT 1,
      completed_qty REAL DEFAULT 0,
      status TEXT CHECK(status IN ('pending','in_progress','partial_completed','completed','cancelled')) DEFAULT 'pending',
      remark TEXT DEFAULT '',
      created_at TEXT DEFAULT (datetime('now','localtime')),
      updated_at TEXT DEFAULT (datetime('now','localtime')),
      FOREIGN KEY (product_id) REFERENCES products(id)
    );

    CREATE TABLE IF NOT EXISTS production_materials (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      production_id INTEGER NOT NULL,
      material_id INTEGER NOT NULL,
      required_qty REAL NOT NULL,
      consumed_qty REAL DEFAULT 0,
      returned_qty REAL DEFAULT 0,
      FOREIGN KEY (production_id) REFERENCES production_orders(id),
      FOREIGN KEY (material_id) REFERENCES products(id)
    );

    -- 库存调拨
    CREATE TABLE IF NOT EXISTS stock_transfers (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_no TEXT UNIQUE NOT NULL,
      from_warehouse_id INTEGER,
      to_warehouse_id INTEGER,
      status TEXT CHECK(status IN ('draft','confirmed','completed','cancelled')) DEFAULT 'draft',
      remark TEXT DEFAULT '',
      created_at TEXT DEFAULT (datetime('now','localtime')),
      FOREIGN KEY (from_warehouse_id) REFERENCES warehouses(id),
      FOREIGN KEY (to_warehouse_id) REFERENCES warehouses(id)
    );

    CREATE TABLE IF NOT EXISTS stock_transfer_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      transfer_id INTEGER NOT NULL,
      product_id INTEGER NOT NULL,
      quantity REAL NOT NULL,
      FOREIGN KEY (transfer_id) REFERENCES stock_transfers(id),
      FOREIGN KEY (product_id) REFERENCES products(id)
    );

    -- 出入库流水
    CREATE TABLE IF NOT EXISTS stock_movements (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      product_id INTEGER NOT NULL,
      warehouse_id INTEGER,
      type TEXT CHECK(type IN ('in','out','transfer_in','transfer_out','return_in','return_out')) NOT NULL,
      quantity REAL NOT NULL,
      batch_no TEXT DEFAULT '',
      related_order TEXT DEFAULT '',
      remark TEXT DEFAULT '',
      created_at TEXT DEFAULT (datetime('now','localtime')),
      FOREIGN KEY (product_id) REFERENCES products(id)
    );

    -- 财务记录
    CREATE TABLE IF NOT EXISTS finance_records (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      type TEXT CHECK(type IN ('income','expense')) NOT NULL,
      category TEXT DEFAULT '',
      amount REAL NOT NULL,
      related_order TEXT DEFAULT '',
      contact_id INTEGER,
      remark TEXT DEFAULT '',
      created_at TEXT DEFAULT (datetime('now','localtime')),
      FOREIGN KEY (contact_id) REFERENCES contacts(id)
    );

    -- 采购需求（MRP 自动生成）
    CREATE TABLE IF NOT EXISTS purchase_demands (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      product_id INTEGER NOT NULL,
      quantity REAL NOT NULL,
      source TEXT DEFAULT 'manual',
      source_ref TEXT DEFAULT '',
      status TEXT CHECK(status IN ('pending','converted','cancelled')) DEFAULT 'pending',
      created_at TEXT DEFAULT (datetime('now','localtime')),
      FOREIGN KEY (product_id) REFERENCES products(id)
    );

    -- 标签系统
    CREATE TABLE IF NOT EXISTS tags (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT UNIQUE NOT NULL,
      color TEXT DEFAULT '#4f6ef7'
    );

    -- 操作日志
    CREATE TABLE IF NOT EXISTS audit_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id TEXT DEFAULT 'system',
      action TEXT NOT NULL,
      detail TEXT DEFAULT '',
      created_at TEXT DEFAULT (datetime('now','localtime'))
    );
  `);

  // Indexes
  db.exec(`
    CREATE INDEX IF NOT EXISTS idx_products_code ON products(code);
    CREATE INDEX IF NOT EXISTS idx_products_barcode ON products(barcode);
    CREATE INDEX IF NOT EXISTS idx_products_category ON products(category);
    CREATE INDEX IF NOT EXISTS idx_stock_movements_date ON stock_movements(created_at);
    CREATE INDEX IF NOT EXISTS idx_stock_movements_product ON stock_movements(product_id);
    CREATE INDEX IF NOT EXISTS idx_finance_records_date ON finance_records(created_at);
    CREATE INDEX IF NOT EXISTS idx_audit_logs_date ON audit_logs(created_at);
    CREATE INDEX IF NOT EXISTS idx_batches_product ON batches(product_id);
    CREATE INDEX IF NOT EXISTS idx_purchase_demands_status ON purchase_demands(status);
  `);

  // Default warehouse
  const whCount = db.prepare('SELECT COUNT(*) as c FROM warehouses').get().c;
  if (whCount === 0) {
    db.prepare('INSERT INTO warehouses (name, address) VALUES (?,?)').run('主仓库', '默认仓库');
    db.prepare("INSERT INTO tags (name,color) VALUES (?,?), (?,?), (?,?)").run('紧急','#ef4444','VIP','#8b5cf6','待跟进','#f59e0b');
  }

  // Sample data
  const count = db.prepare('SELECT COUNT(*) as c FROM products').get();
  if (count.c === 0) {
    const insP = db.prepare('INSERT INTO products (code,name,category,unit,spec,brand,model,package,cost_price,sale_price,min_stock,max_stock,current_stock,auto_replenish,warehouse_id,barcode) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
    insP.run('R-10K-0805','贴片电阻 10KΩ','电阻','个','0805','Yageo','RC0805FR-0710KL','0805',0.008,0.05,5000,50000,25000,1,1,'40010001');
    insP.run('C-100N-0805','贴片电容 100nF','电容','个','0805','Samsung','CL21B104KBCNNNC','0805',0.015,0.08,3000,30000,15000,1,1,'40020001');
    insP.run('MCU-STM32F103','STM32F103C8T6','芯片','个','LQFP-48','STMicroelectronics','STM32F103C8T6','LQFP-48',7.80,15.00,50,500,200,1,1,'50010001');
    insP.run('PCB-5x5','PCB板 5x5cm','PCB','片','双层 1.0mm','立创打样','','',1.80,5.00,100,1000,500,0,1,'60010001');
    insP.run('DEV-V1.0','开发板 V1.0','成品','块','','自研','','',16.50,35.00,10,200,50,0,1,'70010001');
    insP.run('LED-R-0805','LED红灯 0805','LED','个','0805','Everlight','19-217/R6C-AL1M2VY/3T','0805',0.03,0.10,2000,20000,10000,1,1,'40030001');
    insP.run('IC-REG-3.3V','LDO稳压器 3.3V','电源','个','SOT-23','AMS','AMS1117-3.3','SOT-23',0.25,0.80,200,2000,1000,1,1,'50020001');
    insP.run('CONN-USB-C','USB-C 连接器','连接器','个','','Molex','','',0.50,1.50,100,1000,500,1,1,'50030001');

    // BOM
    const insBom = db.prepare('INSERT INTO bom (name,product_id,version,status) VALUES (?,?,?,?)');
    const bomR = insBom.run('开发板BOM',5,'v1.0','approved');
    const insBomItem = db.prepare('INSERT INTO bom_items (bom_id,material_id,quantity,loss_rate) VALUES (?,?,?,?)');
    insBomItem.run(bomR.lastInsertRowid,1,8,0.02);
    insBomItem.run(bomR.lastInsertRowid,2,6,0.02);
    insBomItem.run(bomR.lastInsertRowid,3,1,0);
    insBomItem.run(bomR.lastInsertRowid,4,1,0);
    insBomItem.run(bomR.lastInsertRowid,6,2,0.05);
    insBomItem.run(bomR.lastInsertRowid,7,1,0);
    insBomItem.run(bomR.lastInsertRowid,8,1,0);

    // Alternative material example
    const lastItems = db.prepare('SELECT id FROM bom_items WHERE bom_id=? ORDER BY id').all(bomR.lastInsertRowid);
    // 假设电阻有替代料
    // db.prepare('INSERT INTO bom_alternatives (bom_item_id,alt_material_id,priority) VALUES (?,?,?)').run(lastItems[0].id, 1, 1);

    const insContact = db.prepare('INSERT INTO contacts (type,name,contact_person,phone,email,address) VALUES (?,?,?,?,?,?)');
    insContact.run('supplier','深圳元器件有限公司','张三','13800001111','zhangsan@example.com','深圳市南山区科技园');
    insContact.run('customer','北京科技公司','李四','13900002222','lisi@example.com','北京市海淀区中关村');
    insContact.run('both','广州电子实业','王五','13700003333','wangwu@example.com','广州市天河区');

    console.log('  [OK] Sample data initialized');
  }
};
