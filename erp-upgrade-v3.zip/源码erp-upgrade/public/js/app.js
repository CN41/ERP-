// ===== Globals =====
let _page='dashboard',_cache={},_scanner=null,_selectedItems=new Set();
const $=s=>document.querySelector(s),$$=s=>document.querySelectorAll(s);
const api=async(u,o={})=>{
  showLoading(true);
  try{
    const r=await fetch(u,{headers:{'Content-Type':'application/json'},...o,body:o.body?JSON.stringify(o.body):undefined});
    if(r.status===401){window.location.href='/login.html';throw new Error('Unauthorized')}
    return r.json()
  }finally{showLoading(false)}
};
const fmt=n=>(n||0).toLocaleString('zh-CN',{minimumFractionDigits:2,maximumFractionDigits:2});
const fmtDate=s=>s?s.replace('T',' ').slice(0,16):'';
const fmtMoney=n=>`¥${fmt(n)}`;
const fmtInt=n=>(n||0).toLocaleString('zh-CN');

function showLoading(show){$('#loading-overlay')?.classList.toggle('show',show)}
function toast(msg,type='success'){
  const el=document.createElement('div');el.className=`toast toast-${type}`;
  const icons={success:'✓',error:'✕',info:'ℹ'};el.innerHTML=`<span>${icons[type]||''}</span><span>${msg}</span>`;
  $('#toast-container').appendChild(el);setTimeout(()=>{el.style.animation='toastOut .3s forwards';setTimeout(()=>el.remove(),300)},2800);
}
function openModal(title,html){$('#modal-title').textContent=title;$('#modal-body').innerHTML=html;$('#modal-overlay').classList.add('show')}
function closeModal(e){if(e&&e.target!==e.currentTarget)return;$('#modal-overlay').classList.remove('show')}
function openScanModal(title,html){$('#scan-modal-title').textContent=title;$('#scan-modal-body').innerHTML=html;$('#scan-modal').classList.add('show')}
function closeScanModal(e){if(e&&e.target!==e.currentTarget)return;stopScanner();$('#scan-modal').classList.remove('show')}
function toggleGlobalSearch(){const w=$('#global-search-wrap');const s=$('#global-search');if(w.style.display==='none'){w.style.display='';s.focus()}else{hideGlobalSearch()}}
function hideGlobalSearch(){$('#global-search-wrap').style.display='none';$('#global-search').value=''}
function showLoading(show){const el=$('#loading-overlay');if(el)el.classList.toggle('show',show)}

// Skeleton HTML generators
function skeletonCards(n=4){return`<div class="stat-grid">${'<div class="stat-card skeleton skeleton-card"></div>'.repeat(n)}</div>`}
function skeletonTable(rows=5){return`<div class="card"><div class="card-body no-pad"><div style="padding:16px">${'<div class="skeleton skeleton-row"></div>'.repeat(rows)}</div></div></div>`}
function pageSkeleton(){return skeletonCards()+skeletonTable()}

// CSV Export
function exportCSV(headers, rows, filename){
  const BOM='\uFEFF';
  const csv=BOM+[headers.join(','),...rows.map(r=>r.map(c=>`"${(c??'').toString().replace(/"/g,'""')}"`).join(','))].join('\n');
  const blob=new Blob([csv],{type:'text/csv;charset=utf-8'});
  const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=filename;a.click();URL.revokeObjectURL(a.href);
  toast('导出成功');
}

// Keyboard shortcuts
document.addEventListener('keydown',e=>{
  if(e.key==='Escape'){closeModal();closeScanModal();hideGlobalSearch()}
  if((e.ctrlKey||e.metaKey)&&e.key==='k'){e.preventDefault();toggleGlobalSearch()}
  if(e.altKey&&e.key==='s'){e.preventDefault();nav('scan')}
  if(e.altKey&&e.key==='n'&&!$('.modal-overlay.show')){e.preventDefault();if(_page==='products')formProduct();else if(_page==='procurement')formPurchase();else if(_page==='sales')formSale()}
});

const statusMap={draft:['草稿','badge-gray'],confirmed:['已确认','badge-primary'],received:['已入库','badge-success'],partial_received:['部分入库','badge-info'],shipped:['已发货','badge-warning'],partial_shipped:['部分发货','badge-info'],completed:['已完成','badge-success'],cancelled:['已取消','badge-danger'],pending:['待生产','badge-gray'],in_progress:['生产中','badge-purple'],partial_completed:['部分完工','badge-info']};
const sb=s=>{const[t,c]=statusMap[s]||[s,'badge-gray'];return`<span class="badge ${c}">${t}</span>`};

// ===== Auth =====
async function logout(){await api('/api/auth/logout',{method:'POST'});window.location.href='/login.html'}

// ===== Navigation Config =====
const NAV_CONFIG = [
  { group:'总览', items:[
    {id:'dashboard',label:'工作台',icon:'<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>'}
  ]},
  { group:'进销存', items:[
    {id:'products',label:'产品物料',icon:'<path d="M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 003 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z"/>'},
    {id:'bom',label:'BOM清单',icon:'<circle cx="12" cy="12" r="3"/><path d="M12 2v4m0 12v4M2 12h4m12 0h4"/>'},
    {id:'procurement',label:'采购管理',icon:'<circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 002 1.61h9.72a2 2 0 002-1.61L23 6H6"/>'},
    {id:'sales',label:'销售管理',icon:'<line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6"/>'},
    {id:'production',label:'生产管理',icon:'<path d="M14.7 6.3a1 1 0 000 1.4l1.6 1.6a1 1 0 001.4 0l3.77-3.77a6 6 0 01-7.94 7.94l-6.91 6.91a2.12 2.12 0 01-3-3l6.91-6.91a6 6 0 017.94-7.94l-3.76 3.76z"/>'},
  ]},
  { group:'库存', items:[
    {id:'inventory',label:'库存管理',icon:'<path d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8"/>',badge:'low-stock-badge'},
    {id:'scan',label:'扫码出入库',icon:'<path d="M3 7V5a2 2 0 012-2h2M17 3h2a2 2 0 012 2v2M21 17v2a2 2 0 01-2 2h-2M7 21H5a2 2 0 01-2-2v-2"/><line x1="7" y1="12" x2="17" y2="12"/>'},
    {id:'stocktake',label:'库存盘点',icon:'<path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11"/>'},
  ]},
  { group:'基础', items:[
    {id:'contacts',label:'客户供应商',icon:'<path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/>'},
    {id:'finance',label:'财务管理',icon:'<rect x="1" y="4" width="22" height="16" rx="2"/><line x1="1" y1="10" x2="23" y2="10"/>'},
  ]},
  { group:'系统', items:[
    {id:'reports',label:'数据报表',icon:'<line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/>'},
    {id:'audit',label:'操作日志',icon:'<path d="M12 8v4l3 3"/><circle cx="12" cy="12" r="10"/>'},
  ]}
];

function buildSidebar(){
  let html='';
  NAV_CONFIG.forEach(g=>{
    html+=`<div class="nav-group"><div class="nav-group-label">${g.group}</div>`;
    g.items.forEach(item=>{
      html+=`<a href="#" class="nav-item" data-page="${item.id}" onclick="nav('${item.id}',this)">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">${item.icon}</svg>
        <span>${item.label}</span>
        ${item.badge?`<span class="nav-badge" id="${item.badge}" style="display:none">0</span>`:''}
      </a>`;
    });
    html+=`</div>`;
  });
  $('#sidebar-nav').innerHTML=html;
}

// ===== Navigation =====
function toggleSidebar(){$('#sidebar').classList.toggle('open')}
function nav(page,el){
  stopScanner();_page=page;
  $$('.nav-item').forEach(n=>n.classList.remove('active'));
  if(el){el.classList.add('active')}else{const n=$$(`[data-page="${page}"]`);if(n.length)n[0].classList.add('active')}
  $('#sidebar').classList.remove('open');
  const titles={dashboard:'工作台',products:'产品物料',bom:'BOM清单',procurement:'采购管理',sales:'销售管理',production:'生产管理',inventory:'库存管理',scan:'扫码出入库',stocktake:'库存盘点',contacts:'客户供应商',finance:'财务管理',reports:'数据报表',audit:'操作日志'};
  $('#page-title').textContent=titles[page]||page;
  updateMobileNav(page);
  const fn={dashboard:pgDashboard,products:pgProducts,bom:pgBom,procurement:pgProcurement,sales:pgSales,production:pgProduction,inventory:pgInventory,scan:pgScan,stocktake:pgStocktake,contacts:pgContacts,finance:pgFinance,reports:pgReports,audit:pgAudit};
  fn[page]?.();
}

// ===== SVG Barcode =====
function barcodeSVG(code,w=200,h=60){
  if(!code)return'';const bars=[];let x=10;
  for(let i=0;i<code.length;i++){const c=code.charCodeAt(i);for(let b=0;b<8;b++){if((c>>b)&1){bars.push(`<rect x="${x}" y="2" width="2" height="${h-12}" fill="#1e293b"/>`);x+=2}else{x+=1}}x+=1}
  return`<svg width="${Math.max(x+10,w)}" height="${h}" xmlns="http://www.w3.org/2000/svg">${bars.join('')}<text x="${x/2}" y="${h-2}" text-anchor="middle" font-size="11" font-family="monospace" fill="#1e293b">${code}</text></svg>`;
}

// ===== Charts =====
function barChart(data,maxVal){
  if(!data||!data.length)return'<div class="text-hint text-center">暂无数据</div>';
  const mv=maxVal||Math.max(...data.map(d=>Math.max(d.in||0,d.out||0)),1);
  return`<div class="chart-bar-group">${data.map(d=>{const ih=Math.max(2,(d.in/mv)*160),oh=Math.max(2,(d.out/mv)*160);return`<div class="chart-bar-wrap"><div class="chart-value">${d.in||d.out?fmtInt(Math.max(d.in||0,d.out||0)):''}</div><div style="display:flex;gap:2px;align-items:flex-end;height:160px"><div class="chart-bar income" style="height:${ih}px;width:14px"></div><div class="chart-bar expense" style="height:${oh}px;width:14px"></div></div><div class="chart-label">${d.label}</div></div>`}).join('')}</div><div class="chart-legend"><div class="chart-legend-item"><div class="chart-legend-dot" style="background:var(--success)"></div>入库</div><div class="chart-legend-item"><div class="chart-legend-dot" style="background:var(--danger)"></div>出库</div></div>`;
}

function ringChart(income,expense){
  const total=income+expense||1,r=55,c=2*Math.PI*r;
  const iD=(income/total)*c,eD=(expense/total)*c;
  return`<circle cx="70" cy="70" r="${r}" fill="none" stroke="#e2e8f0" stroke-width="16"/><circle cx="70" cy="70" r="${r}" fill="none" stroke="var(--success)" stroke-width="16" stroke-dasharray="${iD} ${c}" stroke-linecap="round"/><circle cx="70" cy="70" r="${r}" fill="none" stroke="var(--danger)" stroke-width="16" stroke-dasharray="${eD} ${c}" stroke-dashoffset="${-iD}" stroke-linecap="round"/>`;
}

// ===== Dashboard =====
async function pgDashboard(){
  $('#page-content').innerHTML=pageSkeleton();
  const[d,r]=await Promise.all([api('/api/dashboard'),api('/api/inventory/report')]);
  const lb=$('#low-stock-badge');if(lb){lb.style.display=d.low_stock>0?'':'none';lb.textContent=d.low_stock}
  const actHtml=(d.recent_activities||[]).map(a=>{
    const dot=a.action.includes('create')||a.action.includes('scan_in')?'create':a.action.includes('delete')?'delete':'update';
    return`<li class="activity-item"><div class="activity-dot ${dot}"></div><div style="flex:1"><div><strong>${a.user_id}</strong> ${a.action}</div><div class="text-hint text-xs">${fmtDate(a.created_at)}</div></div></li>`;
  }).join('')||'<li class="activity-item text-hint">暂无操作记录</li>';
  // Finance donut calc
  const finTotal=d.monthly_income+d.monthly_expense||1;
  const finPct=d.monthly_income/finTotal*100;
  $('#page-content').innerHTML=`
    <div class="stat-grid">
      <div class="stat-card blue"><div class="stat-icon">📦</div><div class="stat-label">产品物料</div><div class="stat-value">${d.product_count}</div><div class="stat-footer"><div class="stock-bar" style="flex:1"><div class="progress-bar"><div class="progress-fill blue" style="width:${Math.min(100,d.product_count*2)}%"></div></div></div> 库存价值 ${fmtMoney(r.total_stock_value)}</div></div>
      <div class="stat-card ${d.low_stock>0?'red':'green'}"><div class="stat-icon">⚠️</div><div class="stat-label">库存预警</div><div class="stat-value">${d.low_stock}</div><div class="stat-footer">${d.pending_demands?`<span class="badge badge-warning">${d.pending_demands} 条需求</span>`:''} ${r.out_of_stock>0?`缺货${r.out_of_stock}种`:'库存充足'}</div></div>
      <div class="stat-card orange"><div class="stat-icon">🛒</div><div class="stat-label">待处理</div><div class="stat-value">${d.pending_purchase+d.pending_sales+d.pending_production}</div><div class="stat-footer">采购${d.pending_purchase} · 销售${d.pending_sales} · 生产${d.pending_production}</div></div>
      <div class="stat-card ${d.monthly_profit>=0?'green':'red'}"><div class="stat-icon">💰</div><div class="stat-label">本月利润</div><div class="stat-value">${fmtMoney(d.monthly_profit)}</div><div class="stat-footer"><div class="progress-bar" style="flex:1"><div class="progress-fill ${finPct>=50?'green':'orange'}" style="width:${Math.min(100,finPct)}%"></div></div> 收${fmtMoney(d.monthly_income)}</div></div>
    </div>
    <div class="dashboard-grid">
      <div class="card"><div class="card-header"><h3>📊 本月收支</h3></div><div class="card-body">
        <div class="chart-ring"><svg class="ring-svg" width="140" height="140" viewBox="0 0 140 140">${ringChart(d.monthly_income,d.monthly_expense)}</svg>
          <div class="ring-legend">
            <div class="ring-legend-item"><div class="ring-legend-dot" style="background:var(--success)"></div>收入 ${fmtMoney(d.monthly_income)}</div>
            <div class="ring-legend-item"><div class="ring-legend-dot" style="background:var(--danger)"></div>支出 ${fmtMoney(d.monthly_expense)}</div>
            <div class="ring-legend-item" style="margin-top:4px;font-weight:700">利润 ${fmtMoney(d.monthly_profit)}</div>
          </div></div>
      </div></div>
      <div class="card"><div class="card-header"><h3>📈 7日出入库趋势</h3></div><div class="card-body">
        ${barChart(r.trend_7d,Math.max(...(r.trend_7d||[]).map(t=>Math.max(t.in,t.out)),1))}
      </div></div>
    </div>
    <div class="dashboard-grid">
      <div class="card"><div class="card-header"><h3>📋 最近订单</h3><button class="btn btn-ghost btn-xs" onclick="exportOrders()">导出</button></div><div class="card-body no-pad">
        ${d.recent_orders.length?`<table><thead><tr><th>类型</th><th>单号</th><th>金额</th><th>状态</th><th>时间</th></tr></thead><tbody>
          ${d.recent_orders.map(o=>`<tr><td>${o.type==='purchase'?'<span class="badge badge-info">采购</span>':'<span class="badge badge-warning">销售</span>'}</td><td class="fw-600">${o.order_no}</td><td class="money">${fmtMoney(o.total_amount)}</td><td>${sb(o.status)}</td><td class="text-hint text-sm">${fmtDate(o.created_at)}</td></tr>`).join('')}
        </tbody></table>`:'<div class="empty-state"><div class="empty-state-icon">📋</div><h3>暂无订单</h3><p>创建第一个采购或销售订单开始使用</p><button class="btn btn-primary" onclick="nav(\'procurement\')">新建采购单</button></div>'}
      </div></div>
      <div class="card"><div class="card-header"><h3>🕐 最近操作</h3><span class="text-hint text-xs">快捷键: <span class="kbd">Ctrl+K</span> 搜索</span></div><div class="card-body no-pad" style="padding:12px 16px">
        <ul class="activity-list">${actHtml}</ul>
      </div></div>
    </div>
    <div class="card"><div class="card-header"><h3>📦 库存价值分布</h3></div><div class="card-body">
      ${(r.category_value||[]).length?`<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:12px">${r.category_value.map(c=>{
        const pct=(c.total_value/r.category_value.reduce((s,x)=>s+x.total_value,0)*100);
        return`<div style="padding:12px;background:var(--border-light);border-radius:8px"><div style="font-weight:700;font-size:13px;margin-bottom:4px">${c.category}</div><div style="font-size:12px;color:var(--text-sec)">${c.count} 种 · ${fmtInt(c.total_qty)} 件</div><div style="font-size:16px;font-weight:800;color:var(--primary);margin-top:4px">${fmtMoney(c.total_value)}</div><div class="progress-bar" style="margin-top:6px"><div class="progress-fill blue" style="width:${pct}%"></div></div></div>`;
      }).join('')}</div>`:'<div class="empty-state"><div class="empty-state-icon">📊</div><h3>暂无分类数据</h3><p>添加产品并设置分类后显示</p></div>'}
    </div></div>`;
}

// ===== Products =====
async function pgProducts(){
  $('#page-content').innerHTML=pageSkeleton();
  const result=await api('/api/products');
  const p=result.data||result;_cache.products=p;
  const cats=await api('/api/products/categories');
  $('#page-content').innerHTML=`
    <div class="toolbar">
      <div class="search-box"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
        <input placeholder="搜索编号/名称/条码/品牌/型号... (Alt+N 新增)" oninput="filterProducts()"></div>
      <select class="form-select" style="width:auto;padding:8px 12px;border-radius:8px" onchange="filterProducts()"><option value="">全部分类</option>${cats.map(c=>`<option value="${c}">${c}</option>`).join('')}</select>
      <button class="btn btn-primary" onclick="formProduct()"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>新增物料</button>
      <button class="btn btn-export" onclick="exportProducts()">📥 导出CSV</button>
    </div>
    <div class="filter-pills">
      <div class="filter-pill active" onclick="filterProductsPill(this,'')">全部 (${p.length})</div>
      <div class="filter-pill" onclick="filterProductsPill(this,'low')">⚠️ 库存不足</div>
      <div class="filter-pill" onclick="filterProductsPill(this,'out')">❌ 缺货</div>
    </div>
    <div class="card">
      <div class="card-body no-pad">
        <div class="table-wrapper desktop-table"><table>
          <thead><tr><th class="sortable" onclick="sortProducts('code')">编号</th><th>条码</th><th class="sortable" onclick="sortProducts('name')">名称</th><th>品牌</th><th>分类</th><th>规格</th><th>单位</th><th class="sortable" onclick="sortProducts('cost_price')">成本</th><th class="sortable" onclick="sortProducts('sale_price')">售价</th><th class="sortable" onclick="sortProducts('current_stock')">库存</th><th>可用</th><th>库位</th><th>操作</th></tr></thead>
          <tbody id="pt-body">${prodRows(p)}</tbody>
        </table></div>
        <div class="mobile-cards" id="pt-mobile">${prodMobileCards(p)}</div>
      </div>
    </div>`;
}
function stockBarHTML(current,min,max){
  const pct=max>0?Math.min(100,current/max*100):Math.min(100,current/(min*2||1)*100);
  const cls=current<=min?'red':current<=min*1.5?'orange':'green';
  return`<div class="stock-bar"><div class="progress-bar"><div class="progress-fill ${cls}" style="width:${pct}%"></div></div><span class="text-xs" style="min-width:30px">${current}</span></div>`;
}
function prodRows(items){return items.map(p=>{const avail=p.available_stock??(p.current_stock-(p.occupied_stock||0));
  return`<tr><td class="fw-600">${p.code}</td><td class="text-hint text-xs" style="font-family:monospace">${p.barcode||'-'}</td><td>${p.name}</td><td class="text-muted">${p.brand||'-'}</td><td class="text-muted">${p.category||'-'}</td><td class="text-muted">${p.spec||'-'}</td><td>${p.unit}</td><td class="money">${fmtMoney(p.cost_price)}</td><td class="money">${fmtMoney(p.sale_price)}</td><td>${stockBarHTML(p.current_stock,p.min_stock,p.max_stock||p.min_stock*2)}</td><td class="fw-600 ${avail<=0?'text-danger':''}">${avail}</td><td class="text-hint text-xs">${p.location_name||p.location||'-'}</td><td class="nowrap"><button class="btn btn-ghost btn-xs" onclick="formProduct(${p.id})" title="编辑">✏️</button><button class="btn btn-ghost btn-xs" onclick="showBarcode(${p.id})" title="条码">🏷️</button><button class="btn btn-ghost btn-xs" onclick="delProduct(${p.id})" title="删除">🗑️</button></td></tr>`}).join('')||'<tr><td colspan="13" class="table-empty">暂无数据</td></tr>'}
function prodMobileCards(items){return items.map(p=>{const avail=p.available_stock??(p.current_stock-(p.occupied_stock||0));const low=p.current_stock<=p.min_stock;
  return`<div class="mobile-card" onclick="formProduct(${p.id})"><div class="mobile-card-header"><div class="mobile-card-title">${p.name}</div>${low?'<span class="badge badge-danger">偏低</span>':avail<=0?'<span class="badge badge-danger">缺货</span>':'<span class="badge badge-success">正常</span>'}</div><div class="mobile-card-body"><div><span class="mobile-card-label">编号</span> <span class="fw-600">${p.code}</span></div><div><span class="mobile-card-label">品牌</span> ${p.brand||'-'}</div><div><span class="mobile-card-label">库存</span> <span class="fw-700 ${low?'':''}">${p.current_stock}</span> / ${p.min_stock}</div><div><span class="mobile-card-label">可用</span> <span class="fw-600">${avail}</span></div><div><span class="mobile-card-label">成本</span> ${fmtMoney(p.cost_price)}</div><div><span class="mobile-card-label">售价</span> ${fmtMoney(p.sale_price)}</div></div></div>`}).join('')||'<div class="empty-state"><div class="empty-state-icon">📦</div><h3>暂无产品</h3><p>点击右上角新增第一个物料</p></div>'}
async function filterProducts(){const kw=$('.search-box input').value,cat=$('.form-select').value;let u='/api/products?';if(kw)u+=`keyword=${encodeURIComponent(kw)}&`;if(cat)u+=`category=${encodeURIComponent(cat)}&`;const r=await api(u);const items=r.data||r;$('#pt-body').innerHTML=prodRows(items);$('#pt-mobile').innerHTML=prodMobileCards(items)}
function filterProductsPill(el,type){
  el.parentElement.querySelectorAll('.filter-pill').forEach(p=>p.classList.remove('active'));el.classList.add('active');
  const items=_cache.products||[];
  let filtered=items;
  if(type==='low')filtered=items.filter(p=>p.current_stock<=p.min_stock&&p.current_stock>0);
  if(type==='out')filtered=items.filter(p=>p.current_stock===0);
  $('#pt-body').innerHTML=prodRows(filtered);$('#pt-mobile').innerHTML=prodMobileCards(filtered);
}
let _sortField='',_sortDir='asc';
function sortProducts(field){
  if(_sortField===field)_sortDir=_sortDir==='asc'?'desc':'asc';else{_sortField=field;_sortDir='asc'}
  const items=[...(_cache.products||[])];items.sort((a,b)=>{const va=a[field]||0,vb=b[field]||0;return _sortDir==='asc'?(va>vb?1:-1):(va<vb?1:-1)});
  $$('.sortable').forEach(th=>{th.classList.remove('asc','desc');if(th.textContent.includes(field==='code'?'编号':field==='name'?'名称':field==='cost_price'?'成本':field==='sale_price'?'售价':'库存'))th.classList.add(_sortDir)});
  $('#pt-body').innerHTML=prodRows(items);$('#pt-mobile').innerHTML=prodMobileCards(items);
}
function exportProducts(){
  const items=_cache.products||[];
  exportCSV(['编号','条码','名称','品牌','分类','规格','单位','成本价','售价','最低库存','当前库存','可用库存','库位'],
    items.map(p=>[p.code,p.barcode,p.name,p.brand,p.category,p.spec,p.unit,p.cost_price,p.sale_price,p.min_stock,p.current_stock,p.available_stock??(p.current_stock-(p.occupied_stock||0)),p.location_name||p.location]),
    `产品列表_${new Date().toISOString().slice(0,10)}.csv`);
}
function exportOrders(){
  const orders=_cache.recentOrders||[];
  exportCSV(['类型','单号','金额','状态','时间'],
    orders.map(o=>[o.type==='purchase'?'采购':'销售',o.order_no,o.total_amount,o.status,fmtDate(o.created_at)]),
    `订单列表_${new Date().toISOString().slice(0,10)}.csv`);
}

async function showBarcode(id){
  const p=await api(`/api/products/${id}`);const bc=p.barcode||p.code;
  openModal('产品条码 - '+p.name,`<div class="text-center mb-20"><div style="padding:20px;background:#fff;border:2px solid var(--border);border-radius:12px;display:inline-block">${barcodeSVG(bc,280,80)}</div><div class="text-sm text-muted mt-12">${p.code} - ${p.name}</div><div class="text-sm text-muted">条码: ${bc}</div></div><div class="text-center"><button class="btn btn-outline" onclick="printBarcode('${bc}','${p.code} - ${p.name}')">🖨️ 打印条码</button></div><div style="padding:16px 24px;border-top:1px solid var(--border);display:flex;justify-content:flex-end"><button class="btn btn-outline" onclick="closeModal()">关闭</button></div>`);
}
function printBarcode(bc,name){const w=window.open('','_blank','width=400,height=200');w.document.write(`<html><body style="display:flex;flex-direction:column;align-items:center;justify-content:center;height:100vh;margin:0">${barcodeSVG(bc,300,80)}<div style="font-size:12px;margin-top:8px">${name}</div></body></html>`);w.document.close();w.print()}

async function formProduct(id){
  const p=id?await api(`/api/products/${id}`):{};
  openModal(id?'编辑物料':'新增物料',`
    <form onsubmit="saveProduct(event,${id||'null'})">
      <div class="form-row"><div class="form-group"><label class="form-label">物料编号 *</label><input class="form-input" name="code" value="${p.code||''}" required></div><div class="form-group"><label class="form-label">物料名称 *</label><input class="form-input" name="name" value="${p.name||''}" required></div></div>
      <div class="form-row"><div class="form-group"><label class="form-label">条码</label><input class="form-input" name="barcode" value="${p.barcode||''}" placeholder="扫描或手动输入"><div class="form-hint">用于扫码出入库</div></div><div class="form-group"><label class="form-label">分类</label><input class="form-input" name="category" value="${p.category||''}"></div></div>
      <div class="form-row"><div class="form-group"><label class="form-label">品牌</label><input class="form-input" name="brand" value="${p.brand||''}" placeholder="如：ST、Yageo"></div><div class="form-group"><label class="form-label">型号</label><input class="form-input" name="model" value="${p.model||''}" placeholder="如：STM32F103C8T6"></div></div>
      <div class="form-row"><div class="form-group"><label class="form-label">规格</label><input class="form-input" name="spec" value="${p.spec||''}"></div><div class="form-group"><label class="form-label">单位</label><input class="form-input" name="unit" value="${p.unit||'个'}"></div></div>
      <div class="form-row"><div class="form-group"><label class="form-label">成本价 (¥)</label><input class="form-input" type="number" step="0.0001" name="cost_price" value="${p.cost_price||0}"></div><div class="form-group"><label class="form-label">售价 (¥)</label><input class="form-input" type="number" step="0.0001" name="sale_price" value="${p.sale_price||0}"></div></div>
      <div class="form-row"><div class="form-group"><label class="form-label">最低库存</label><input class="form-input" type="number" name="min_stock" value="${p.min_stock||0}"></div><div class="form-group"><label class="form-label">当前库存${id?'':' (自动)'}</label><input class="form-input" type="number" name="current_stock" value="${p.current_stock||0}" ${id?'':'disabled'}></div></div>
      <div class="form-row"><div class="form-group"><label class="form-label">库位</label><input class="form-input" name="location" value="${p.location||''}" placeholder="如：A-01-01"></div><div class="form-group"><label class="form-label">供应商</label><input class="form-input" name="supplier" value="${p.supplier||''}"></div></div>
      <div class="form-group"><label class="form-label">备注</label><textarea class="form-textarea" name="remark" rows="2">${p.remark||''}</textarea></div>
      <div style="padding:16px 24px;border-top:1px solid var(--border);display:flex;justify-content:flex-end;gap:10px"><button type="button" class="btn btn-outline" onclick="closeModal()">取消</button><button type="submit" class="btn btn-primary">保存</button></div>
    </form>`);
}
async function saveProduct(e,id){e.preventDefault();const d=Object.fromEntries(new FormData(e.target));['cost_price','sale_price','min_stock','current_stock'].forEach(k=>d[k]=Number(d[k])||0);d.status=1;await api(id?`/api/products/${id}`:'/api/products',{method:id?'PUT':'POST',body:d});closeModal();toast(id?'更新成功':'添加成功');pgProducts()}
async function delProduct(id){if(!confirm('确定删除此物料？'))return;await api(`/api/products/${id}`,{method:'DELETE'});toast('已删除');pgProducts()}

// ===== BOM =====
async function pgBom(){
  const[bom,prods]=await Promise.all([api('/api/bom'),api('/api/products')]);_cache.products=prods.data||prods;
  const grp={};bom.forEach(b=>{if(!grp[b.product_id])grp[b.product_id]={code:b.product_code,name:b.product_name,items:[]};grp[b.product_id].items.push(b)});
  const entries=Object.entries(grp);
  $('#page-content').innerHTML=`
    <div class="toolbar"><button class="btn btn-primary" onclick="formBom()">+ 添加BOM项</button></div>
    ${entries.length?entries.map(([pid,g])=>{const tc=g.items.reduce((s,i)=>s+i.quantity*i.material_cost,0);
      return`<div class="bom-card"><div class="bom-header" onclick="this.nextElementSibling.style.display=this.nextElementSibling.style.display==='none'?'':'none'"><div class="bom-product-name">📦 ${g.code} - ${g.name}</div><div><span class="text-sm text-muted">共${g.items.length}项 · 总成本 <strong style="color:var(--primary)">${fmtMoney(tc)}</strong></span></div></div><div class="bom-body"><table><thead><tr><th>物料编号</th><th>物料名称</th><th>用量</th><th>单位</th><th>单价</th><th>小计</th><th></th></tr></thead><tbody>${g.items.map(i=>`<tr><td>${i.material_code}</td><td class="fw-600">${i.material_name}</td><td>${i.quantity}</td><td>${i.material_unit}</td><td class="money">${fmtMoney(i.material_cost)}</td><td class="money fw-600">${fmtMoney(i.quantity*i.material_cost)}</td><td><button class="btn btn-ghost btn-xs" onclick="delBom(${i.id})">🗑️</button></td></tr>`).join('')}</tbody></table></div></div>`}).join(''):'<div class="card"><div class="card-body"><div class="empty"><p>暂无BOM数据</p></div></div></div>'}`;
}
async function formBom(){const prods=_cache.products||await api('/api/products');
  openModal('添加BOM项',`<form onsubmit="saveBom(event)"><div class="form-group"><label class="form-label">成品 *</label><select class="form-select" name="product_id" required><option value="">选择成品...</option>${prods.map(p=>`<option value="${p.id}">${p.code} - ${p.name}</option>`).join('')}</select></div><div class="form-group"><label class="form-label">原材料 *</label><select class="form-select" name="material_id" required><option value="">选择原材料...</option>${prods.map(p=>`<option value="${p.id}">${p.code} - ${p.name} (${fmtMoney(p.cost_price)}/${p.unit})</option>`).join('')}</select></div><div class="form-row"><div class="form-group"><label class="form-label">用量 *</label><input class="form-input" type="number" step="0.01" name="quantity" value="1" required></div><div class="form-group"><label class="form-label">备注</label><input class="form-input" name="remark"></div></div><div style="padding:16px 24px;border-top:1px solid var(--border);display:flex;justify-content:flex-end;gap:10px"><button type="button" class="btn btn-outline" onclick="closeModal()">取消</button><button type="submit" class="btn btn-primary">添加</button></div></form>`)}
async function saveBom(e){e.preventDefault();const d=Object.fromEntries(new FormData(e.target));d.product_id=+d.product_id;d.material_id=+d.material_id;d.quantity=+d.quantity;await api('/api/bom',{method:'POST',body:d});closeModal();toast('添加成功');pgBom()}
async function delBom(id){if(!confirm('确定删除？'))return;await api(`/api/bom/${id}`,{method:'DELETE'});toast('已删除');pgBom()}

// ===== Contacts =====
async function pgContacts(){
  const result=await api('/api/contacts');const cs=result.data||result;_cache.contacts=cs;
  const tm={customer:['客户','badge-primary'],supplier:['供应商','badge-warning'],both:['兼','badge-success']};
  const row=c=>{const[t,cl]=tm[c.type]||['未知','badge-gray'];return`<tr><td><span class="badge ${cl}">${t}</span></td><td class="fw-600">${c.name}</td><td>${c.contact_person||'-'}</td><td>${c.phone||'-'}</td><td class="text-muted">${c.email||'-'}</td><td class="nowrap"><button class="btn btn-ghost btn-xs" onclick="formContact(${c.id})">✏️</button><button class="btn btn-ghost btn-xs" onclick="delContact(${c.id})">🗑️</button></td></tr>`};
  $('#page-content').innerHTML=`<div class="toolbar"><div class="search-box"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg><input placeholder="搜索..." oninput="filterContacts()"></div><div class="tabs" id="ct-tabs" style="margin:0"><div class="tab active" onclick="filterContacts('')">全部</div><div class="tab" onclick="filterContacts('customer')">客户</div><div class="tab" onclick="filterContacts('supplier')">供应商</div></div><button class="btn btn-primary" onclick="formContact()">+ 新增</button></div><div class="card"><div class="card-body no-pad"><div class="table-wrapper"><table><thead><tr><th>类型</th><th>名称</th><th>联系人</th><th>电话</th><th>邮箱</th><th>操作</th></tr></thead><tbody id="ct-body">${cs.map(row).join('')}</tbody></table></div></div></div>`}
async function filterContacts(type){const kw=$('#page-content .search-box input')?.value||'';let u='/api/contacts?';if(type!==undefined&&type!==''){u+=`type=${type}&`;const tabs=$('#ct-tabs');if(tabs)tabs.querySelectorAll('.tab').forEach((t,i)=>t.classList.toggle('active',['','customer','supplier'][i]===type))}if(kw)u+=`keyword=${encodeURIComponent(kw)}&`;const r=await api(u);const cs=r.data||r;const tm={customer:['客户','badge-primary'],supplier:['供应商','badge-warning'],both:['兼','badge-success']};const row=c=>{const[t,cl]=tm[c.type]||['未知','badge-gray'];return`<tr><td><span class="badge ${cl}">${t}</span></td><td class="fw-600">${c.name}</td><td>${c.contact_person||'-'}</td><td>${c.phone||'-'}</td><td class="text-muted">${c.email||'-'}</td><td class="nowrap"><button class="btn btn-ghost btn-xs" onclick="formContact(${c.id})">✏️</button><button class="btn btn-ghost btn-xs" onclick="delContact(${c.id})">🗑️</button></td></tr>`};$('#ct-body').innerHTML=cs.map(row).join('')||'<tr><td colspan="6" class="table-empty">暂无</td></tr>'}
async function formContact(id){const c=id?(_cache.contacts||[]).find(x=>x.id===id)||{}:{};openModal(id?'编辑':'新增客户/供应商',`<form onsubmit="saveContact(event,${id||'null'})"><div class="form-row"><div class="form-group"><label class="form-label">类型 *</label><select class="form-select" name="type" required><option value="customer" ${c.type==='customer'?'selected':''}>客户</option><option value="supplier" ${c.type==='supplier'?'selected':''}>供应商</option><option value="both" ${c.type==='both'?'selected':''}>兼</option></select></div><div class="form-group"><label class="form-label">名称 *</label><input class="form-input" name="name" value="${c.name||''}" required></div></div><div class="form-row"><div class="form-group"><label class="form-label">联系人</label><input class="form-input" name="contact_person" value="${c.contact_person||''}"></div><div class="form-group"><label class="form-label">电话</label><input class="form-input" name="phone" value="${c.phone||''}"></div></div><div class="form-row"><div class="form-group"><label class="form-label">邮箱</label><input class="form-input" name="email" value="${c.email||''}"></div><div class="form-group"><label class="form-label">地址</label><input class="form-input" name="address" value="${c.address||''}"></div></div><div class="form-group"><label class="form-label">备注</label><textarea class="form-textarea" name="remark">${c.remark||''}</textarea></div><div style="padding:16px 24px;border-top:1px solid var(--border);display:flex;justify-content:flex-end;gap:10px"><button type="button" class="btn btn-outline" onclick="closeModal()">取消</button><button type="submit" class="btn btn-primary">保存</button></div></form>`)}
async function saveContact(e,id){e.preventDefault();const d=Object.fromEntries(new FormData(e.target));if(id)d.status=1;await api(id?`/api/contacts/${id}`:'/api/contacts',{method:id?'PUT':'POST',body:d});closeModal();toast(id?'更新成功':'添加成功');pgContacts()}
async function delContact(id){if(!confirm('确定删除？'))return;await api(`/api/contacts/${id}`,{method:'DELETE'});toast('已删除');pgContacts()}

// ===== Procurement =====
let _poItems=[];
async function pgProcurement(){
  $('#page-content').innerHTML=pageSkeleton();
  const orders=await api('/api/procurement');
  $('#page-content').innerHTML=`<div class="toolbar"><div class="search-box"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg><input placeholder="搜索单号/供应商..." oninput="filterPO(this.value)"></div><button class="btn btn-primary" onclick="formPurchase()">+ 新建采购单</button><button class="btn btn-export" onclick="exportPO()">📥 导出</button></div><div class="filter-pills"><div class="filter-pill active" onclick="filterPOStatus(this,'')">全部</div><div class="filter-pill" onclick="filterPOStatus(this,'draft')">草稿</div><div class="filter-pill" onclick="filterPOStatus(this,'confirmed')">已确认</div><div class="filter-pill" onclick="filterPOStatus(this,'partial_received')">部分入库</div><div class="filter-pill" onclick="filterPOStatus(this,'received')">已入库</div></div><div class="card"><div class="card-body no-pad"><div class="table-wrapper desktop-table"><table><thead><tr><th>单号</th><th>供应商</th><th>金额</th><th>已付</th><th>状态</th><th>时间</th><th>操作</th></tr></thead><tbody id="po-body">${poRows(orders)}</tbody></table></div><div class="mobile-cards" id="po-mobile">${poMobileCards(orders)}</div></div></div>`;
  _cache.poAll=orders;
}
function paymentBadge(paid,total){
  if(!total)return'';
  const pct=Math.round(paid/total*100);
  const cls=pct>=100?'badge-success':pct>0?'badge-info':'badge-gray';
  return`<span class="badge ${cls}">${pct>=100?'已结清':fmtMoney(paid)+' ('+pct+'%)'}</span>`;
}
function poRows(orders){return orders.length?orders.map(o=>{const sf=s=>{const f=['draft','confirmed','received'],l=['草稿','已确认','已入库'],i=f.indexOf(s);if(s==='partial_received')return'<span class="status-step done">已确认</span><span class="status-arrow">›</span><span class="status-step current">部分入库</span>';return f.map((_,j)=>`<span class="status-step ${j<i?'done':j===i?'current':'pending'}">${l[j]}</span>${j<f.length-1?'<span class="status-arrow">›</span>':''}`).join('')};return`<tr><td class="fw-600">${o.order_no}</td><td>${o.supplier_name||'-'}</td><td class="money fw-600">${fmtMoney(o.total_amount)}</td><td>${paymentBadge(o.paid_amount,o.total_amount)}</td><td><div class="status-flow">${sf(o.status)}</div></td><td class="text-hint text-sm">${fmtDate(o.created_at)}</td><td class="nowrap"><button class="btn btn-ghost btn-xs" onclick="viewPO(${o.id})">详情</button>${o.status==='draft'?`<button class="btn btn-primary btn-xs" onclick="updPO(${o.id},'confirmed')">确认</button><button class="btn btn-ghost btn-xs" onclick="delPO(${o.id})">删除</button>`:''}${['confirmed','partial_received'].includes(o.status)?`<button class="btn btn-success btn-xs" onclick="receivePO(${o.id})">入库</button>`:''}${o.paid_amount<o.total_amount&&o.status!=='draft'&&o.status!=='cancelled'?`<button class="btn btn-outline btn-xs" onclick="payPO(${o.id},${o.total_amount-o.paid_amount})">付款</button>`:''}</td></tr>`}).join(''):'<tr><td colspan="7" class="table-empty">暂无采购单</td></tr>'}
function poMobileCards(orders){return orders.length?orders.map(o=>`<div class="mobile-card" onclick="viewPO(${o.id})"><div class="mobile-card-header"><div class="mobile-card-title">${o.order_no}</div>${sb(o.status)}</div><div class="mobile-card-body"><div><span class="mobile-card-label">供应商</span> ${o.supplier_name||'-'}</div><div><span class="mobile-card-label">金额</span> <span class="fw-700">${fmtMoney(o.total_amount)}</span></div><div><span class="mobile-card-label">已付</span> ${fmtMoney(o.paid_amount)}</div><div><span class="mobile-card-label">时间</span> ${fmtDate(o.created_at).slice(5,16)}</div></div><div class="mobile-card-actions">${['confirmed','partial_received'].includes(o.status)?`<button class="btn btn-success btn-xs" onclick="event.stopPropagation();receivePO(${o.id})">入库</button>`:''} ${o.paid_amount<o.total_amount&&o.status!=='draft'?`<button class="btn btn-outline btn-xs" onclick="event.stopPropagation();payPO(${o.id},${o.total_amount-o.paid_amount})">付款</button>`:''}</div></div>`).join(''):'<div class="empty-state"><div class="empty-state-icon">🛒</div><h3>暂无采购单</h3><p>点击上方按钮创建第一张采购单</p></div>'}
async function filterPOStatus(el,status){el.parentElement.querySelectorAll('.filter-pill').forEach(p=>p.classList.remove('active'));el.classList.add('active');const all=_cache.poAll||[];const filtered=status?all.filter(o=>o.status===status):all;$('#po-body').innerHTML=poRows(filtered);$('#po-mobile').innerHTML=poMobileCards(filtered)}
function exportPO(){const orders=_cache.poAll||[];exportCSV(['单号','供应商','金额','已付','状态','时间'],orders.map(o=>[o.order_no,o.supplier_name,o.total_amount,o.paid_amount,o.status,fmtDate(o.created_at)]),`采购单_${new Date().toISOString().slice(0,10)}.csv`)}
async function filterPO(kw){const orders=await api('/api/procurement?keyword='+encodeURIComponent(kw));$('#po-body').innerHTML=poRows(orders)}
async function viewPO(id){const o=await api(`/api/procurement/${id}`);
  const remainPay=o.total_amount-o.paid_amount;
  openModal('采购单 '+o.order_no,`
    <div class="detail-grid">
      <div class="detail-item"><div class="detail-label">供应商</div><div class="detail-value">${o.supplier_name||'-'}</div></div>
      <div class="detail-item"><div class="detail-label">状态</div><div class="detail-value">${sb(o.status)}</div></div>
      <div class="detail-item"><div class="detail-label">总金额</div><div class="detail-value money-val">${fmtMoney(o.total_amount)}</div></div>
      <div class="detail-item"><div class="detail-label">已付款</div><div class="detail-value">${fmtMoney(o.paid_amount)}</div></div>
    </div>
    ${o.total_amount>0?`<div class="payment-progress"><div class="progress-bar"><div class="progress-fill ${o.paid_amount>=o.total_amount?'green':'blue'}" style="width:${Math.round(o.paid_amount/o.total_amount*100)}%"></div></div><div class="payment-info"><span class="payment-paid">已付 ${fmtMoney(o.paid_amount)}</span><span class="payment-unpaid">${remainPay>0?'待付 '+fmtMoney(remainPay):'已结清'}</span></div></div>`:''}
    <h4 style="margin:16px 0 8px">物料明细</h4>
    <table><thead><tr><th>物料</th><th>数量</th><th>已入库</th><th>待入库</th><th>单价</th><th>金额</th></tr></thead><tbody>${(o.items||[]).map(i=>`<tr><td>${i.product_code} ${i.product_name}</td><td>${i.quantity} ${i.unit}</td><td class="fw-600 ${i.received_qty>=i.quantity?'text-success':''}">${i.received_qty}</td><td class="${i.pending_qty>0?'fw-700':''}">${i.pending_qty}</td><td class="money">${fmtMoney(i.unit_price)}</td><td class="money fw-600">${fmtMoney(i.amount)}</td></tr>`).join('')}</tbody></table>
    <div style="padding:16px 24px;border-top:1px solid var(--border);display:flex;justify-content:flex-end;gap:8px">${remainPay>0&&o.status!=='draft'?`<button class="btn btn-primary" onclick="closeModal();payPO(${o.id},${remainPay})">付款 ${fmtMoney(remainPay)}</button>`:''}<button class="btn btn-outline" onclick="closeModal()">关闭</button></div>`)}
async function receivePO(id){
  const o=await api(`/api/procurement/${id}`);
  const items=(o.items||[]).filter(i=>i.pending_qty>0);
  if(!items.length)return toast('所有物料已入库','info');
  openModal('入库 - '+o.order_no,`
    <p class="text-sm text-muted mb-16">输入本次入库数量（最大不超过待入库数量）</p>
    <table><thead><tr><th>物料</th><th>待入库</th><th>本次入库</th></tr></thead><tbody>
      ${items.map(i=>`<tr><td>${i.product_code} ${i.product_name}</td><td>${i.pending_qty} ${i.unit}</td><td><input type="number" class="form-input recv-qty" data-item-id="${i.id}" value="${i.pending_qty}" min="0" max="${i.pending_qty}" style="width:100px;text-align:center"></td></tr>`).join('')}
    </tbody></table>
    <div style="padding:16px 24px;border-top:1px solid var(--border);display:flex;justify-content:flex-end;gap:10px"><button class="btn btn-outline" onclick="closeModal()">取消</button><button class="btn btn-success" onclick="doReceivePO(${id})">确认入库</button></div>`);
}
async function doReceivePO(id){
  const inputs=$$('.recv-qty');
  const recvItems=[];
  inputs.forEach(inp=>{const qty=Number(inp.value);if(qty>0)recvItems.push({item_id:Number(inp.dataset.itemId),receive_qty:qty})});
  if(!recvItems.length)return toast('请输入入库数量','error');
  await api(`/api/procurement/${id}/receive`,{method:'PUT',body:{items:recvItems}});
  closeModal();toast('入库成功');pgProcurement();
}
async function payPO(id,maxAmount){
  openModal('付款',`<form onsubmit="event.preventDefault();doPayPO(${id})"><div class="form-group"><label class="form-label">付款金额 (最大 ${fmtMoney(maxAmount)})</label><input class="form-input" type="number" step="0.01" id="pay-amount" value="${maxAmount}" max="${maxAmount}" min="0.01" required></div><div style="padding:16px 24px;border-top:1px solid var(--border);display:flex;justify-content:flex-end;gap:10px"><button type="button" class="btn btn-outline" onclick="closeModal()">取消</button><button type="submit" class="btn btn-primary">确认付款</button></div></form>`);
}
async function doPayPO(id){const amt=Number($('#pay-amount').value);if(!amt)return;await api(`/api/procurement/${id}/pay`,{method:'PUT',body:{amount:amt}});closeModal();toast('付款成功');pgProcurement()}
async function formPurchase(){const[prods,conts]=await Promise.all([api('/api/products'),api('/api/contacts?type=supplier')]);_poItems=[];
  openModal('新建采购单',`<form onsubmit="savePurchase(event)"><div class="form-group"><label class="form-label">供应商</label><select class="form-select" name="supplier_id"><option value="">选择...</option>${(conts.data||conts).map(c=>`<option value="${c.id}">${c.name}</option>`).join('')}</select></div><div class="form-group"><label class="form-label">添加物料</label><div class="flex gap-8 mb-12"><select class="form-select" id="poi-p" style="flex:3">${(prods.data||prods).map(p=>`<option value="${p.id}" data-p="${p.cost_price}">${p.code} ${p.name}</option>`).join('')}</select><input class="form-input" type="number" id="poi-q" value="1" min="1" style="flex:1" placeholder="数量"><input class="form-input" type="number" step="0.0001" id="poi-pr" style="flex:1" placeholder="单价"><button type="button" class="btn btn-outline" onclick="addPOI()">+</button></div><div id="poi-list"></div></div><div class="form-group"><label class="form-label">备注</label><textarea class="form-textarea" name="remark" rows="2"></textarea></div><div style="padding:16px 24px;border-top:1px solid var(--border);display:flex;justify-content:flex-end;gap:10px"><button type="button" class="btn btn-outline" onclick="closeModal()">取消</button><button type="submit" class="btn btn-primary">创建</button></div></form>`);
  const sel=$('#poi-p');if(sel&&sel.options.length>1){$('#poi-pr').value=sel.options[sel.selectedIndex].dataset.p||''}if(sel)sel.onchange=()=>{$('#poi-pr').value=sel.options[sel.selectedIndex].dataset.p||''}}
function addPOI(){const s=$('#poi-p'),o=s.options[s.selectedIndex];_poItems.push({product_id:+s.value,name:o.text,quantity:+$('#poi-q').value||1,unit_price:+$('#poi-pr').value||0});renderPOI()}
function renderPOI(){const el=$('#poi-list');if(!_poItems.length){el.innerHTML='<div class="text-hint text-sm">尚未添加</div>';return}el.innerHTML=`<table><thead><tr><th>物料</th><th>数量</th><th>单价</th><th>金额</th><th></th></tr></thead><tbody>${_poItems.map((i,idx)=>`<tr><td>${i.name}</td><td>${i.quantity}</td><td class="money">${fmtMoney(i.unit_price)}</td><td class="money fw-600">${fmtMoney(i.quantity*i.unit_price)}</td><td><button type="button" class="btn btn-ghost btn-xs" onclick="_poItems.splice(${idx},1);renderPOI()">✕</button></td></tr>`).join('')}</tbody></table><div class="text-right text-sm mt-12"><span class="text-muted">合计：</span><span class="fw-700">${fmtMoney(_poItems.reduce((s,i)=>s+i.quantity*i.unit_price,0))}</span></div>`}
async function savePurchase(e){e.preventDefault();if(!_poItems.length)return toast('请添加物料','error');const fd=new FormData(e.target);await api('/api/procurement',{method:'POST',body:{supplier_id:+fd.get('supplier_id')||null,items:_poItems.map(i=>({product_id:i.product_id,quantity:i.quantity,unit_price:i.unit_price})),remark:fd.get('remark')||''}});closeModal();toast('创建成功');pgProcurement()}
async function updPO(id,status){if(!confirm(status==='received'?'入库将自动增加库存，确定？':'确定确认？'))return;await api(`/api/procurement/${id}/status`,{method:'PUT',body:{status}});toast('操作成功');pgProcurement()}
async function delPO(id){if(!confirm('确定删除？'))return;await api(`/api/procurement/${id}`,{method:'DELETE'});toast('已删除');pgProcurement()}

// ===== Sales =====
let _soItems=[];
async function pgSales(){
  const orders=await api('/api/sales');
  const sf=s=>{const f=['draft','confirmed','shipped','completed'],l=['草稿','已确认','已发货','已完成'],i=f.indexOf(s);return f.map((_,j)=>`<span class="status-step ${j<i?'done':j===i?'current':'pending'}">${l[j]}</span>${j<f.length-1?'<span class="status-arrow">›</span>':''}`).join('')};
  $('#page-content').innerHTML=`<div class="toolbar"><div class="search-box"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg><input placeholder="搜索单号/客户..." oninput="filterSO(this.value)"></div><button class="btn btn-primary" onclick="formSale()">+ 新建销售单</button></div><div class="card"><div class="card-body no-pad"><div class="table-wrapper"><table><thead><tr><th>单号</th><th>客户</th><th>金额</th><th>状态</th><th>时间</th><th>操作</th></tr></thead><tbody id="so-body">${soRows(orders)}</tbody></table></div></div></div>`}
function soRows(orders){return orders.length?orders.map(o=>{const sf=s=>{const f=['draft','confirmed','shipped','completed'],l=['草稿','已确认','已发货','已完成'],i=f.indexOf(s);return f.map((_,j)=>`<span class="status-step ${j<i?'done':j===i?'current':'pending'}">${l[j]}</span>${j<f.length-1?'<span class="status-arrow">›</span>':''}`).join('')};return`<tr><td class="fw-600">${o.order_no}</td><td>${o.customer_name||'-'}</td><td class="money fw-600">${fmtMoney(o.total_amount)}</td><td><div class="status-flow">${sf(o.status)}</div></td><td class="text-hint text-sm">${fmtDate(o.created_at)}</td><td class="nowrap"><button class="btn btn-ghost btn-xs" onclick="viewSO(${o.id})">详情</button>${o.status==='draft'?`<button class="btn btn-primary btn-xs" onclick="updSO(${o.id},'confirmed')">确认</button><button class="btn btn-ghost btn-xs" onclick="delSO(${o.id})">删除</button>`:''}${o.status==='confirmed'?`<button class="btn btn-warning btn-xs" onclick="updSO(${o.id},'shipped')">发货</button>`:''}${o.status==='shipped'?`<button class="btn btn-success btn-xs" onclick="updSO(${o.id},'completed')">完成</button>`:''}</td></tr>`}).join(''):'<tr><td colspan="6" class="table-empty">暂无</td></tr>'}
async function filterSO(kw){const orders=await api('/api/sales?keyword='+encodeURIComponent(kw));$('#so-body').innerHTML=soRows(orders)}
async function viewSO(id){const o=await api(`/api/sales/${id}`);openModal('销售单 '+o.order_no,`<div class="flex items-center gap-12 mb-16"><span class="text-muted">客户：</span><span class="fw-600">${o.customer_name||'-'}</span><span style="margin-left:auto">${sb(o.status)}</span></div><table><thead><tr><th>产品</th><th>数量</th><th>单价</th><th>金额</th></tr></thead><tbody>${(o.items||[]).map(i=>`<tr><td>${i.product_code} ${i.product_name}</td><td>${i.quantity} ${i.unit}</td><td class="money">${fmtMoney(i.unit_price)}</td><td class="money fw-600">${fmtMoney(i.amount)}</td></tr>`).join('')}</tbody></table><div class="text-right" style="margin-top:16px;padding-top:12px;border-top:2px solid var(--border)"><span class="text-muted">合计：</span><span class="fw-800" style="font-size:20px;color:var(--primary)">${fmtMoney(o.total_amount)}</span></div><div style="padding:16px 24px;border-top:1px solid var(--border);display:flex;justify-content:flex-end"><button class="btn btn-outline" onclick="closeModal()">关闭</button></div>`)}
async function formSale(){const[prods,conts]=await Promise.all([api('/api/products'),api('/api/contacts?type=customer')]);_soItems=[];
  openModal('新建销售单',`<form onsubmit="saveSale(event)"><div class="form-group"><label class="form-label">客户</label><select class="form-select" name="customer_id"><option value="">选择...</option>${(conts.data||conts).map(c=>`<option value="${c.id}">${c.name}</option>`).join('')}</select></div><div class="form-group"><label class="form-label">添加产品</label><div class="flex gap-8 mb-12"><select class="form-select" id="soi-p" style="flex:3">${(prods.data||prods).map(p=>`<option value="${p.id}" data-p="${p.sale_price}" data-s="${p.current_stock}">${p.code} ${p.name}(库存:${p.current_stock})</option>`).join('')}</select><input class="form-input" type="number" id="soi-q" value="1" min="1" style="flex:1"><input class="form-input" type="number" step="0.0001" id="soi-pr" style="flex:1" placeholder="单价"><button type="button" class="btn btn-outline" onclick="addSOI()">+</button></div><div id="soi-list"></div></div><div class="form-group"><label class="form-label">备注</label><textarea class="form-textarea" name="remark" rows="2"></textarea></div><div style="padding:16px 24px;border-top:1px solid var(--border);display:flex;justify-content:flex-end;gap:10px"><button type="button" class="btn btn-outline" onclick="closeModal()">取消</button><button type="submit" class="btn btn-primary">创建</button></div></form>`);
  const sel=$('#soi-p');if(sel&&sel.options.length>1){$('#soi-pr').value=sel.options[sel.selectedIndex].dataset.p||''}if(sel)sel.onchange=()=>{$('#soi-pr').value=sel.options[sel.selectedIndex].dataset.p||''}}
function addSOI(){const s=$('#soi-p'),o=s.options[s.selectedIndex];_soItems.push({product_id:+s.value,name:o.text,quantity:+$('#soi-q').value||1,unit_price:+$('#soi-pr').value||0});renderSOI()}
function renderSOI(){const el=$('#soi-list');if(!_soItems.length){el.innerHTML='<div class="text-hint text-sm">尚未添加</div>';return}el.innerHTML=`<table><thead><tr><th>产品</th><th>数量</th><th>单价</th><th>金额</th><th></th></tr></thead><tbody>${_soItems.map((i,idx)=>`<tr><td>${i.name}</td><td>${i.quantity}</td><td class="money">${fmtMoney(i.unit_price)}</td><td class="money fw-600">${fmtMoney(i.quantity*i.unit_price)}</td><td><button type="button" class="btn btn-ghost btn-xs" onclick="_soItems.splice(${idx},1);renderSOI()">✕</button></td></tr>`).join('')}</tbody></table><div class="text-right text-sm mt-12"><span class="text-muted">合计：</span><span class="fw-700">${fmtMoney(_soItems.reduce((s,i)=>s+i.quantity*i.unit_price,0))}</span></div>`}
async function saveSale(e){e.preventDefault();if(!_soItems.length)return toast('请添加产品','error');const fd=new FormData(e.target);await api('/api/sales',{method:'POST',body:{customer_id:+fd.get('customer_id')||null,items:_soItems.map(i=>({product_id:i.product_id,quantity:i.quantity,unit_price:i.unit_price})),remark:fd.get('remark')||''}});closeModal();toast('创建成功');pgSales()}
async function updSO(id,status){if(!confirm(status==='shipped'?'发货将自动扣减库存，确定？':status==='completed'?'完成将自动记收入，确定？':'确定确认？'))return;await api(`/api/sales/${id}/status`,{method:'PUT',body:{status}});toast('操作成功');pgSales()}
async function delSO(id){if(!confirm('确定删除？'))return;await api(`/api/sales/${id}`,{method:'DELETE'});toast('已删除');pgSales()}

// ===== Production =====
async function pgProduction(){
  const orders=await api('/api/production');
  const sf=s=>{const f=['pending','in_progress','completed'],l=['待生产','生产中','已完成'],i=f.indexOf(s);return f.map((_,j)=>`<span class="status-step ${j<i?'done':j===i?'current':'pending'}">${l[j]}</span>${j<f.length-1?'<span class="status-arrow">›</span>':''}`).join('')};
  $('#page-content').innerHTML=`<div class="toolbar"><div class="search-box"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg><input placeholder="搜索单号/产品..." oninput="filterProd(this.value)"></div><button class="btn btn-primary" onclick="formProduction()">+ 新建生产单</button></div><div class="card"><div class="card-body no-pad"><div class="table-wrapper"><table><thead><tr><th>单号</th><th>产品</th><th>数量</th><th>状态</th><th>时间</th><th>操作</th></tr></thead><tbody id="prod-body">${prodRows2(orders)}</tbody></table></div></div></div>`}
function prodRows2(orders){return orders.length?orders.map(o=>{const sf=s=>{const f=['pending','in_progress','completed'],l=['待生产','生产中','已完成'],i=f.indexOf(s);return f.map((_,j)=>`<span class="status-step ${j<i?'done':j===i?'current':'pending'}">${l[j]}</span>${j<f.length-1?'<span class="status-arrow">›</span>':''}`).join('')};return`<tr><td class="fw-600">${o.order_no}</td><td>${o.product_code} ${o.product_name}</td><td>${o.quantity}</td><td><div class="status-flow">${sf(o.status)}</div></td><td class="text-hint text-sm">${fmtDate(o.created_at)}</td><td class="nowrap"><button class="btn btn-ghost btn-xs" onclick="viewProd(${o.id})">详情</button>${o.status==='pending'?`<button class="btn btn-primary btn-xs" onclick="updProd(${o.id},'in_progress')">开工</button><button class="btn btn-ghost btn-xs" onclick="delProd(${o.id})">删除</button>`:''}${o.status==='in_progress'?`<button class="btn btn-success btn-xs" onclick="updProd(${o.id},'completed')">完工入库</button>`:''}</td></tr>`}).join(''):'<tr><td colspan="6" class="table-empty">暂无生产单</td></tr>'}
async function filterProd(kw){const orders=await api('/api/production?keyword='+encodeURIComponent(kw));$('#prod-body').innerHTML=prodRows2(orders)}
async function viewProd(id){const o=await api(`/api/production/${id}`);openModal('生产单 '+o.order_no,`<div class="flex items-center gap-12 mb-16"><span class="text-muted">产品：</span><span class="fw-600">${o.product_code} ${o.product_name}</span><span class="text-muted" style="margin-left:auto">数量: ${o.quantity}</span>${sb(o.status)}</div><h4 style="margin-bottom:8px">原材料清单</h4><table><thead><tr><th>物料</th><th>需要</th><th>已领</th><th>库存</th><th>状态</th></tr></thead><tbody>${(o.materials||[]).map(m=>`<tr><td>${m.material_code} ${m.material_name}</td><td>${m.required_qty} ${m.material_unit}</td><td>${m.consumed_qty}</td><td>${m.current_stock}</td><td>${m.current_stock>=m.required_qty?'<span class="badge badge-success">充足</span>':'<span class="badge badge-danger">不足</span>'}</td></tr>`).join('')}</tbody></table><div style="padding:16px 24px;border-top:1px solid var(--border);display:flex;justify-content:flex-end"><button class="btn btn-outline" onclick="closeModal()">关闭</button></div>`)}
async function formProduction(){const prods=await api('/api/products');
  openModal('新建生产单',`<form onsubmit="saveProduction(event)"><div class="form-group"><label class="form-label">选择产品 *</label><select class="form-select" name="product_id" required><option value="">选择有BOM的产品...</option>${(prods.data||prods).map(p=>`<option value="${p.id}">${p.code} - ${p.name} (库存:${p.current_stock})</option>`).join('')}</select></div><div class="form-row"><div class="form-group"><label class="form-label">生产数量 *</label><input class="form-input" type="number" name="quantity" value="1" min="1" required></div><div class="form-group"><label class="form-label">备注</label><input class="form-input" name="remark"></div></div><div style="padding:16px 24px;border-top:1px solid var(--border);display:flex;justify-content:flex-end;gap:10px"><button type="button" class="btn btn-outline" onclick="closeModal()">取消</button><button type="submit" class="btn btn-primary">创建</button></div></form>`)}
async function saveProduction(e){e.preventDefault();const fd=new FormData(e.target);try{await api('/api/production',{method:'POST',body:{product_id:+fd.get('product_id'),quantity:+fd.get('quantity'),remark:fd.get('remark')||''}});closeModal();toast('创建成功');pgProduction()}catch(err){const d=await err.response?.json?.();toast(d?.error||'创建失败','error')}}
async function updProd(id,status){if(!confirm(status==='in_progress'?'开工将自动领用原材料，确定？':status==='completed'?'完工将自动入库成品，确定？':'确定？'))return;await api(`/api/production/${id}/status`,{method:'PUT',body:{status}});toast('操作成功');pgProduction()}
async function delProd(id){if(!confirm('确定删除？'))return;await api(`/api/production/${id}`,{method:'DELETE'});toast('已删除');pgProduction()}

// ===== Inventory =====
async function pgInventory(){
  const[stock,report]=await Promise.all([api('/api/inventory'),api('/api/inventory/report')]);
  $('#page-content').innerHTML=`
    <div class="stat-grid" style="grid-template-columns:repeat(4,1fr);margin-bottom:16px">
      <div class="stat-card blue"><div class="stat-label">产品种类</div><div class="stat-value" style="font-size:22px">${report.total_products}</div></div>
      <div class="stat-card green"><div class="stat-label">库存总价值</div><div class="stat-value" style="font-size:18px">${fmtMoney(report.total_stock_value)}</div></div>
      <div class="stat-card orange"><div class="stat-label">今日入库</div><div class="stat-value" style="font-size:22px">${fmtInt(report.today_in)}</div></div>
      <div class="stat-card red"><div class="stat-label">今日出库</div><div class="stat-value" style="font-size:22px">${fmtInt(report.today_out)}</div></div>
    </div>
    <div class="tabs" id="inv-tabs"><div class="tab active" onclick="showInv('current',this)">当前库存</div><div class="tab" onclick="showInv('log',this)">出入库记录</div><div class="tab" onclick="showInv('report',this)">库存报表</div></div>
    <div id="inv-current"><div class="toolbar"><div class="search-box"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg><input placeholder="搜索..." oninput="filterStock()"></div><label style="display:flex;align-items:center;gap:6px;font-size:12px;color:var(--text-sec);cursor:pointer"><input type="checkbox" onchange="filterStock(this.checked)"> 仅显示库存不足</label></div><div class="card"><div class="card-body no-pad"><div class="table-wrapper"><table><thead><tr><th>编号</th><th>条码</th><th>名称</th><th>分类</th><th>单位</th><th>当前库存</th><th>最低</th><th>库位</th><th>状态</th></tr></thead><tbody id="stk-body">${stockRows(stock)}</tbody></table></div></div></div></div>
    <div id="inv-log" style="display:none"><div class="toolbar"><select class="form-select" style="width:auto;padding:8px 12px;border-radius:8px" onchange="filterMovs(this.value)"><option value="">近30天</option><option value="7">近7天</option><option value="1">今天</option></select><div class="tabs" style="margin:0"><div class="tab active" onclick="filterMovs('','',this)">全部</div><div class="tab" onclick="filterMovs('','in',this)">入库</div><div class="tab" onclick="filterMovs('','out',this)">出库</div></div></div><div class="card"><div class="card-body no-pad"><div class="table-wrapper"><table><thead><tr><th>时间</th><th>物料</th><th>类型</th><th>数量</th><th>关联单号</th><th>备注</th></tr></thead><tbody id="mov-body"></tbody></table></div></div></div></div>
    <div id="inv-report" style="display:none"><div class="card"><div class="card-header"><h3>📊 7日出入库趋势</h3></div><div class="card-body">${barChart(report.trend_7d,Math.max(...report.trend_7d.map(t=>Math.max(t.in,t.out)),1))}</div></div><div class="card mt-16"><div class="card-header"><h3>📦 分类库存价值</h3></div><div class="card-body no-pad"><table><thead><tr><th>分类</th><th>品种数</th><th>总数量</th><th>总价值</th></tr></thead><tbody>${report.category_value.map(c=>`<tr><td class="fw-600">${c.category}</td><td>${c.count}</td><td>${fmtInt(c.total_qty)}</td><td class="money fw-600">${fmtMoney(c.total_value)}</td></tr>`).join('')||'<tr><td colspan="4" class="table-empty">暂无分类数据</td></tr>'}</tbody></table></div></div></div>`;
}
function stockRows(items){return items.map(p=>{const low=p.is_low;return`<tr><td class="fw-600">${p.code}</td><td class="text-hint text-xs" style="font-family:monospace">${p.barcode||'-'}</td><td>${p.name}</td><td class="text-muted">${p.category||'-'}</td><td>${p.unit}</td><td class="fw-700">${p.current_stock}</td><td class="text-hint">${p.min_stock}</td><td class="text-hint text-xs">${p.location||'-'}</td><td>${p.is_out?'<span class="badge badge-danger">缺货</span>':low?'<span class="badge badge-warning">偏低</span>':'<span class="badge badge-success">正常</span>'}</td></tr>`}).join('')||'<tr><td colspan="9" class="table-empty">暂无数据</td></tr>'}
async function filterStock(lowOnly){const kw=$('#inv-current .search-box input')?.value||'';let u='/api/inventory?';if(kw)u+=`keyword=${encodeURIComponent(kw)}&`;if(lowOnly)u+='low_only=1&';$('#stk-body').innerHTML=stockRows(await api(u))}
function showInv(tab,el){['current','log','report'].forEach(t=>document.getElementById('inv-'+t).style.display=t===tab?'':'none');el.parentElement.querySelectorAll('.tab').forEach(t=>t.classList.remove('active'));el.classList.add('active');if(tab==='log')filterMovs()}
async function filterMovs(days,type,el){if(el){el.parentElement.querySelectorAll('.tab').forEach(t=>t.classList.remove('active'));el.classList.add('active')}let u='/api/inventory/movements?';if(days)u+=`days=${days}&`;if(type)u+=`type=${type}&`;const r=await api(u);const movs=r.data||r;
  $('#mov-body').innerHTML=movs.map(m=>`<tr><td class="text-hint text-sm">${fmtDate(m.created_at)}</td><td>${m.product_code} ${m.product_name}</td><td>${m.type==='in'?'<span class="badge badge-success">入库</span>':'<span class="badge badge-warning">出库</span>'}</td><td class="fw-600">${m.type==='in'?'+':'-'}${m.quantity}</td><td class="text-hint">${m.related_order||'-'}</td><td class="text-hint">${m.remark||'-'}</td></tr>`).join('')||'<tr><td colspan="6" class="table-empty">暂无记录</td></tr>'}

// ===== Scan =====
async function pgScan(){
  _cache.products=_cache.products||await (api('/api/products').then(r=>r.data||r));
  $('#page-content').innerHTML=`
    <div class="card mb-16" style="border-left:4px solid var(--success)"><div class="card-body">
      <h3 style="margin-bottom:12px">📱 扫码出入库</h3>
      <p class="text-muted text-sm mb-16">扫描产品条码或手动输入，快速完成出入库。支持连续扫码。</p>
      <div class="filter-pills" style="margin-bottom:16px">
        <button class="btn btn-success btn-lg" onclick="startScan('in')" style="flex:1;padding:18px;font-size:16px;justify-content:center;border-radius:var(--radius)">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 5v14M5 12h14"/></svg>
          入库
        </button>
        <button class="btn btn-warning btn-lg" onclick="startScan('out')" style="flex:1;padding:18px;font-size:16px;justify-content:center;border-radius:var(--radius)">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="5" y1="12" x2="19" y2="12"/></svg>
          出库
        </button>
      </div>
    </div></div>
    <div class="card mb-16"><div class="card-body">
      <h3 style="margin-bottom:12px">⌨️ 手动输入</h3>
      <div class="form-row">
        <div class="form-group"><label class="form-label">条码/编号</label><input class="form-input" id="manual-barcode" placeholder="输入条码或物料编号" style="font-size:16px" onkeydown="if(event.key==='Enter'){event.preventDefault();manualScan()}"></div>
        <div class="form-group"><label class="form-label">类型</label><select class="form-select" id="manual-type"><option value="in">入库 ↑</option><option value="out">出库 ↓</option></select></div>
      </div>
      <div class="form-row">
        <div class="form-group"><label class="form-label">数量</label><input class="form-input" type="number" id="manual-qty" value="1" min="1" style="font-size:16px"></div>
        <div class="form-group"><label class="form-label">备注</label><input class="form-input" id="manual-remark" placeholder="可选"></div>
      </div>
      <button class="btn btn-primary btn-lg" onclick="manualScan()" style="width:100%">确认操作 <span class="kbd" style="margin-left:8px">Enter</span></button>
    </div></div>
    <div class="card"><div class="card-header"><h3>📋 今日扫码记录</h3></div><div class="card-body no-pad">
      <div class="table-wrapper"><table><thead><tr><th>时间</th><th>物料</th><th>类型</th><th>数量</th><th>备注</th></tr></thead><tbody id="scan-log-body"><tr><td colspan="5" class="table-empty">加载中...</td></tr></tbody></table></div>
    </div></div>`;
  const r=await api('/api/inventory/movements?days=1');const movs=r.data||r;
  $('#scan-log-body').innerHTML=movs.map(m=>`<tr><td class="text-hint text-sm">${fmtDate(m.created_at)}</td><td>${m.product_code} ${m.product_name}</td><td>${m.type==='in'?'<span class="badge badge-success">入库</span>':'<span class="badge badge-warning">出库</span>'}</td><td class="fw-600">${m.type==='in'?'+':'-'}${m.quantity}</td><td class="text-hint">${m.remark||'-'}</td></tr>`).join('')||'<tr><td colspan="5" class="table-empty">今日暂无记录</td></tr>';
}
async function manualScan(){
  const barcode=$('#manual-barcode').value.trim();if(!barcode)return toast('请输入条码','error');
  const type=$('#manual-type').value,qty=+$('#manual-qty').value||1,remark=$('#manual-remark').value||'';
  try{const r=await api('/api/inventory/scan',{method:'POST',body:{barcode,type,quantity:qty,remark}});toast(`${r.product} ${type==='in'?'入库':'出库'} ${qty}，当前库存: ${r.new_stock}`);$('#manual-barcode').value='';$('#manual-qty').value='1';$('#manual-remark').value='';pgScan()}catch(e){toast('操作失败','error')}
}
function stopScanner(){if(_scanner){try{_scanner.stop()}catch(e){}_scanner=null}}
function startScan(type){
  const title=type==='in'?'扫码入库':'扫码出库';
  openScanModal(title,`<div id="scan-reader" style="width:100%;min-height:250px;background:#000;border-radius:8px;overflow:hidden"></div><div class="form-group mt-16"><label class="form-label">数量</label><input class="form-input" type="number" id="scan-qty" value="1" min="1" style="font-size:18px;text-align:center"></div><div class="form-group"><label class="form-label">备注</label><input class="form-input" id="scan-remark" placeholder="可选"></div><div id="scan-result" class="text-center" style="min-height:40px"></div><div style="padding:16px 0;display:flex;gap:10px"><button class="btn btn-outline" style="flex:1" onclick="closeScanModal()">关闭</button></div>`);
  setTimeout(()=>{try{_scanner=new Html5Qrcode('scan-reader');_scanner.start({facingMode:'environment'},{fps:10,qrbox:{width:250,height:150}},async code=>{if(!code)return;_scanner.pause(true);const qty=+$('#scan-qty').value||1;const remark=$('#scan-remark').value||'';try{const r=await api('/api/inventory/scan',{method:'POST',body:{barcode:code.trim(),type,quantity:qty,remark}});$('#scan-result').innerHTML=`<div class="badge badge-success" style="font-size:14px;padding:8px 16px">✓ ${r.product} ${type==='in'?'入库':'出库'}成功！库存: ${r.new_stock}</div>`;toast(`${r.product} 操作成功`)}catch(e){$('#scan-result').innerHTML=`<div class="badge badge-danger" style="font-size:14px;padding:8px 16px">✕ 扫码失败: 条码${code}未找到</div>`;toast('未找到产品','error')}setTimeout(()=>{if(_scanner)try{_scanner.resume()}catch(e){}},2000)},()=>{}).catch(err=>{$('#scan-reader').innerHTML=`<div style="padding:40px;text-align:center;color:#fff"><p>📷 无法访问摄像头</p><p style="font-size:12px;opacity:0.7">请检查浏览器权限或使用手动输入</p></div>`})}catch(e){$('#scan-reader').innerHTML=`<div style="padding:40px;text-align:center;color:#fff"><p>此浏览器不支持扫码功能</p></div>`}},300)}

// ===== Stock Take =====
async function pgStocktake(){
  const prods=await api('/api/inventory');_cache.stocktake={};
  prods.forEach(p=>{_cache.stocktake[p.id]={...p,actual:p.current_stock}});
  $('#page-content').innerHTML=`<div class="card mb-16"><div class="card-body"><h3 style="margin-bottom:8px">📋 库存盘点</h3><p class="text-muted text-sm mb-16">逐一核实实际库存数量，系统将自动计算差异并调整。</p><div class="toolbar" style="margin-bottom:0"><div class="search-box"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg><input placeholder="搜索物料..." oninput="filterStocktake(this.value)"></div><button class="btn btn-success" onclick="submitStocktake()">✅ 提交盘点结果</button></div></div></div><div class="card"><div class="card-body no-pad"><div class="table-wrapper"><table><thead><tr><th>编号</th><th>名称</th><th>系统库存</th><th>实际数量</th><th>差异</th></tr></thead><tbody id="st-body">${stocktakeRows(prods)}</tbody></table></div></div></div>`;
}
function stocktakeRows(items){return items.map(p=>{const actual=_cache.stocktake[p.id]?.actual??p.current_stock;const diff=actual-p.current_stock;const diffCls=diff>0?'badge-success':diff<0?'badge-danger':'badge-gray';return`<tr data-id="${p.id}"><td>${p.code}</td><td class="fw-600">${p.name}</td><td class="text-hint">${p.current_stock}</td><td><input type="number" class="form-input" value="${actual}" min="0" style="width:100px;text-align:center;font-weight:700" onchange="updateStocktake(${p.id},this.value)"></td><td><span class="badge ${diffCls}">${diff>0?'+':''}${diff}</span></td></tr>`}).join('')||'<tr><td colspan="5" class="table-empty">暂无物料</td></tr>'}
function updateStocktake(id,val){if(_cache.stocktake[id])_cache.stocktake[id].actual=+val||0;const tr=$(`tr[data-id="${id}"]`);if(!tr)return;const p=_cache.stocktake[id];const diff=p.actual-p.current_stock;const badge=tr.querySelector('td:last-child .badge');if(badge){badge.textContent=(diff>0?'+':'')+diff;badge.className=`badge ${diff>0?'badge-success':diff<0?'badge-danger':'badge-gray'}`}}
async function filterStocktake(kw){const all=Object.values(_cache.stocktake);const filtered=kw?all.filter(p=>p.code.includes(kw)||p.name.includes(kw)):all;$('#st-body').innerHTML=stocktakeRows(filtered)}
async function submitStocktake(){const items=Object.values(_cache.stocktake).filter(p=>p.actual!==p.current_stock).map(p=>({product_id:p.id,actual_count:p.actual}));if(!items.length)return toast('没有需要调整的项目','info');if(!confirm(`共${items.length}项有差异，确定提交？`))return;try{const r=await api('/api/inventory/stocktake',{method:'POST',body:{items}});toast(`盘点完成！调整了${r.results.length}项`);pgStocktake()}catch(e){toast('盘点失败','error')}}

// ===== Finance =====
async function pgFinance(){
  const[recs,sum]=await Promise.all([api('/api/finance'),api('/api/finance/summary')]);
  const data=recs.data||recs;
  const row=r=>`<tr><td class="text-hint text-sm">${fmtDate(r.created_at)}</td><td>${r.type==='income'?'<span class="badge badge-success">收入</span>':'<span class="badge badge-danger">支出</span>'}</td><td>${r.category||'-'}</td><td class="money fw-700" style="color:${r.type==='income'?'var(--success)':'var(--danger)'}">${r.type==='income'?'+':'-'}${fmtMoney(r.amount)}</td><td>${r.contact_name||'-'}</td><td class="text-hint">${r.remark||'-'}</td><td><button class="btn btn-ghost btn-xs" onclick="delFin(${r.id})">🗑️</button></td></tr>`;
  $('#page-content').innerHTML=`
    <div class="stat-grid"><div class="stat-card green"><div class="stat-label">累计收入</div><div class="stat-value">${fmtMoney(sum.income)}</div></div><div class="stat-card red"><div class="stat-label">累计支出</div><div class="stat-value">${fmtMoney(sum.expense)}</div></div><div class="stat-card ${sum.profit>=0?'blue':'red'}"><div class="stat-label">累计利润</div><div class="stat-value">${fmtMoney(sum.profit)}</div></div><div class="stat-card orange"><div class="stat-label">本月</div><div class="stat-value" style="font-size:16px">+${fmtMoney(sum.monthly_income)} / -${fmtMoney(sum.monthly_expense)}</div></div></div>
    <div class="toolbar"><button class="btn btn-primary" onclick="formFin()">+ 记一笔</button><div class="tabs" id="fin-tabs" style="margin:0"><div class="tab active" onclick="filterFin('',this)">全部</div><div class="tab" onclick="filterFin('income',this)">收入</div><div class="tab" onclick="filterFin('expense',this)">支出</div></div></div>
    <div class="card"><div class="card-body no-pad"><div class="table-wrapper"><table><thead><tr><th>时间</th><th>类型</th><th>分类</th><th>金额</th><th>关联方</th><th>备注</th><th></th></tr></thead><tbody id="fin-body">${data.map(row).join('')}</tbody></table></div></div></div>`}
async function filterFin(type,el){if(el){el.parentElement.querySelectorAll('.tab').forEach(t=>t.classList.remove('active'));el.classList.add('active')}const r=await api(`/api/finance${type?'?type='+type:''}`);const recs=r.data||r;const row=r=>`<tr><td class="text-hint text-sm">${fmtDate(r.created_at)}</td><td>${r.type==='income'?'<span class="badge badge-success">收入</span>':'<span class="badge badge-danger">支出</span>'}</td><td>${r.category||'-'}</td><td class="money fw-700" style="color:${r.type==='income'?'var(--success)':'var(--danger)'}">${r.type==='income'?'+':'-'}${fmtMoney(r.amount)}</td><td>${r.contact_name||'-'}</td><td class="text-hint">${r.remark||'-'}</td><td><button class="btn btn-ghost btn-xs" onclick="delFin(${r.id})">🗑️</button></td></tr>`;$('#fin-body').innerHTML=recs.map(row).join('')||'<tr><td colspan="7" class="table-empty">暂无记录</td></tr>'}
async function formFin(){const conts=await api('/api/contacts');openModal('记账',`<form onsubmit="saveFin(event)"><div class="form-row"><div class="form-group"><label class="form-label">类型 *</label><select class="form-select" name="type" required><option value="income">收入</option><option value="expense">支出</option></select></div><div class="form-group"><label class="form-label">金额 *</label><input class="form-input" type="number" step="0.01" name="amount" required></div></div><div class="form-row"><div class="form-group"><label class="form-label">分类</label><input class="form-input" name="category" placeholder="销售/采购/工资..."></div><div class="form-group"><label class="form-label">关联方</label><select class="form-select" name="contact_id"><option value="">无</option>${(conts.data||conts).map(c=>`<option value="${c.id}">${c.name}</option>`).join('')}</select></div></div><div class="form-group"><label class="form-label">备注</label><input class="form-input" name="remark"></div><div style="padding:16px 24px;border-top:1px solid var(--border);display:flex;justify-content:flex-end;gap:10px"><button type="button" class="btn btn-outline" onclick="closeModal()">取消</button><button type="submit" class="btn btn-primary">保存</button></div></form>`)}
async function saveFin(e){e.preventDefault();const d=Object.fromEntries(new FormData(e.target));d.amount=+d.amount;d.contact_id=d.contact_id?+d.contact_id:null;await api('/api/finance',{method:'POST',body:d});closeModal();toast('记账成功');pgFinance()}
async function delFin(id){if(!confirm('确定删除？'))return;await api(`/api/finance/${id}`,{method:'DELETE'});toast('已删除');pgFinance()}

// ===== Reports =====
async function pgReports(){
  const r=await api('/api/reports/overview');
  const topSellHtml=r.topSelling.map(p=>`<tr><td>${p.code}</td><td class="fw-600">${p.name}</td><td>${fmtInt(p.total_qty)}</td><td class="money fw-600">${fmtMoney(p.total_amount)}</td></tr>`).join('')||'<tr><td colspan="4" class="table-empty">暂无数据</td></tr>';
  const topCostHtml=r.topCost.map(p=>`<tr><td>${p.code}</td><td class="fw-600">${p.name}</td><td>${fmtInt(p.total_qty)}</td><td class="money fw-600">${fmtMoney(p.total_amount)}</td></tr>`).join('')||'<tr><td colspan="4" class="table-empty">暂无数据</td></tr>';
  $('#page-content').innerHTML=`
    <div class="stat-grid">
      <div class="stat-card blue"><div class="stat-icon">📦</div><div class="stat-label">总产品</div><div class="stat-value">${r.products.total}</div><div class="stat-footer">库存价值 ${fmtMoney(r.products.stockValue)}</div></div>
      <div class="stat-card green"><div class="stat-icon">💰</div><div class="stat-label">总利润</div><div class="stat-value">${fmtMoney(r.finance.profit)}</div><div class="stat-footer">本月 ${fmtMoney(r.finance.monthlyProfit)}</div></div>
      <div class="stat-card orange"><div class="stat-icon">🛒</div><div class="stat-label">采购总额</div><div class="stat-value">${fmtMoney(r.orders.purchase.amount)}</div></div>
      <div class="stat-card purple"><div class="stat-icon">📈</div><div class="stat-label">销售总额</div><div class="stat-value">${fmtMoney(r.orders.sales.amount)}</div></div>
    </div>
    <div class="dashboard-grid">
      <div class="card"><div class="card-header"><h3>🔥 销量TOP10</h3></div><div class="card-body no-pad"><table><thead><tr><th>编号</th><th>名称</th><th>销量</th><th>金额</th></tr></thead><tbody>${topSellHtml}</tbody></table></div></div>
      <div class="card"><div class="card-header"><h3>💸 采购成本TOP10</h3></div><div class="card-body no-pad"><table><thead><tr><th>编号</th><th>名称</th><th>数量</th><th>金额</th></tr></thead><tbody>${topCostHtml}</tbody></table></div></div>
    </div>
    <div class="card"><div class="card-header"><h3>⚠️ 库存预警</h3></div><div class="card-body no-pad"><table><thead><tr><th>编号</th><th>名称</th><th>当前库存</th><th>最低库存</th></tr></thead><tbody>${r.products.lowStock.map(p=>`<tr><td>${p.code}</td><td class="fw-600">${p.name}</td><td><span class="badge badge-danger">${p.current_stock}</span></td><td class="text-hint">${p.min_stock}</td></tr>`).join('')||'<tr><td colspan="4" class="table-empty">无预警</td></tr>'}</tbody></table></div></div>`;
}

// ===== Audit Log =====
async function pgAudit(){
  const r=await api('/api/audit?days=7');const logs=r.data||r;
  const actionMap={create_product:'创建产品',update_product:'更新产品',delete_product:'删除产品',create_bom:'创建BOM',create_purchase:'创建采购单',purchase_status:'采购状态变更',delete_purchase:'删除采购单',create_sale:'创建销售单',sale_status:'销售状态变更',delete_sale:'删除销售单',scan_in:'扫码入库',scan_out:'扫码出库',stocktake:'库存盘点',create_production:'创建生产单',production_status:'生产状态变更',create_finance:'创建财务记录'};
  const dotClass=a=>a.includes('create')||a.includes('scan_in')?'create':a.includes('delete')?'delete':'update';
  $('#page-content').innerHTML=`<div class="toolbar"><select class="form-select" style="width:auto;padding:8px 12px;border-radius:8px" onchange="filterAudit(this.value)"><option value="7">近7天</option><option value="30">近30天</option><option value="1">今天</option></select></div><div class="card"><div class="card-body"><ul class="activity-list" id="audit-list">${logs.map(a=>`<li class="activity-item"><div class="activity-dot ${dotClass(a.action)}"></div><div style="flex:1"><div><strong>${a.user_id||'system'}</strong> ${actionMap[a.action]||a.action}</div><div class="text-hint text-xs" style="word-break:break-all">${a.detail}</div></div><div class="activity-time">${fmtDate(a.created_at)}</div></li>`).join('')||'<li class="text-hint text-center" style="padding:20px">暂无操作记录</li>'}</ul></div></div>`}
async function filterAudit(days){const r=await api(`/api/audit?days=${days}`);const logs=r.data||r;const actionMap={create_product:'创建产品',update_product:'更新产品',delete_product:'删除产品',create_bom:'创建BOM',create_purchase:'创建采购单',purchase_status:'采购状态变更',delete_purchase:'删除采购单',create_sale:'创建销售单',sale_status:'销售状态变更',delete_sale:'删除销售单',scan_in:'扫码入库',scan_out:'扫码出库',stocktake:'库存盘点',create_production:'创建生产单',production_status:'生产状态变更',create_finance:'创建财务记录'};const dotClass=a=>a.includes('create')||a.includes('scan_in')?'create':a.includes('delete')?'delete':'update';$('#audit-list').innerHTML=logs.map(a=>`<li class="activity-item"><div class="activity-dot ${dotClass(a.action)}"></div><div style="flex:1"><div><strong>${a.user_id||'system'}</strong> ${actionMap[a.action]||a.action}</div><div class="text-hint text-xs" style="word-break:break-all">${a.detail}</div></div><div class="activity-time">${fmtDate(a.created_at)}</div></li>`).join('')||'<li class="text-hint text-center" style="padding:20px">暂无操作记录</li>'}

// ===== Mobile Orders =====
function showMobileOrders(){
  openModal('订单入口',`
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
      <button class="btn btn-primary btn-lg" onclick="closeModal();nav('procurement')" style="flex-direction:column;height:80px;justify-content:center;gap:6px">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 002 1.61h9.72a2 2 0 002-1.61L23 6H6"/></svg>
        <span>采购管理</span>
      </button>
      <button class="btn btn-warning btn-lg" onclick="closeModal();nav('sales')" style="flex-direction:column;height:80px;justify-content:center;gap:6px">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6"/></svg>
        <span>销售管理</span>
      </button>
      <button class="btn btn-success btn-lg" onclick="closeModal();nav('production')" style="flex-direction:column;height:80px;justify-content:center;gap:6px">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14.7 6.3a1 1 0 000 1.4l1.6 1.6a1 1 0 001.4 0l3.77-3.77a6 6 0 01-7.94 7.94l-6.91 6.91a2.12 2.12 0 01-3-3l6.91-6.91a6 6 0 017.94-7.94l-3.76 3.76z"/></svg>
        <span>生产管理</span>
      </button>
      <button class="btn btn-outline btn-lg" onclick="closeModal();nav('finance')" style="flex-direction:column;height:80px;justify-content:center;gap:6px">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="1" y="4" width="22" height="16" rx="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>
        <span>财务管理</span>
      </button>
    </div>`);
}

// ===== Keyboard Shortcuts Help =====
function showShortcuts(){
  openModal('键盘快捷键',`
    <div style="display:grid;gap:10px">
      <div style="display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid var(--border-light)"><span>全局搜索</span><span class="kbd">Ctrl + K</span></div>
      <div style="display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid var(--border-light)"><span>扫码页面</span><span class="kbd">Alt + S</span></div>
      <div style="display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid var(--border-light)"><span>新增记录</span><span class="kbd">Alt + N</span></div>
      <div style="display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid var(--border-light)"><span>关闭弹窗</span><span class="kbd">Esc</span></div>
      <div style="display:flex;justify-content:space-between;padding:8px 0"><span>确认操作</span><span class="kbd">Enter</span></div>
    </div>
    <div style="padding:16px 24px;border-top:1px solid var(--border);display:flex;justify-content:flex-end"><button class="btn btn-outline" onclick="closeModal()">关闭</button></div>`);
}

// ===== Clock =====
function updateClock(){const el=$('#clock');if(el)el.textContent=new Date().toLocaleString('zh-CN',{year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:false})}

// ===== Init =====
document.addEventListener('DOMContentLoaded',async()=>{
  try{const s=await api('/api/auth/status');if(!s.authenticated){window.location.href='/login.html';return}}catch(e){return}
  try{const d=await api('/api/dashboard');$('#sidebar-user').innerHTML=`<span>👤 管理员</span> <span class="kbd" onclick="showShortcuts()" style="cursor:pointer" title="快捷键">⌨</span>`}catch(e){}
  buildSidebar();pgDashboard();updateClock();setInterval(updateClock,1000);
  // Mobile: highlight current nav
  updateMobileNav('dashboard');
});
function updateMobileNav(page){
  $$('.mob-nav-item').forEach(b=>b.classList.toggle('active',b.dataset.mob===page));
}
