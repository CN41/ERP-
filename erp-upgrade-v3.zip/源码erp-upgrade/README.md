# ERP管理系统 v3.0

**深度参考立创ERP（szlcsc.com/lcerp）全功能升级改造**

## 升级对照表

### 🔐 安全体系（全面加固）

| 项目 | 改造 |
|------|------|
| 认证 | Session 登录 + 自动401跳转 |
| 防护 | Helmet CSP/XSS + CORS 禁止 + Rate Limiting |
| 校验 | 全 API 参数验证 + XSS 字符过滤 |
| 审计 | 全操作 audit_logs + 用户追踪 |
| SQL | 统一 prepared statements |

### 📦 仓储管理（参考立创ERP多仓库架构）

| 特性 | 说明 |
|------|------|
| 多仓库 | warehouses 表 + 产品关联 warehouse_id |
| 库位管理 | locations 表，按仓库组织 |
| 库存占用 | occupied_stock 字段，销售下单自动占用 |
| 可用库存 | available = current - occupied（立创ERP核心概念）|
| 警戒库存 | min_stock + max_stock 上下限 |
| 自动补货 | auto_replenish 标记，低库存自动生成采购需求 |
| 批次管理 | batches 表，入库时自动记录批次 |

### 🏭 生产管理（参考立创ERP MRP系统）

| 特性 | 说明 |
|------|------|
| BOM 审核 | draft → approved → disabled 三态流转 |
| BOM 版本 | version 字段 + 复制BOM功能 |
| 替换料 | bom_alternatives 表，支持备用物料 |
| BOM 损耗率 | loss_rate 字段，自动计入损耗 |
| MRP 计算 | 创建生产单时自动计算物料需求/缺口 |
| 分批完工 | partial_completed 状态，支持部分入库 |
| 尾料回库 | return-materials 接口，按完工比例退料 |
| 领料出库 | 开工时自动扣减原材料库存 |

### 🛒 采购管理（参考立创ERP分批入库）

| 特性 | 说明 |
|------|------|
| 分批入库 | received_qty 逐项跟踪，partial_received 状态 |
| 分批付款 | paid_amount 累加，未付款一目了然 |
| 标签系统 | tag 字段，自定义标记（紧急/VIP等）|
| 采购来源 | source 字段区分手动/自动生成 |
| 采购退货 | purchase_returns 完整退货流程 |
| 采购需求 | purchase_demands，MRP/警戒自动生成 |

### 💰 销售管理（参考立创ERP分批出库）

| 特性 | 说明 |
|------|------|
| 库存占用 | 下单时自动占用库存 occupied_stock |
| 分批出库 | shipped_qty 逐项跟踪，partial_shipped 状态 |
| 分批收款 | paid_amount 累加 |
| 标签系统 | tag 字段 |
| 销售退货 | sales_returns，退货自动释放占用+回库 |

### 🔄 库存调拨（参考立创ERP调拨模块）

| 特性 | 说明 |
|------|------|
| 调拨单 | stock_transfers + stock_transfer_items |
| 仓库间流转 | 自动出库→入库，movement 记录 |
| 状态管理 | draft → confirmed → completed |

### 📊 数据报表（增强）

| 报表 | 内容 |
|------|------|
| 工作台 | KPI 卡片 + 月度收支环形图 + 7日趋势 + 最近操作 |
| 库存报表 | 分类价值、7日趋势、预警列表 |
| 财务报表 | 6月趋势 + 未收/未付款统计 |
| 综合报表 | 销量/采购 TOP10 + 预警汇总 |

### 🏷️ 标签系统

| 特性 | 说明 |
|------|------|
| 自定义标签 | tags 表，名称+颜色 |
| 预置标签 | 紧急(红)、VIP(紫)、待跟进(橙) |
| 订单标记 | 采购/销售单支持 tag 标记 |

## 数据库架构（19张表）

```
warehouses          ── 仓库
locations           ── 库位
products            ── 产品物料（+occupied_stock,max_stock,auto_replenish,warehouse_id,package）
batches             ── 批次（NEW）
bom                 ── BOM主表（+version,status审核）
bom_items           ── BOM明细（+loss_rate损耗率）
bom_alternatives    ── 替换料（NEW）
contacts            ── 联系人
purchase_orders     ── 采购单（+paid_amount,tag,source,partial状态）
purchase_order_items ── 采购明细（+received_qty）
purchase_returns    ── 采购退货（NEW）
purchase_return_items ── 采购退货明细（NEW）
purchase_demands    ── 采购需求（NEW,MRP自动生成）
sales_orders        ── 销售单（+paid_amount,tag,partial状态）
sales_order_items   ── 销售明细（+shipped_qty）
sales_returns       ── 销售退货（NEW）
sales_return_items  ── 销售退货明细（NEW）
production_orders   ── 生产工单（+bom_id,completed_qty）
production_materials ── 生产用料（+returned_qty）
stock_transfers     ── 调拨单（NEW）
stock_transfer_items ── 调拨明细（NEW）
stock_movements     ── 出入库流水（+transfer/return类型）
finance_records     ── 财务记录
tags                ── 标签（NEW）
audit_logs          ── 操作日志
```

## API 路由（25个模块）

| 路由 | 说明 |
|------|------|
| /api/auth | 登录/退出/状态 |
| /api/products | 产品CRUD + 搜索 + 警戒 + 分类 |
| /api/bom | BOM管理 + MRP计算 + 审核 + 复制 + 替换料 |
| /api/contacts | 联系人管理 |
| /api/procurement | 采购管理 + 分批入库 + 付款 |
| /api/sales | 销售管理 + 分批出库 + 收款 |
| /api/production | 生产管理 + MRP + 分批完工 + 退料 |
| /api/inventory | 库存 + 出入库 + 扫码 + 盘点 + 报表 |
| /api/finance | 财务 + 趋势 + 未收付款 |
| /api/dashboard | 工作台数据聚合 |
| /api/warehouses | 仓库 + 库位管理 |
| /api/transfers | 库存调拨 |
| /api/returns | 销售退货 + 采购退货 |
| /api/demands | 采购需求（MRP自动生成）|
| /api/tags | 标签管理 |
| /api/reports | 综合报表 |
| /api/audit | 操作日志 |

## 快速开始

```bash
cd erp-upgrade
npm install
npm start
# http://localhost:3000
# admin / admin123
```

环境变量：
```bash
PORT=3000          ERP_USER=admin    ERP_PASS=admin123    ERP_SECRET=your-secret
```

## 文件结构（24个文件，~2400行）

```
├── server.js                    入口 + 安全中间件 + 认证 + 路由
├── db-init.js                   19表 + 索引 + 示例数据
├── package.json                 7个依赖
├── routes/ (15 files)
│   ├── products.js              产品（可用库存/警戒/搜索）
│   ├── bom.js                   BOM（审核/MRP/复制/替换料）
│   ├── contacts.js              联系人
│   ├── procurement.js           采购（分批入库/付款）
│   ├── sales.js                 销售（占用库存/分批出库/收款）
│   ├── production.js            生产（MRP/分批完工/退料）
│   ├── inventory.js             库存（多仓库/批次/盘点）
│   ├── finance.js               财务（趋势/未收付款）
│   ├── dashboard.js             工作台
│   ├── warehouses.js            仓库+库位
│   ├── transfers.js             调拨
│   ├── returns.js               退货
│   ├── demands.js               采购需求
│   ├── tags.js                  标签
│   ├── reports.js               报表
│   └── audit.js                 日志
├── public/
│   ├── login.html               登录页
│   ├── index.html               SPA
│   ├── css/style.css            样式
│   └── js/app.js                前端逻辑
└── start.bat                    Windows启动
```
