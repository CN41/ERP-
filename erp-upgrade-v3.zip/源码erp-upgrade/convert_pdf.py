#!/usr/bin/env python3
"""Convert markdown files to PDF with Chinese font support using fpdf2"""
import re, sys, os
from fpdf import FPDF

FONT_REGULAR = '/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
FONT_BOLD = '/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc'
FONT_MONO = '/usr/share/fonts/truetype/noto/NotoSansMono-Regular.ttf'

class MarkdownPDF(FPDF):
    def __init__(self):
        super().__init__()
        self.add_font('noto', '', FONT_REGULAR, uni=True)
        self.add_font('noto', 'B', FONT_BOLD, uni=True)
        self.add_font('mono', '', FONT_MONO, uni=True)
        self.set_auto_page_break(auto=True, margin=20)

    def write_markdown(self, md_text):
        lines = md_text.split('\n')
        in_table = False
        in_code = False
        code_lines = []

        for line in lines:
            # Code blocks
            if line.strip().startswith('```'):
                if in_code:
                    self._write_code_block('\n'.join(code_lines))
                    code_lines = []
                    in_code = False
                else:
                    in_code = True
                continue
            if in_code:
                code_lines.append(line)
                continue

            # Table
            if '|' in line and line.strip().startswith('|'):
                if not in_table:
                    in_table = True
                    self._table_rows = []
                # Skip separator row
                if re.match(r'^\|[\s\-:|]+\|$', line.strip()):
                    continue
                cells = [c.strip() for c in line.strip().strip('|').split('|')]
                self._table_rows.append(cells)
                continue
            else:
                if in_table:
                    self._write_table()
                    in_table = False

            stripped = line.strip()

            # Empty line
            if not stripped:
                self.ln(3)
                continue

            # Headers
            if stripped.startswith('#'):
                level = len(stripped) - len(stripped.lstrip('#'))
                text = stripped.lstrip('# ').strip()
                self._write_heading(text, level)
                continue

            # Horizontal rule
            if stripped in ('---', '***', '___'):
                self.ln(3)
                self.set_draw_color(200, 200, 200)
                self.line(self.l_margin, self.get_y(), self.w - self.r_margin, self.get_y())
                self.ln(5)
                continue

            # List items
            if re.match(r'^[\-\*]\s', stripped) or re.match(r'^\d+\.\s', stripped):
                text = re.sub(r'^[\-\*]\s*', '', stripped)
                text = re.sub(r'^\d+\.\s*', '', text)
                self._write_list_item(text)
                continue

            # Normal paragraph
            self._write_paragraph(stripped)

        if in_code and code_lines:
            self._write_code_block('\n'.join(code_lines))
        if in_table:
            self._write_table()

    def _write_heading(self, text, level):
        sizes = {1: 22, 2: 17, 3: 14, 4: 12, 5: 11}
        size = sizes.get(level, 10)
        self.ln(6 if level <= 2 else 4)
        self.set_font('noto', 'B', size)
        self.set_text_color(30, 41, 59)
        # Clean markdown bold/italic
        text = re.sub(r'\*\*(.*?)\*\*', r'\1', text)
        text = re.sub(r'\*(.*?)\*', r'\1', text)
        self.cell(0, size + 4, text, new_x="LMARGIN", new_y="NEXT")
        if level <= 2:
            self.set_draw_color(79, 110, 247)
            self.set_line_width(0.5)
            self.line(self.l_margin, self.get_y(), self.l_margin + 40, self.get_y())
        self.ln(4)
        self.set_text_color(0, 0, 0)

    def _write_paragraph(self, text):
        self.set_font('noto', '', 10)
        self.set_text_color(30, 41, 59)
        # Handle inline code
        text = re.sub(r'`([^`]+)`', r'\1', text)
        # Handle bold
        text = re.sub(r'\*\*(.*?)\*\*', r'\1', text)
        text = re.sub(r'\*(.*?)\*', r'\1', text)
        # Handle links
        text = re.sub(r'\[([^\]]+)\]\([^)]+\)', r'\1', text)
        self.multi_cell(0, 6, text)
        self.ln(2)

    def _write_list_item(self, text):
        self.set_font('noto', '', 10)
        self.set_text_color(30, 41, 59)
        text = re.sub(r'`([^`]+)`', r'\1', text)
        text = re.sub(r'\*\*(.*?)\*\*', r'\1', text)
        x = self.get_x()
        self.cell(8, 6, '•')
        self.multi_cell(0, 6, text)
        self.ln(1)

    def _write_code_block(self, code):
        self.ln(3)
        self.set_fill_color(241, 245, 249)
        self.set_font('mono', '', 8.5)
        self.set_text_color(51, 65, 85)
        lines = code.split('\n')
        h = len(lines) * 5 + 6
        x = self.get_x()
        y = self.get_y()
        # Check if we need a new page
        if y + h > self.h - self.b_margin:
            self.add_page()
            y = self.get_y()
        self.rect(x, y, self.w - self.l_margin - self.r_margin, h, 'F')
        self.set_xy(x + 4, y + 3)
        for line in lines:
            self.cell(0, 5, line, new_x="LMARGIN", new_y="NEXT")
            self.set_x(x + 4)
        self.set_xy(x, y + h + 3)
        self.set_text_color(0, 0, 0)
        self.ln(2)

    def _write_table(self):
        if not hasattr(self, '_table_rows') or not self._table_rows:
            return
        rows = self._table_rows
        if not rows:
            return

        # Calculate column widths
        num_cols = max(len(r) for r in rows)
        avail_w = self.w - self.l_margin - self.r_margin
        col_w = avail_w / num_cols

        self.ln(3)
        self.set_font('noto', '', 9)

        for i, row in enumerate(rows):
            if self.get_y() > self.h - self.b_margin - 20:
                self.add_page()

            max_h = 6
            # Calculate row height
            for j, cell in enumerate(row):
                if j >= num_cols:
                    break
                lines = self.multi_cell(col_w, 6, cell, split_only=True)
                max_h = max(max_h, len(lines) * 6)

            # Header row
            if i == 0:
                self.set_fill_color(241, 245, 249)
                self.set_font('noto', 'B', 9)
            else:
                self.set_fill_color(255, 255, 255)
                self.set_font('noto', '', 9)

            x_start = self.get_x()
            y_start = self.get_y()

            for j, cell in enumerate(row):
                if j >= num_cols:
                    break
                self.set_xy(x_start + j * col_w, y_start)
                self.cell(col_w, max_h, cell, border=1, fill=True, align='L' if j == 0 else 'C')

            self.set_xy(x_start, y_start + max_h)

        self._table_rows = []
        self.ln(4)

    def footer(self):
        self.set_y(-15)
        self.set_font('noto', '', 8)
        self.set_text_color(148, 163, 184)
        self.cell(0, 10, f'ERP管理系统 v3.0  |  第 {self.page_no()} 页', align='C')


def convert(md_path, pdf_path):
    with open(md_path, 'r', encoding='utf-8') as f:
        md = f.read()

    pdf = MarkdownPDF()
    pdf.add_page()
    pdf.write_markdown(md)
    pdf.output(pdf_path)
    print(f'  ✅ {pdf_path} ({os.path.getsize(pdf_path)//1024}KB)')


if __name__ == '__main__':
    base = os.path.dirname(os.path.abspath(__file__))
    os.chdir(base)
    convert('项目报告.md', '项目报告.pdf')
    convert('使用说明.md', '使用说明.pdf')
    print('  Done!')
