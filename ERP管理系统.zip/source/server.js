const express = require('express');
const path = require('path');
const Database = require('better-sqlite3');
const os = require('os');

const app = express();
const PORT = process.env.PORT || 3000;

// 数据库初始化
const dbPath = path.join(os.homedir(), 'erp-data.db');
const db = new Database(dbPath);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

// 初始化表结构
require('./db-init')(db);

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// 注入 db 到请求
app.use((req, res, next) => { req.db = db; next(); });

// API 路由
app.use('/api/products', require('./routes/products'));
app.use('/api/bom', require('./routes/bom'));
app.use('/api/procurement', require('./routes/procurement'));
app.use('/api/sales', require('./routes/sales'));
app.use('/api/inventory', require('./routes/inventory'));
app.use('/api/contacts', require('./routes/contacts'));
app.use('/api/finance', require('./routes/finance'));
app.use('/api/dashboard', require('./routes/dashboard'));

// SPA fallback
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, '0.0.0.0', () => {
  console.log('');
  console.log('  ERP System Started!');
  console.log('  http://localhost:' + PORT);
  console.log('');
  // 自动打开浏览器
  const { exec } = require('child_process');
  const url = `http://localhost:${PORT}`;
  if (process.platform === 'win32') exec(`start ${url}`);
  else if (process.platform === 'darwin') exec(`open ${url}`);
  else exec(`xdg-open ${url}`);
});
