module.exports = function(db) {
  db.exec(`
    CREATE TABLE IF NOT EXISTS products (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      code TEXT UNIQUE NOT NULL,
      name TEXT NOT NULL,
      barcode TEXT DEFAULT '',
      category TEXT DEFAULT '',
      unit TEXT DEFAULT '个',
      spec TEXT DEFAULT '',
      cost_price REAL DEFAULT 0,
      sale_price REAL DEFAULT 0,
      min_stock INTEGER DEFAULT 0,
      current_stock INTEGER DEFAULT 0,
      supplier TEXT DEFAULT '',
      remark TEXT DEFAULT '',
      status INTEGER DEFAULT 1,
      created_at TEXT DEFAULT (datetime('now','localtime')),
      updated_at TEXT DEFAULT (datetime('now','localtime'))
    );

    CREATE TABLE IF NOT EXISTS bom (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      product_id INTEGER NOT NULL,
      material_id INTEGER NOT NULL,
      quantity REAL NOT NULL DEFAULT 1,
      remark TEXT DEFAULT '',
      FOREIGN KEY (product_id) REFERENCES products(id),
      FOREIGN KEY (material_id) REFERENCES products(id)
    );

    CREATE TABLE IF NOT EXISTS contacts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      type TEXT CHECK(type IN ('customer','supplier','both')) DEFAULT 'customer',
      name TEXT NOT NULL,
      contact_person TEXT DEFAULT '',
      phone TEXT DEFAULT '',
      email TEXT DEFAULT '',
      address TEXT DEFAULT '',
      remark TEXT DEFAULT '',
      status INTEGER DEFAULT 1,
      created_at TEXT DEFAULT (datetime('now','localtime'))
    );

    CREATE TABLE IF NOT EXISTS purchase_orders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_no TEXT UNIQUE NOT NULL,
      supplier_id INTEGER,
      total_amount REAL DEFAULT 0,
      status TEXT CHECK(status IN ('draft','confirmed','received','cancelled')) DEFAULT 'draft',
      remark TEXT DEFAULT '',
      created_at TEXT DEFAULT (datetime('now','localtime')),
      updated_at TEXT DEFAULT (datetime('now','localtime')),
      FOREIGN KEY (supplier_id) REFERENCES contacts(id)
    );

    CREATE TABLE IF NOT EXISTS purchase_order_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_id INTEGER NOT NULL,
      product_id INTEGER NOT NULL,
      quantity REAL NOT NULL,
      unit_price REAL NOT NULL,
      amount REAL GENERATED ALWAYS AS (quantity * unit_price) STORED,
      FOREIGN KEY (order_id) REFERENCES purchase_orders(id),
      FOREIGN KEY (product_id) REFERENCES products(id)
    );

    CREATE TABLE IF NOT EXISTS sales_orders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_no TEXT UNIQUE NOT NULL,
      customer_id INTEGER,
      total_amount REAL DEFAULT 0,
      status TEXT CHECK(status IN ('draft','confirmed','shipped','completed','cancelled')) DEFAULT 'draft',
      remark TEXT DEFAULT '',
      created_at TEXT DEFAULT (datetime('now','localtime')),
      updated_at TEXT DEFAULT (datetime('now','localtime')),
      FOREIGN KEY (customer_id) REFERENCES contacts(id)
    );

    CREATE TABLE IF NOT EXISTS sales_order_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_id INTEGER NOT NULL,
      product_id INTEGER NOT NULL,
      quantity REAL NOT NULL,
      unit_price REAL NOT NULL,
      amount REAL GENERATED ALWAYS AS (quantity * unit_price) STORED,
      FOREIGN KEY (order_id) REFERENCES sales_orders(id),
      FOREIGN KEY (product_id) REFERENCES products(id)
    );

    CREATE TABLE IF NOT EXISTS stock_movements (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      product_id INTEGER NOT NULL,
      type TEXT CHECK(type IN ('in','out')) NOT NULL,
      quantity REAL NOT NULL,
      related_order TEXT DEFAULT '',
      remark TEXT DEFAULT '',
      created_at TEXT DEFAULT (datetime('now','localtime')),
      FOREIGN KEY (product_id) REFERENCES products(id)
    );

    CREATE TABLE IF NOT EXISTS finance_records (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      type TEXT CHECK(type IN ('income','expense')) NOT NULL,
      category TEXT DEFAULT '',
      amount REAL NOT NULL,
      related_order TEXT DEFAULT '',
      contact_id INTEGER,
      remark TEXT DEFAULT '',
      created_at TEXT DEFAULT (datetime('now','localtime')),
      FOREIGN KEY (contact_id) REFERENCES contacts(id)
    );
  `);

  // 插入示例数据（仅首次）
  const count = db.prepare('SELECT COUNT(*) as c FROM products').get();
  if (count.c === 0) {
    const insertProduct = db.prepare('INSERT INTO products (code,name,category,unit,spec,cost_price,sale_price,min_stock,current_stock,barcode) VALUES (?,?,?,?,?,?,?,?,?,?)');
    insertProduct.run('M001', '电阻 10KΩ', '电子元件', '个', '0805', 0.01, 0.05, 1000, 5000, 'BC0010001');
    insertProduct.run('M002', '电容 100nF', '电子元件', '个', '0805', 0.02, 0.08, 500, 3000, 'BC0010002');
    insertProduct.run('M003', 'STM32F103C8T6', '芯片', '个', 'LQFP-48', 8.5, 15, 50, 200, 'BC0020001');
    insertProduct.run('M004', 'PCB板 5x5cm', 'PCB', '片', '双层', 2.0, 5.0, 100, 500, 'BC0030001');
    insertProduct.run('P001', '开发板 V1.0', '成品', '块', '', 18, 35, 10, 50, 'BC1000001');

    const insertBom = db.prepare('INSERT INTO bom (product_id,material_id,quantity) VALUES (?,?,?)');
    insertBom.run(5, 1, 8);
    insertBom.run(5, 2, 6);
    insertBom.run(5, 3, 1);
    insertBom.run(5, 4, 1);

    const insertContact = db.prepare('INSERT INTO contacts (type,name,contact_person,phone) VALUES (?,?,?,?)');
    insertContact.run('supplier', '深圳元器件有限公司', '张三', '13800001111');
    insertContact.run('customer', '北京科技公司', '李四', '13900002222');

    console.log('  [OK] Sample data initialized');
  }
};
