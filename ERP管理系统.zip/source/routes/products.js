const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
  const { category, keyword, status } = req.query;
  let sql = 'SELECT * FROM products WHERE 1=1';
  const params = [];
  if (category) { sql += ' AND category = ?'; params.push(category); }
  if (keyword) { sql += ' AND (code LIKE ? OR name LIKE ? OR barcode LIKE ?)'; params.push(`%${keyword}%`, `%${keyword}%`, `%${keyword}%`); }
  if (status !== undefined && status !== '') { sql += ' AND status = ?'; params.push(Number(status)); }
  sql += ' ORDER BY id DESC';
  res.json(req.db.prepare(sql).all(...params));
});

router.get('/categories', (req, res) => {
  res.json(req.db.prepare("SELECT DISTINCT category FROM products WHERE category != ''").all().map(r => r.category));
});

router.get('/:id', (req, res) => {
  const row = req.db.prepare('SELECT * FROM products WHERE id = ?').get(req.params.id);
  row ? res.json(row) : res.status(404).json({ error: '未找到' });
});

router.post('/', (req, res) => {
  const { code, name, category, unit, spec, cost_price, sale_price, min_stock, supplier, remark, barcode } = req.body;
  try {
    const r = req.db.prepare('INSERT INTO products (code,name,category,unit,spec,cost_price,sale_price,min_stock,supplier,remark,barcode) VALUES (?,?,?,?,?,?,?,?,?,?,?)')
      .run(code, name, category||'', unit||'个', spec||'', cost_price||0, sale_price||0, min_stock||0, supplier||'', remark||'', barcode||'');
    res.json({ id: r.lastInsertRowid, message: '添加成功' });
  } catch(e) { res.status(400).json({ error: e.message }); }
});

router.put('/:id', (req, res) => {
  const { code, name, category, unit, spec, cost_price, sale_price, min_stock, current_stock, supplier, remark, status, barcode } = req.body;
  req.db.prepare(`UPDATE products SET code=?,name=?,category=?,unit=?,spec=?,cost_price=?,sale_price=?,min_stock=?,current_stock=?,supplier=?,remark=?,status=?,barcode=?,updated_at=datetime('now','localtime') WHERE id=?`)
    .run(code, name, category, unit, spec, cost_price, sale_price, min_stock, current_stock, supplier, remark, status, barcode||'', req.params.id);
  res.json({ message: '更新成功' });
});

router.delete('/:id', (req, res) => {
  req.db.prepare('DELETE FROM products WHERE id = ?').run(req.params.id);
  res.json({ message: '删除成功' });
});

module.exports = router;
