const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
  const rows = req.db.prepare(`
    SELECT b.*, p.code as product_code, p.name as product_name,
           m.code as material_code, m.name as material_name, m.unit as material_unit, m.cost_price as material_cost
    FROM bom b
    JOIN products p ON b.product_id = p.id
    JOIN products m ON b.material_id = m.id
    ORDER BY b.product_id
  `).all();
  res.json(rows);
});

router.get('/product/:pid', (req, res) => {
  const rows = req.db.prepare(`
    SELECT b.*, m.code as material_code, m.name as material_name, m.unit as material_unit, m.cost_price as material_cost
    FROM bom b JOIN products m ON b.material_id = m.id
    WHERE b.product_id = ?
  `).all(req.params.pid);
  res.json(rows);
});

router.post('/', (req, res) => {
  const { product_id, material_id, quantity, remark } = req.body;
  const r = req.db.prepare('INSERT INTO bom (product_id,material_id,quantity,remark) VALUES (?,?,?,?)')
    .run(product_id, material_id, quantity||1, remark||'');
  res.json({ id: r.lastInsertRowid });
});

router.put('/:id', (req, res) => {
  const { quantity, remark } = req.body;
  req.db.prepare('UPDATE bom SET quantity=?, remark=? WHERE id=?').run(quantity, remark, req.params.id);
  res.json({ message: '更新成功' });
});

router.delete('/:id', (req, res) => {
  req.db.prepare('DELETE FROM bom WHERE id=?').run(req.params.id);
  res.json({ message: '删除成功' });
});

module.exports = router;
