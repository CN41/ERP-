const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
  const rows = req.db.prepare(`
    SELECT po.*, c.name as supplier_name
    FROM purchase_orders po LEFT JOIN contacts c ON po.supplier_id = c.id
    ORDER BY po.id DESC
  `).all();
  res.json(rows);
});

router.get('/:id', (req, res) => {
  const order = req.db.prepare('SELECT po.*, c.name as supplier_name FROM purchase_orders po LEFT JOIN contacts c ON po.supplier_id=c.id WHERE po.id=?').get(req.params.id);
  if (!order) return res.status(404).json({ error: '未找到' });
  order.items = req.db.prepare(`
    SELECT poi.*, p.code as product_code, p.name as product_name, p.unit
    FROM purchase_order_items poi JOIN products p ON poi.product_id=p.id
    WHERE poi.order_id=?
  `).all(req.params.id);
  res.json(order);
});

router.post('/', (req, res) => {
  const { supplier_id, items, remark } = req.body;
  const order_no = 'PO' + Date.now().toString().slice(-8);
  const total = items.reduce((s, i) => s + i.quantity * i.unit_price, 0);
  const r = req.db.prepare('INSERT INTO purchase_orders (order_no,supplier_id,total_amount,remark) VALUES (?,?,?,?)')
    .run(order_no, supplier_id, total, remark||'');
  const insertItem = req.db.prepare('INSERT INTO purchase_order_items (order_id,product_id,quantity,unit_price) VALUES (?,?,?,?)');
  items.forEach(i => insertItem.run(r.lastInsertRowid, i.product_id, i.quantity, i.unit_price));
  res.json({ id: r.lastInsertRowid, order_no });
});

router.put('/:id/status', (req, res) => {
  const { status } = req.body;
  const order = req.db.prepare('SELECT * FROM purchase_orders WHERE id=?').get(req.params.id);
  if (!order) return res.status(404).json({ error: '未找到' });

  // 入库操作
  if (status === 'received' && order.status !== 'received') {
    const items = req.db.prepare('SELECT * FROM purchase_order_items WHERE order_id=?').all(req.params.id);
    const updateStock = req.db.prepare('UPDATE products SET current_stock=current_stock+? WHERE id=?');
    const insertLog = req.db.prepare('INSERT INTO stock_movements (product_id,type,quantity,related_order,remark) VALUES (?,?,?,?,?)');
    items.forEach(i => {
      updateStock.run(i.quantity, i.product_id);
      insertLog.run(i.product_id, 'in', i.quantity, order.order_no, '采购入库');
    });
    req.db.prepare("INSERT INTO finance_records (type,category,amount,related_order,contact_id,remark) SELECT 'expense','采购',total_amount,order_no,supplier_id,'采购支出' FROM purchase_orders WHERE id=?").run(req.params.id);
  }
  req.db.prepare("UPDATE purchase_orders SET status=?,updated_at=datetime('now','localtime') WHERE id=?").run(status, req.params.id);
  res.json({ message: '状态已更新' });
});

router.delete('/:id', (req, res) => {
  req.db.prepare('DELETE FROM purchase_order_items WHERE order_id=?').run(req.params.id);
  req.db.prepare('DELETE FROM purchase_orders WHERE id=?').run(req.params.id);
  res.json({ message: '删除成功' });
});

module.exports = router;
