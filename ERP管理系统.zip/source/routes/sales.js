const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
  const rows = req.db.prepare(`
    SELECT so.*, c.name as customer_name
    FROM sales_orders so LEFT JOIN contacts c ON so.customer_id=c.id
    ORDER BY so.id DESC
  `).all();
  res.json(rows);
});

router.get('/:id', (req, res) => {
  const order = req.db.prepare('SELECT so.*, c.name as customer_name FROM sales_orders so LEFT JOIN contacts c ON so.customer_id=c.id WHERE so.id=?').get(req.params.id);
  if (!order) return res.status(404).json({ error: '未找到' });
  order.items = req.db.prepare(`
    SELECT soi.*, p.code as product_code, p.name as product_name, p.unit
    FROM sales_order_items soi JOIN products p ON soi.product_id=p.id
    WHERE soi.order_id=?
  `).all(req.params.id);
  res.json(order);
});

router.post('/', (req, res) => {
  const { customer_id, items, remark } = req.body;
  const order_no = 'SO' + Date.now().toString().slice(-8);
  const total = items.reduce((s, i) => s + i.quantity * i.unit_price, 0);
  const r = req.db.prepare('INSERT INTO sales_orders (order_no,customer_id,total_amount,remark) VALUES (?,?,?,?)')
    .run(order_no, customer_id, total, remark||'');
  const insertItem = req.db.prepare('INSERT INTO sales_order_items (order_id,product_id,quantity,unit_price) VALUES (?,?,?,?)');
  items.forEach(i => insertItem.run(r.lastInsertRowid, i.product_id, i.quantity, i.unit_price));
  res.json({ id: r.lastInsertRowid, order_no });
});

router.put('/:id/status', (req, res) => {
  const { status } = req.body;
  const order = req.db.prepare('SELECT * FROM sales_orders WHERE id=?').get(req.params.id);
  if (!order) return res.status(404).json({ error: '未找到' });

  if (status === 'shipped' && order.status !== 'shipped') {
    const items = req.db.prepare('SELECT * FROM sales_order_items WHERE order_id=?').all(req.params.id);
    const updateStock = req.db.prepare('UPDATE products SET current_stock=current_stock-? WHERE id=?');
    const insertLog = req.db.prepare('INSERT INTO stock_movements (product_id,type,quantity,related_order,remark) VALUES (?,?,?,?,?)');
    items.forEach(i => {
      updateStock.run(i.quantity, i.product_id);
      insertLog.run(i.product_id, 'out', i.quantity, order.order_no, '销售出库');
    });
  }
  if (status === 'completed' && order.status !== 'completed') {
    req.db.prepare("INSERT INTO finance_records (type,category,amount,related_order,contact_id,remark) SELECT 'income','销售',total_amount,order_no,customer_id,'销售收款' FROM sales_orders WHERE id=?").run(req.params.id);
  }
  req.db.prepare("UPDATE sales_orders SET status=?,updated_at=datetime('now','localtime') WHERE id=?").run(status, req.params.id);
  res.json({ message: '状态已更新' });
});

router.delete('/:id', (req, res) => {
  req.db.prepare('DELETE FROM sales_order_items WHERE order_id=?').run(req.params.id);
  req.db.prepare('DELETE FROM sales_orders WHERE id=?').run(req.params.id);
  res.json({ message: '删除成功' });
});

module.exports = router;
