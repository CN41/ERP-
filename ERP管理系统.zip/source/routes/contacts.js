const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
  const { type, keyword } = req.query;
  let sql = 'SELECT * FROM contacts WHERE 1=1';
  const params = [];
  if (type) { sql += ' AND (type=? OR type=?)'; params.push(type, 'both'); }
  if (keyword) { sql += ' AND (name LIKE ? OR contact_person LIKE ? OR phone LIKE ?)'; params.push(`%${keyword}%`, `%${keyword}%`, `%${keyword}%`); }
  sql += ' ORDER BY id DESC';
  res.json(req.db.prepare(sql).all(...params));
});

router.post('/', (req, res) => {
  const { type, name, contact_person, phone, email, address, remark } = req.body;
  const r = req.db.prepare('INSERT INTO contacts (type,name,contact_person,phone,email,address,remark) VALUES (?,?,?,?,?,?,?)')
    .run(type||'customer', name, contact_person||'', phone||'', email||'', address||'', remark||'');
  res.json({ id: r.lastInsertRowid });
});

router.put('/:id', (req, res) => {
  const { type, name, contact_person, phone, email, address, remark, status } = req.body;
  req.db.prepare('UPDATE contacts SET type=?,name=?,contact_person=?,phone=?,email=?,address=?,remark=?,status=? WHERE id=?')
    .run(type, name, contact_person, phone, email, address, remark, status, req.params.id);
  res.json({ message: '更新成功' });
});

router.delete('/:id', (req, res) => {
  req.db.prepare('DELETE FROM contacts WHERE id=?').run(req.params.id);
  res.json({ message: '删除成功' });
});

module.exports = router;
