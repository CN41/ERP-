const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
  const { type, category, days } = req.query;
  let sql = 'SELECT fr.*, c.name as contact_name FROM finance_records fr LEFT JOIN contacts c ON fr.contact_id=c.id WHERE 1=1';
  const params = [];
  if (type) { sql += ' AND fr.type=?'; params.push(type); }
  if (category) { sql += ' AND fr.category=?'; params.push(category); }
  if (days) { sql += ` AND fr.created_at >= datetime('now','localtime','-${days} days')`; }
  sql += ' ORDER BY fr.id DESC';
  res.json(req.db.prepare(sql).all(...params));
});

router.get('/summary', (req, res) => {
  const income = req.db.prepare("SELECT COALESCE(SUM(amount),0) as total FROM finance_records WHERE type='income'").get().total;
  const expense = req.db.prepare("SELECT COALESCE(SUM(amount),0) as total FROM finance_records WHERE type='expense'").get().total;
  const monthly_income = req.db.prepare("SELECT COALESCE(SUM(amount),0) as total FROM finance_records WHERE type='income' AND created_at >= datetime('now','localtime','start of month')").get().total;
  const monthly_expense = req.db.prepare("SELECT COALESCE(SUM(amount),0) as total FROM finance_records WHERE type='expense' AND created_at >= datetime('now','localtime','start of month')").get().total;
  res.json({ income, expense, profit: income - expense, monthly_income, monthly_expense, monthly_profit: monthly_income - monthly_expense });
});

router.post('/', (req, res) => {
  const { type, category, amount, related_order, contact_id, remark } = req.body;
  const r = req.db.prepare('INSERT INTO finance_records (type,category,amount,related_order,contact_id,remark) VALUES (?,?,?,?,?,?)')
    .run(type, category||'', amount, related_order||'', contact_id||null, remark||'');
  res.json({ id: r.lastInsertRowid });
});

router.delete('/:id', (req, res) => {
  req.db.prepare('DELETE FROM finance_records WHERE id=?').run(req.params.id);
  res.json({ message: '删除成功' });
});

module.exports = router;
