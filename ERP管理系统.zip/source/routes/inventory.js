const express = require('express');
const router = express.Router();

// 获取库存列表
router.get('/', (req, res) => {
  const { keyword, category, low_only } = req.query;
  let sql = `SELECT p.*,
    CASE WHEN p.current_stock <= p.min_stock THEN 1 ELSE 0 END as is_low,
    CASE WHEN p.current_stock = 0 THEN 1 ELSE 0 END as is_out
    FROM products p WHERE p.status = 1`;
  const params = [];
  if (keyword) { sql += ' AND (p.code LIKE ? OR p.name LIKE ? OR p.barcode LIKE ?)'; params.push(`%${keyword}%`, `%${keyword}%`, `%${keyword}%`); }
  if (category) { sql += ' AND p.category = ?'; params.push(category); }
  if (low_only === '1') { sql += ' AND p.current_stock <= p.min_stock'; }
  sql += ' ORDER BY is_low DESC, p.category, p.name';
  res.json(req.db.prepare(sql).all(...params));
});

// 出入库记录
router.get('/movements', (req, res) => {
  const { product_id, type, days, keyword } = req.query;
  let sql = `SELECT sm.*, p.code as product_code, p.name as product_name, p.barcode, p.unit
    FROM stock_movements sm JOIN products p ON sm.product_id = p.id WHERE 1=1`;
  const params = [];
  if (product_id) { sql += ' AND sm.product_id = ?'; params.push(product_id); }
  if (type) { sql += ' AND sm.type = ?'; params.push(type); }
  if (days) { sql += ` AND sm.created_at >= datetime('now','localtime','-${Number(days)} days')`; }
  if (keyword) { sql += ' AND (p.code LIKE ? OR p.name LIKE ?)'; params.push(`%${keyword}%`, `%${keyword}%`); }
  sql += ' ORDER BY sm.id DESC LIMIT 500';
  res.json(req.db.prepare(sql).all(...params));
});

// 按条码查找产品
router.get('/barcode/:code', (req, res) => {
  const p = req.db.prepare('SELECT * FROM products WHERE (barcode = ? OR code = ?) AND status = 1').get(req.params.code, req.params.code);
  p ? res.json(p) : res.status(404).json({ error: '未找到该条码对应的产品' });
});

// 扫码出入库
router.post('/scan', (req, res) => {
  const { barcode, type, quantity, remark } = req.body;
  const p = req.db.prepare('SELECT * FROM products WHERE (barcode = ? OR code = ?) AND status = 1').get(barcode, barcode);
  if (!p) return res.status(404).json({ error: '未找到该条码对应的产品' });
  const qty = Number(quantity) || 1;
  const delta = type === 'in' ? qty : -qty;
  const newStock = p.current_stock + delta;
  if (newStock < 0) return res.status(400).json({ error: `库存不足！当前库存: ${p.current_stock}`, current_stock: p.current_stock });
  req.db.prepare('UPDATE products SET current_stock = current_stock + ? WHERE id = ?').run(delta, p.id);
  req.db.prepare('INSERT INTO stock_movements (product_id, type, quantity, remark) VALUES (?, ?, ?, ?)').run(p.id, type, qty, remark || (type === 'in' ? '扫码入库' : '扫码出库'));
  res.json({ message: `${type === 'in' ? '入库' : '出库'}成功`, product: p.name, quantity: qty, new_stock: newStock });
});

// 库存调整
router.post('/adjust', (req, res) => {
  const { product_id, type, quantity, remark } = req.body;
  const delta = type === 'in' ? quantity : -quantity;
  const p = req.db.prepare('SELECT * FROM products WHERE id = ?').get(product_id);
  if (!p) return res.status(404).json({ error: '产品不存在' });
  if (p.current_stock + delta < 0) return res.status(400).json({ error: `库存不足，当前: ${p.current_stock}` });
  req.db.prepare('UPDATE products SET current_stock = current_stock + ? WHERE id = ?').run(delta, product_id);
  req.db.prepare('INSERT INTO stock_movements (product_id, type, quantity, remark) VALUES (?, ?, ?, ?)').run(product_id, type, quantity, remark || '库存调整');
  res.json({ message: '调整成功', new_stock: p.current_stock + delta });
});

// 盘点
router.post('/stocktake', (req, res) => {
  const { items } = req.body; // [{product_id, actual_count}]
  if (!items || !items.length) return res.status(400).json({ error: '请添加盘点项' });
  const results = [];
  const updateStock = req.db.prepare('UPDATE products SET current_stock = ? WHERE id = ?');
  const insertLog = req.db.prepare('INSERT INTO stock_movements (product_id, type, quantity, remark) VALUES (?, ?, ?, ?)');
  for (const item of items) {
    const p = req.db.prepare('SELECT * FROM products WHERE id = ?').get(item.product_id);
    if (!p) continue;
    const diff = item.actual_count - p.current_stock;
    if (diff !== 0) {
      updateStock.run(item.actual_count, item.product_id);
      insertLog.run(item.product_id, diff > 0 ? 'in' : 'out', Math.abs(diff), `盘点调整: 系统${p.current_stock} -> 实际${item.actual_count}`);
    }
    results.push({ product_id: p.id, code: p.code, name: p.name, system_count: p.current_stock, actual_count: item.actual_count, diff });
  }
  res.json({ message: '盘点完成', results });
});

// 库存统计报表
router.get('/report', (req, res) => {
  const db = req.db;
  const total_products = db.prepare('SELECT COUNT(*) as c FROM products WHERE status = 1').get().c;
  const total_stock_value = db.prepare('SELECT COALESCE(SUM(current_stock * cost_price), 0) as v FROM products WHERE status = 1').get().v;
  const low_stock_count = db.prepare('SELECT COUNT(*) as c FROM products WHERE status = 1 AND current_stock <= min_stock').get().c;
  const out_of_stock = db.prepare('SELECT COUNT(*) as c FROM products WHERE status = 1 AND current_stock = 0').get().c;
  const today_in = db.prepare("SELECT COALESCE(SUM(quantity), 0) as v FROM stock_movements WHERE type = 'in' AND date(created_at) = date('now','localtime')").get().v;
  const today_out = db.prepare("SELECT COALESCE(SUM(quantity), 0) as v FROM stock_movements WHERE type = 'out' AND date(created_at) = date('now','localtime')").get().v;
  const month_in = db.prepare("SELECT COALESCE(SUM(quantity), 0) as v FROM stock_movements WHERE type = 'in' AND created_at >= datetime('now','localtime','start of month')").get().v;
  const month_out = db.prepare("SELECT COALESCE(SUM(quantity), 0) as v FROM stock_movements WHERE type = 'out' AND created_at >= datetime('now','localtime','start of month')").get().v;

  // 各分类库存价值
  const category_value = db.prepare("SELECT category, COUNT(*) as count, SUM(current_stock) as total_qty, SUM(current_stock * cost_price) as total_value FROM products WHERE status = 1 AND category != '' GROUP BY category ORDER BY total_value DESC").all();

  // 最近7天出入库趋势
  const trend_7d = [];
  for (let i = 6; i >= 0; i--) {
    const in_v = db.prepare(`SELECT COALESCE(SUM(quantity),0) as v FROM stock_movements WHERE type='in' AND date(created_at)=date('now','localtime','-${i} days')`).get().v;
    const out_v = db.prepare(`SELECT COALESCE(SUM(quantity),0) as v FROM stock_movements WHERE type='out' AND date(created_at)=date('now','localtime','-${i} days')`).get().v;
    const label = db.prepare(`SELECT date('now','localtime','-${i} days') as d`).get().d.slice(5);
    trend_7d.push({ label, in: in_v, out: out_v });
  }

  res.json({
    total_products, total_stock_value, low_stock_count, out_of_stock,
    today_in, today_out, month_in, month_out,
    category_value, trend_7d
  });
});

module.exports = router;
