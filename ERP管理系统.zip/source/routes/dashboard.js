const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
  const db = req.db;
  const product_count = db.prepare('SELECT COUNT(*) as c FROM products WHERE status=1').get().c;
  const low_stock = db.prepare('SELECT COUNT(*) as c FROM products WHERE current_stock <= min_stock AND status=1').get().c;
  const pending_purchase = db.prepare("SELECT COUNT(*) as c FROM purchase_orders WHERE status IN ('draft','confirmed')").get().c;
  const pending_sales = db.prepare("SELECT COUNT(*) as c FROM sales_orders WHERE status IN ('draft','confirmed')").get().c;
  const total_income = db.prepare("SELECT COALESCE(SUM(amount),0) as t FROM finance_records WHERE type='income'").get().t;
  const total_expense = db.prepare("SELECT COALESCE(SUM(amount),0) as t FROM finance_records WHERE type='expense'").get().t;
  const monthly_income = db.prepare("SELECT COALESCE(SUM(amount),0) as t FROM finance_records WHERE type='income' AND created_at >= datetime('now','localtime','start of month')").get().t;
  const monthly_expense = db.prepare("SELECT COALESCE(SUM(amount),0) as t FROM finance_records WHERE type='expense' AND created_at >= datetime('now','localtime','start of month')").get().t;
  const contact_count = db.prepare('SELECT COUNT(*) as c FROM contacts WHERE status=1').get().c;
  const recent_orders = db.prepare(`
    SELECT 'purchase' as type, order_no, total_amount, status, created_at FROM purchase_orders
    UNION ALL
    SELECT 'sales' as type, order_no, total_amount, status, created_at FROM sales_orders
    ORDER BY created_at DESC LIMIT 10
  `).all();
  const low_stock_items = db.prepare('SELECT code,name,current_stock,min_stock FROM products WHERE current_stock<=min_stock AND status=1 LIMIT 5').all();
  const stock_value = db.prepare('SELECT COALESCE(SUM(current_stock*cost_price),0) as t FROM products WHERE status=1').get().t;

  res.json({
    product_count, low_stock, pending_purchase, pending_sales,
    total_income, total_expense, profit: total_income - total_expense,
    monthly_income, monthly_expense, monthly_profit: monthly_income - monthly_expense,
    contact_count, stock_value, recent_orders, low_stock_items
  });
});

module.exports = router;
