@echo off
cd /d "%~dp0"
"%~dp0node\node.exe" "%~dp0server.js"
pause
